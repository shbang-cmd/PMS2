# SQLite persistence layer for PMS2
library(DBI)
library(RSQLite)

holdings_columns <- c(
  "country", "symbol", "name", "currency", "asset_class", "tax_type",
  "broker", "account_type", "account_number", "fractional_share", "quantity", "avg_price",
  "avg_fx_rate", "cost_krw", "memo", "updated_at"
)

open_pms_db <- function(path = file.path("data", "pms.sqlite")) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  con <- dbConnect(SQLite(), path)
  dbExecute(con, "PRAGMA busy_timeout = 5000")
  dbExecute(con, "
    CREATE TABLE IF NOT EXISTS holdings (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      country        TEXT NOT NULL,
      symbol         TEXT NOT NULL,
      name           TEXT,
      currency       TEXT NOT NULL,
      asset_class    TEXT NOT NULL,
      tax_type       TEXT NOT NULL,
      broker         TEXT NOT NULL,
      account_type   TEXT NOT NULL,
      account_number TEXT NOT NULL,
      fractional_share INTEGER NOT NULL DEFAULT 0 CHECK(fractional_share IN (0,1)),
      quantity       REAL NOT NULL DEFAULT 0 CHECK(quantity >= 0),
      avg_price      REAL NOT NULL DEFAULT 0 CHECK(avg_price >= 0),
      avg_fx_rate    REAL NOT NULL DEFAULT 1 CHECK(avg_fx_rate > 0),
      cost_krw       REAL CHECK(cost_krw >= 0),
      memo           TEXT,
      updated_at     TEXT,
      UNIQUE(broker, account_number, country, symbol, fractional_share)
    )
  ")
  # Upgrade pre-v0.5.22 SQLite holdings safely: keep IDs/data, allow whole+fractional lots.
  fields <- DBI::dbGetQuery(con, "PRAGMA table_info(holdings)")$name
  indexes <- DBI::dbGetQuery(con, "PRAGMA index_list(holdings)")
  old_unique <- FALSE
  if (nrow(indexes)) {
    for (idx in indexes$name) {
      cols <- DBI::dbGetQuery(con, paste0("PRAGMA index_info(", DBI::dbQuoteString(con, idx), ")"))$name
      if (identical(as.character(cols), c("broker", "account_number", "country", "symbol"))) old_unique <- TRUE
    }
  }
  if (!("fractional_share" %in% fields) || old_unique) {
    DBI::dbWithTransaction(con, {
      DBI::dbExecute(con, "CREATE TABLE holdings_v0522 (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        country TEXT NOT NULL, symbol TEXT NOT NULL, name TEXT,
        currency TEXT NOT NULL, asset_class TEXT NOT NULL, tax_type TEXT NOT NULL,
        broker TEXT NOT NULL, account_type TEXT NOT NULL, account_number TEXT NOT NULL,
        fractional_share INTEGER NOT NULL DEFAULT 0 CHECK(fractional_share IN (0,1)),
        quantity REAL NOT NULL DEFAULT 0 CHECK(quantity >= 0),
        avg_price REAL NOT NULL DEFAULT 0 CHECK(avg_price >= 0),
        avg_fx_rate REAL NOT NULL DEFAULT 1 CHECK(avg_fx_rate > 0),
        cost_krw REAL CHECK(cost_krw >= 0), memo TEXT, updated_at TEXT,
        UNIQUE(broker, account_number, country, symbol, fractional_share))")
      copy_cols <- c("id", holdings_columns)
      values <- ifelse(copy_cols == "fractional_share" & !("fractional_share" %in% fields),
                       "0", copy_cols)
      DBI::dbExecute(con, paste0("INSERT INTO holdings_v0522 (",paste(copy_cols,collapse=","),
                                ") SELECT ",paste(values,collapse=",")," FROM holdings"))
      DBI::dbExecute(con, "DROP TABLE holdings")
      DBI::dbExecute(con, "ALTER TABLE holdings_v0522 RENAME TO holdings")
    })
  }
  con
}

list_holdings <- function(con, include_zero = FALSE) {
  sql <- paste0("SELECT id, ", paste(holdings_columns, collapse = ", "),
                " FROM holdings ", if (include_zero) "" else "WHERE quantity > 0 ",
                "ORDER BY id ASC")
  dbGetQuery(con, sql)
}

get_holding <- function(con, id) {
  x <- dbGetQuery(con, "SELECT * FROM holdings WHERE id = ?", params = list(as.integer(id)))
  if (nrow(x) == 0L) NULL else x[1, , drop = FALSE]
}

# updated_at은 DB에서 자동 기록합니다. 앱이 전달한 날짜는 사용하지 않습니다.
write_columns <- setdiff(holdings_columns, "updated_at")

insert_holding <- function(con, record) {
  stopifnot(identical(names(record), holdings_columns))
  placeholders <- paste(rep("?", length(write_columns)), collapse = ", ")
  sql <- paste0("INSERT INTO holdings (", paste(write_columns, collapse = ", "),
                ", updated_at) VALUES (", placeholders,
                ", strftime('%Y-%m-%d %H:%M:%S', 'now', 'localtime'))")
  dbExecute(con, sql, params = unname(record[write_columns]))
}

update_holding <- function(con, id, record) {
  stopifnot(identical(names(record), holdings_columns))
  # 동일 값으로 저장한 경우 갱신일시를 바꾸지 않습니다.
  # SQLite IS NOT 비교는 NULL도 정확하게 구분합니다.
  setters <- paste(paste0(write_columns, " = ?"), collapse = ", ")
  differences <- paste(paste0(write_columns, " IS NOT ?"), collapse = " OR ")
  sql <- paste0("UPDATE holdings SET ", setters,
                ", updated_at = strftime('%Y-%m-%d %H:%M:%S', 'now', 'localtime')",
                " WHERE id = ? AND (", differences, ")")
  values <- unname(record[write_columns])
  dbExecute(con, sql, params = c(values, list(as.integer(id)), values))
}

delete_holding <- function(con, id) {
  dbExecute(con, "DELETE FROM holdings WHERE id = ?", params = list(as.integer(id)))
}
