# PMS2 FIRE scenario calculator — illustrative 2026 Korean tax and insurance assumptions.
# Never equate withdrawals (including return of capital) with taxable income.
pms_fire_tax_brackets <- function(base) {
  cut <- c(0,14e6,50e6,88e6,150e6,300e6,500e6,1e9)
  rates <- c(.06,.15,.24,.35,.38,.40,.42,.45)
  x <- max(0,as.numeric(base)); z <- 0
  for (i in seq_along(rates)) {
    top <- if(i < length(cut)) cut[i+1L] else Inf
    z <- z + max(0,min(x,top)-cut[i])*rates[i]
  }
  z
}
pms_fire_financial_tax <- function(annual_income, other_tax_base=0) {
  f <- max(0,as.numeric(annual_income))
  b <- max(0,as.numeric(other_tax_base))
  if(f <= 20e6) return(f*.154)
  # Simplified comparative taxation; capital gross-up, credits and special withholding excluded.
  a <- 20e6*.14 + pms_fire_tax_brackets(b+f-20e6)-pms_fire_tax_brackets(b)
  max(f*.14,a)*1.1
}
pms_fire_scenarios <- function(nav, finance_income=19e6, foreign_gain_share=0,
                                other_tax_base=0, property_health_month=0,
                                include_health=TRUE) {
  if(!is.finite(nav) || nav<=0) return(data.frame())
  rates <- seq(.03,.08,by=.005)
  fin <- max(0,as.numeric(finance_income))
  fg <- pmax(0,nav*rates*max(0,foreign_gain_share)/100)
  # 2026: NHIS regional income component + LTC. Property points are entered separately as KRW/month.
  health_inc <- if(isTRUE(include_health) && fin>10e6) fin*.0719/12 else 0
  health_base <- if(isTRUE(include_health)) health_inc + max(0,as.numeric(property_health_month)) else 0
  health_ltc <- health_base*(.009448/.0719)
  financial_tax <- pms_fire_financial_tax(fin,other_tax_base)
  foreign_tax <- pmax(0,fg-2.5e6)*.22
  annual <- nav*rates
  total_tax <- financial_tax + foreign_tax
  monthly_net <- (annual-total_tax)/12-health_base-health_ltc
  data.frame(인출률=paste0(sprintf('%.1f',rates*100),'%'),
             연간_인출가능액=round(annual),월_세전_인출액=round(annual/12),
             연간_금융소득세_추정=round(rep(financial_tax,length(rates))),
             연간_해외주식_양도세_추정=round(foreign_tax),
             월_건강보험료_추정=round(rep(health_base,length(rates))),
             월_장기요양보험료_추정=round(rep(health_ltc,length(rates))),
             월_세후_가용액_추정=round(monthly_net),
             check.names=FALSE)
}
pms_fire_money <- function(x) if(is.finite(x)) paste0(format(round(x),big.mark=',',scientific=FALSE,trim=TRUE),'원') else '산출 불가'
pms_fire_scenario_ui <- function(x, nav, missing=0) {
  if(!nrow(x)) return(shiny::tags$div(class='alert alert-warning','시세 또는 환율이 없어 총평가액을 계산할 수 없습니다.'))
  shiny::tagList(
    shiny::tags$div(class='alert alert-info',
      shiny::tags$b('현재 금융자산 평가액: '),pms_fire_money(nav),
      shiny::tags$span(style='margin-left:12px;',paste0('시세 누락 보유행: ',missing,'건')),
      shiny::tags$p(style='margin:8px 0 0 0;',
        '여기서 수입은 임금·배당을 뜻하지 않고, 금융자산에서 정기 인출하는 생활비 재원입니다. 원금 인출 자체는 금융소득세 과세 대상이 아닙니다.')),
    shiny::tags$div(class='row',lapply(c(1L,5L,9L),function(i) {
      y<-x[i,]
      shiny::tags$div(class='col-sm-4',shiny::tags$div(style='border:1px solid #ddd;border-radius:9px;padding:14px;margin-bottom:10px;',
        shiny::tags$div(style='font-size:12px;color:#666;',paste0(y$인출률,' 인출 가정 · 월 세후')), 
        shiny::tags$strong(style='font-size:20px;',pms_fire_money(y$월_세후_가용액_추정))))
    })))
}
