# Join the latest collected quotes to brokerage holdings and calculate KRW values.
pms_valuation <- function(con, include_zero=FALSE) {
  init_market_tables(con)
  sql <- paste0("SELECT h.*, p.price AS current_price, p.source AS price_source,
    p.quoted_at AS price_date, p.fetched_at AS fetched_at
    FROM holdings h LEFT JOIN prices p ON p.country=h.country AND p.symbol=h.symbol ",
    if (!include_zero) "WHERE h.quantity > 0 " else "",
    "ORDER BY h.id ASC")
  d <- DBI::dbGetQuery(con,sql)
  if (!nrow(d)) return(d)
  fxdf <- DBI::dbGetQuery(con,"SELECT rate,quoted_at,fetched_at FROM fx_rates WHERE pair='USD/KRW'")
  fx <- if(nrow(fxdf)) as.numeric(fxdf$rate[1]) else NA_real_
  d$fx_current <- ifelse(d$currency=='KRW',1,ifelse(d$currency=='USD',fx,NA_real_))
  d$market_value_krw <- d$quantity * d$current_price * d$fx_current
  # Broker supplied cost basis takes precedence; otherwise use approximate basis.
  estimated_cost <- d$quantity * d$avg_price * d$avg_fx_rate
  usable_cost <- is.finite(d$cost_krw) & d$cost_krw >= 0
  d$cost_basis_krw <- ifelse(usable_cost,d$cost_krw,estimated_cost)
  d$cost_basis_source <- ifelse(usable_cost,'BROKER','ESTIMATED')
  d$profit_krw <- d$market_value_krw - d$cost_basis_krw
  d$return_pct <- ifelse(d$cost_basis_krw > 0,
                         d$profit_krw / d$cost_basis_krw * 100,NA_real_)
  d$quote_status <- ifelse(!is.finite(d$current_price),'NO_PRICE',
                    ifelse(!is.finite(d$fx_current),'NO_FX','OK'))
  d$fx_note <- ifelse(d$currency=='USD' & d$avg_fx_rate<=1 & !usable_cost,
                      'CHECK_PURCHASE_FX','')
  # 0 quantity is a historical marker: exclude from current NAV regardless of old basis.
  z <- which(d$quantity == 0)
  if (length(z)) {
    d$market_value_krw[z] <- 0
    d$cost_basis_krw[z] <- 0
    d$profit_krw[z] <- 0
    d$return_pct[z] <- NA_real_
    d$quote_status[z] <- 'CLOSED'
  }
  d
}

pms_valuation_view <- function(d) {
  if(!nrow(d)) return(data.frame())
  valid_nav <- is.finite(d$market_value_krw)
  nav_total <- if(any(valid_nav)) sum(d$market_value_krw[valid_nav]) else NA_real_
  weights <- if(is.finite(nav_total) && nav_total > 0) d$market_value_krw / nav_total * 100 else rep(NA_real_,nrow(d))
  weights[!valid_nav] <- NA_real_
  data.frame(
    ID=d$id,국가=d$country,종목코드=d$symbol,종목명=d$name,
    증권사=d$broker,계좌유형=d$account_type,
    소수점주식=ifelse(as.integer(d$fractional_share)==1L,"예","아니오"),
    보유수량=d$quantity,현재가=d$current_price,통화=d$currency,
    적용환율=d$fx_current,평가액_원=d$market_value_krw,비중_퍼센트=weights,
    취득원가_원=d$cost_basis_krw,평가손익_원=d$profit_krw,
    수익률_퍼센트=d$return_pct,상태=d$quote_status,
    취득원가기준=d$cost_basis_source,시세출처=d$price_source,
    시세기준일=d$price_date,수집시각_UTC=d$fetched_at,
    매입환율확인=d$fx_note,check.names=FALSE)
}
