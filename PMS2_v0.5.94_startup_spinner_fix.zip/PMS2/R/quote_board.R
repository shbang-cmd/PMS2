# PMS2 - previous trading session quote board (v0.5.73)
# Prices are read from SQLite only. The existing auto collector updates the DB
# every ~10 minutes while the Shiny session is alive and the checkbox is on.

pms_board_data <- function(con) {
  init_market_tables(con)
  h <- DBI::dbGetQuery(con, "SELECT country,symbol,MAX(name) AS name,
    SUM(quantity) AS quantity,MIN(currency) AS currency
    FROM holdings WHERE quantity>0 AND country IN ('KR','US')
    GROUP BY country,symbol ORDER BY country,symbol")
  if(!nrow(h)) return(h)
  p <- DBI::dbGetQuery(con,"SELECT country,symbol,price,source,quoted_at,fetched_at FROM prices")
  for(nm in c('price','source','quoted_at','fetched_at')) {
    h[[nm]] <- p[[nm]][match(paste(h$country,h$symbol),paste(p$country,p$symbol))]
  }
  h$quote_date <- as.Date(substr(as.character(h$quoted_at),1L,10L))
  h$previous_close <- rep(NA_real_,nrow(h))
  h$previous_date <- rep(as.Date(NA),nrow(h))
  # Includes benchmark history and prices archived during recurring collections.
  history_exists <- DBI::dbExistsTable(con,'history_daily')
  for(i in seq_len(nrow(h))) {
    if(is.na(h$quote_date[i])) next
    cutoff <- as.character(h$quote_date[i])
    prior <- DBI::dbGetQuery(con,"SELECT quote_date AS dt,price AS px FROM quote_daily_archive
      WHERE country=? AND symbol=? AND quote_date<? ORDER BY quote_date DESC LIMIT 1",
      params=list(h$country[i],h$symbol[i],cutoff))
    if(history_exists) {
      old <- DBI::dbGetQuery(con,"SELECT trade_date AS dt,close AS px FROM history_daily
        WHERE country=? AND symbol=? AND trade_date<? ORDER BY trade_date DESC LIMIT 1",
        params=list(h$country[i],h$symbol[i],cutoff))
      if(nrow(old)) prior <- rbind(prior,old)
    }
    if(nrow(prior)) {
      prior <- prior[order(prior$dt,decreasing=TRUE),,drop=FALSE]
      if(is.finite(prior$px[1]) && prior$px[1]>0) {
        h$previous_close[i] <- prior$px[1]
        h$previous_date[i] <- as.Date(prior$dt[1])
      }
    }
  }
  h$change <- h$price-h$previous_close
  h$change_pct <- (h$price/h$previous_close-1)*100
  h$change[!is.finite(h$change)] <- NA_real_
  h$change_pct[!is.finite(h$change_pct)] <- NA_real_
  h
}

pms_board_panel <- function(df,updated_at=Sys.time()) {
  fmt <- function(x,d=2) if(length(x)==0||!is.finite(x)) '-' else
    format(round(x,d),big.mark=',',trim=TRUE,nsmall=d,scientific=FALSE)
  if(!nrow(df)) return(shiny::tags$div(class='alert alert-info','보유종목이 없습니다.'))
  cards <- lapply(seq_len(nrow(df)),function(i) {
    r <- df[i,,drop=FALSE]
    valid <- is.finite(r$change_pct)
    stale <- is.na(r$quote_date) || as.numeric(Sys.Date()-r$quote_date)>5
    typ <- if(!valid) 'none' else if(r$change_pct>0) 'up' else if(r$change_pct<0) 'down' else 'flat'
    col <- switch(typ,up='#d43838',down='#267dc5',flat='#556577',none='#888888')
    state <- if(!valid) '기준가 없음' else paste0(if(r$change_pct>0) '+' else '',fmt(r$change_pct),'%')
    shiny::tags$div(style='border:1px solid #dce3e9;border-left:5px solid '
      %+% col %+% ';border-radius:9px;padding:12px;background:#fff;min-width:220px;flex:1 1 255px;',
      shiny::tags$div(style='font-size:14px;font-weight:700;color:#243647;',r$name),
      shiny::tags$div(style='font-size:11px;color:#7c8692;',paste(r$country,r$symbol)),
      shiny::tags$div(style='font-size:24px;font-weight:700;margin-top:8px;color:' %+% col %+% ';',
        if(is.finite(r$price)) fmt(r$price,if(r$country=='KR') 0 else 2) else '시세 없음'),
      shiny::tags$div(style='font-weight:700;color:' %+% col %+% ';',
        paste0(state,if(valid) paste0(' (',if(r$change>=0) '+' else '',fmt(r$change,if(r$country=='KR') 0 else 2),')') else '')),
      shiny::tags$div(style='font-size:11px;color:#687786;margin-top:5px;',
        '현재 ',if(!is.na(r$quote_date)) as.character(r$quote_date) else '날짜 미확인',
        ' / 이전 ',if(!is.na(r$previous_date)) as.character(r$previous_date) else '기록 없음'),
      if(stale) shiny::tags$div(style='font-size:11px;color:#aa6b10;', '주의: 시세 기준일이 오래됐거나 확인되지 않음')
    )
  })
  shiny::tags$div(
    shiny::tags$p(style='color:#607386;',
      paste0('화면 갱신: ',format(updated_at,'%Y-%m-%d %H:%M:%S'),
        ' · 종목 ',nrow(df),'개 · 등락률 산출 ',sum(is.finite(df$change_pct)),'개')),
    shiny::tags$p(class='text-muted',
      '최근 저장 시세 대비 직전 거래일 종가를 비교합니다. 빨강은 상승, 파랑은 하락입니다. 이전 종가가 없으면 표시를 생략합니다. 10분마다 새 가격이 들어온다는 보장은 없습니다.'),
    shiny::tags$div(style='display:flex;flex-wrap:wrap;gap:12px;',cards)
  )
}
# Local string concatenation helper for Shiny CSS strings.
`%+%` <- function(x,y) paste0(x,y)


# 종목별 종가 차이와 보유 수량으로 계산하는 KRW 가격 기여도.
# USD/KRW 변동 자체의 별도 손익은 포함하지 않는다.
pms_board_valuation_changes <- function(df,con) {
  out_names <- c('국가','종목코드','종목명','보유수량','전일종가','현재가',
                 '등락률(%)','총평가액(원)','평가증감(원)','시세기준일','전일기준일','상태')
  if(is.null(df) || !nrow(df)) {
    z <- as.data.frame(setNames(replicate(length(out_names),numeric(0),simplify=FALSE),out_names),
                       check.names=FALSE)
    return(z)
  }
  fx <- tryCatch(DBI::dbGetQuery(con,
    "SELECT rate FROM fx_rates WHERE pair='USD/KRW' LIMIT 1"),
    error=function(e) data.frame())
  krw <- if(nrow(fx) && is.finite(as.numeric(fx$rate[1])) &&
            as.numeric(fx$rate[1])>0) as.numeric(fx$rate[1]) else NA_real_
  multiplier <- ifelse(df$country=='KR',1,krw)
  # Do not silently count unavailable USD quotes/FX as 0 KRW.
  current_value <- df$price * df$quantity * multiplier
  price_effect <- (df$price-df$previous_close) * df$quantity * multiplier
  current_value[!is.finite(current_value) | current_value<0] <- NA_real_
  price_effect[!is.finite(price_effect)] <- NA_real_
  status <- ifelse(!is.finite(df$price),'현재가 없음',
      ifelse(df$country=='US' & !is.finite(krw),'환율 없음',
      ifelse(!is.finite(df$previous_close),'전일 기준가 없음',
      ifelse(is.na(df$quote_date),'시세일 미확인',
      ifelse(as.numeric(Sys.Date()-df$quote_date)>5,'오래된 시세','정상')))))
  z <- data.frame('국가'=df$country,'종목코드'=df$symbol,'종목명'=df$name,
    '보유수량'=as.numeric(df$quantity),
    '전일종가'=as.numeric(df$previous_close),
    '현재가'=as.numeric(df$price),
    '등락률(%)'=as.numeric(df$change_pct),
    '총평가액(원)'=round(current_value),
    '평가증감(원)'=round(price_effect),
    '시세기준일'=as.character(df$quote_date),
    '전일기준일'=as.character(df$previous_date),
    '상태'=status,check.names=FALSE,stringsAsFactors=FALSE)
  # Highest KRW position size first. NA valuations appear at the end.
  z[order(is.na(z[['총평가액(원)']]),-z[['총평가액(원)']],z[['종목코드']]),,drop=FALSE]
}
