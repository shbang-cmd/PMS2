# v0.5.78: Same initial wealth, inferred dated cash-flows, ETF price-only comparator.
# IMPORTANT: Invested = NAV - unrealized P&L is NOT verified external cash-flow.
# Reinvesting/rebalancing, realized gains and cost-basis changes may contaminate flows.
pms_equal_cashflow_data <- function(con, nav_history, max_stale_days=4L) {
  empty <- list(ok=FALSE,reason='비교에 필요한 자료가 부족합니다.')
  if(!'history_daily' %in% DBI::dbListTables(con)) return(empty)
  etf <- DBI::dbGetQuery(con,"SELECT trade_date,close FROM history_daily WHERE country='KR' AND symbol='379800' AND close>0 ORDER BY trade_date")
  if(nrow(etf)<2L) return(list(ok=FALSE,reason='KODEX 미국S&P500 과거종가가 부족합니다. 홈의 전체기간 다시 수집 버튼을 사용하세요.'))
  n <- nav_history
  if(!all(c('date','value','profit') %in% names(n))) return(list(ok=FALSE,reason='총평가액과 평가손익이 함께 저장된 이력이 필요합니다.'))
  n$date <- as.Date(n$date); n$value <- as.numeric(n$value);n$profit <- as.numeric(n$profit)
  n <- n[!is.na(n$date)&is.finite(n$value)&n$value>0&is.finite(n$profit),,drop=FALSE]
  n <- n[order(n$date),,drop=FALSE];n <- n[!duplicated(n$date,fromLast=TRUE),,drop=FALSE]
  etf$date <- as.Date(etf$trade_date);etf <- etf[!is.na(etf$date)&is.finite(etf$close)&etf$close>0,,drop=FALSE]
  etf <- etf[order(etf$date),,drop=FALSE];etf <- etf[!duplicated(etf$date,fromLast=TRUE),,drop=FALSE]
  if(nrow(n)<3L||nrow(etf)<2L) return(empty)
  # Match the latest published close *on or before* each portfolio observation, no look-ahead.
  j <- findInterval(as.numeric(n$date),as.numeric(etf$date))
  valid <- j>0L
  staleness <- rep(Inf,nrow(n));staleness[valid] <- as.integer(n$date[valid]-etf$date[j[valid]])
  valid <- valid & staleness <= max_stale_days
  n <- n[valid,,drop=FALSE];j <- j[valid]
  if(nrow(n)<20L) return(list(ok=FALSE,reason='공통 기간의 유효한 ETF 종가가 20회 미만입니다. 과거시세 보충 상태를 확인하세요.'))
  n$etf_close <- as.numeric(etf$close[j]);n$etf_date <- etf$date[j]
  n$invested_proxy <- n$value-n$profit
  # Only compare contiguous observation pairs; abnormal proxy inflows are deliberately NOT erased.
  n$inferred_flow <- c(0,diff(n$invested_proxy))
  n$portfolio_return <- c(NA_real_, n$value[-1] / (n$value[-nrow(n)] + n$inferred_flow[-1]) - 1)
  n$etf_return <- c(NA_real_, n$etf_close[-1]/n$etf_close[-nrow(n)]-1)
  # If ETF data gaps exceed 4 days across observations, do not connect over missing periods.
  n$hypothetical <- NA_real_;n$hypothetical[1] <- n$value[1]
  for(i in seq.int(2L,nrow(n))) {
    prev <- n$hypothetical[i-1L]; flow <- n$inferred_flow[i]
    if(is.finite(prev) && is.finite(flow) && is.finite(n$etf_return[i]) && prev+flow>0)
      n$hypothetical[i] <- (prev+flow)*(1+n$etf_return[i])
  }
  # TWR-like chained proxy return, not audited TWR.
  good <- is.finite(n$portfolio_return[-1]) & (1+n$portfolio_return[-1]>0)
  if(!all(good) || !is.finite(tail(n$hypothetical,1)))
    return(list(ok=FALSE,reason='추정 현금흐름으로 비교 계좌 잔고가 0 이하가 되거나 유효하지 않은 기간이 있습니다. 입출금 기록을 확인하세요.'))
  n$portfolio_index <- c(100,100*cumprod(1+n$portfolio_return[-1]))
  n$etf_index <- 100*n$etf_close/n$etf_close[1]
  list(ok=TRUE,series=n,begin=as.character(n$date[1]),end=as.character(tail(n$date,1)),
    portfolio_pct=100*(tail(n$portfolio_index,1)/100-1),
    etf_pct=100*(tail(n$etf_index,1)/100-1),
    initial=n$value[1],portfolio_final=tail(n$value,1),etf_final=tail(n$hypothetical,1),
    net_flow=sum(n$inferred_flow[-1]),samples=nrow(n),large_flows=sum(abs(n$inferred_flow[-1])>0.08*n$value[-nrow(n)],na.rm=TRUE))
}

# v0.5.79: Common-date, flow-adjusted daily return metrics.
# Price return for ETF excludes ETF cash distributions. Risk-free rate = 0.
pms_equal_cashflow_metrics <- function(r) {
  r <- as.numeric(r)
  if(length(r)<20L || any(!is.finite(r)) || any(r<=-1))
    return(list(ok=FALSE,reason='비교에 필요한 유효 수익률 구간이 20개 미만이거나 비정상 값이 포함됩니다.'))
  curve <- cumprod(1+r)
  peak <- cummax(c(1,curve))[-1L]
  mdd <- min(curve/peak-1)
  cumulative <- tail(curve,1L)-1
  annual <- (1+cumulative)^(252/length(r))-1
  volatility <- stats::sd(r)
  sharpe <- if(is.finite(volatility) && volatility>0) mean(r)/volatility*sqrt(252) else NA_real_
  calmar <- if(is.finite(mdd) && mdd < 0) annual / abs(mdd) else NA_real_
  list(ok=TRUE,cumulative=cumulative,annual=annual,mdd=mdd,sharpe=sharpe,calmar=calmar,n=length(r))
}

pms_equal_cashflow_risk_table <- function(z) {
  a <- z$series
  # Rows correspond to precisely the same dated intervals, not independent dropna() samples.
  rp <- a$portfolio_return[-1L]
  re <- a$etf_return[-1L]
  mp <- pms_equal_cashflow_metrics(rp)
  me <- pms_equal_cashflow_metrics(re)
  if(!isTRUE(mp$ok) || !isTRUE(me$ok))
    return(shiny::tags$p(class='alert alert-warning','동일 관측일 위험지표 계산에 필요한 정상 수익률 자료가 부족합니다.'))
  pct <- function(x) if(is.finite(x)) sprintf('%+.2f%%',100*x) else '산출불가'
  num <- function(x) if(is.finite(x)) sprintf('%.2f',x) else '산출불가'
  tr <- function(label,port,etf,desc) shiny::tags$tr(
    shiny::tags$th(scope='row',style='white-space:nowrap;',label),
    shiny::tags$td(style='text-align:right;white-space:nowrap;color:#2879bf;font-weight:600;',port),
    shiny::tags$td(style='text-align:right;white-space:nowrap;color:#d88428;font-weight:600;',etf),
    shiny::tags$td(desc))
  shiny::tags$div(style='margin:16px 0 8px;',
    shiny::tags$h4(style='font-size:17px;font-weight:700;margin:0 0 9px;','동일기간 투자성과·위험 비교 (Return · MDD · Sharpe · Calmar)'),
    shiny::tags$div(style='overflow-x:auto;',
      shiny::tags$table(class='table table-bordered table-striped',style='width:100%;max-width:900px;font-size:13px;',
        shiny::tags$thead(shiny::tags$tr(
          shiny::tags$th('지표'),shiny::tags$th('내 포트폴리오 (추정)'),
          shiny::tags$th('S&P500 ETF (가격)'),shiny::tags$th('해석'))),
        shiny::tags$tbody(
          tr('Return · 누적',pct(mp$cumulative),pct(me$cumulative),'동일기간 누적 복리수익률; 높을수록 유리'),
          tr('Return · 연환산',pct(mp$annual),pct(me$annual),'252관측일 기준 연환산 복리수익률'),
          tr('MDD',pct(mp$mdd),pct(me$mdd),'현금흐름을 제거한 수익률 지수의 최대낙폭; 0%에 가까울수록 방어적'),
          tr('Sharpe',num(mp$sharpe),num(me$sharpe),'무위험수익률 0% 가정; 높을수록 변동성 대비 효율적'),
          tr('Calmar',num(mp$calmar),num(me$calmar),'공식: 연환산 Return ÷ |MDD| · 높을수록 최대낙폭 대비 성과가 좋음')))),
    shiny::tags$p(style='color:#5b6f80;font-size:12px;margin:8px 0 2px;',
      sprintf('동일 관측 구간 %d개 · %s ~ %s · 연환산 252관측일 · 무위험수익률 0%%.',mp$n,z$begin,z$end)),
    shiny::tags$p(style='color:#855900;font-size:12px;margin:2px 0;',
      '내 포트폴리오의 Return은 평가액−평가손익의 변화를 외부 현금흐름으로 간주한 추정치이며 확정된 TWR이 아닙니다. ',
      'ETF는 분배금 재투자·수수료·세금이 없는 가격수익률입니다. ',
      'MDD는 순유입에 따라 달라지는 평가액 그래프의 낙폭이 아닌 복리 수익률 지수에서 산출합니다.'))
}

pms_equal_cashflow_panel <- function(con, history) {
  tryCatch({
    z <- pms_equal_cashflow_data(con,history)
    if(!isTRUE(z$ok)) return(shiny::tags$div(style='background:white;border:1px solid #dfe6ee;border-radius:9px;padding:15px;margin:12px 0;',
      shiny::tags$h4('동일조건 투자성과 비교 · 추정'),shiny::tags$p(class='text-muted',z$reason)))
    a <- z$series
    W<-1100;H<-340;L<-78;R<-35;T<-30;B<-54
    xrange<-as.numeric(range(a$date));if(diff(xrange)<1) xrange[2]<-xrange[1]+1
    yr<-range(c(a$value,a$hypothetical),finite=TRUE);span<-max(diff(yr),1);yr<-yr+c(-0.08,0.08)*span
    xfun<-function(d)L+(as.numeric(d)-xrange[1])/diff(xrange)*(W-L-R)
    yfun<-function(v)T+(yr[2]-v)/diff(yr)*(H-T-B)
    path<-function(v) paste(sprintf('%.1f,%.1f',xfun(a$date),yfun(v)),collapse=' ')
    ticks<-pretty(yr,5);ticks<-ticks[ticks>=yr[1]&ticks<=yr[2]]
    months<-seq(as.Date(format(min(a$date),'%Y-%m-01')),as.Date(format(max(a$date),'%Y-%m-01')),by='month')
    months<-months[months>=min(a$date)&months<=max(a$date)]
    label_step<-if(length(months)>30)3L else if(length(months)>16)2L else 1L
    fmt<-function(x)format(round(x),big.mark=',',scientific=FALSE)
    shiny::tags$div(style='background:white;border:1px solid #dfe6ee;border-radius:9px;padding:16px;margin:12px 0;',
      shiny::tags$h4(style='margin-top:0;font-weight:700;','동일조건 투자성과 비교 · 같은 초기금액 / 같은 추정 불입 일정'),
      shiny::tags$p(style='font-size:13px;color:#567;',sprintf('%s ~ %s · %d개 관측일 · 시작금액 %s원 · 기간 추정 순유입 %s원',z$begin,z$end,z$samples,fmt(z$initial),fmt(z$net_flow))),
      shiny::tags$div(style='display:flex;flex-wrap:wrap;gap:13px;margin:10px 0;',
        shiny::tags$strong(style='color:#2879bf;',sprintf('● 내 포트폴리오 최종 %s원',fmt(z$portfolio_final))),
        shiny::tags$strong(style='color:#d88428;',sprintf('● ETF 가상계좌 최종 %s원',fmt(z$etf_final))),
        shiny::tags$span(sprintf('차이 %+s원',fmt(z$portfolio_final-z$etf_final)))),
      shiny::tags$svg(viewBox=sprintf('0 0 %d %d',W,H),style='width:100%;height:auto;display:block;',
        lapply(ticks,function(v) shiny::tags$line(x1=L,x2=W-R,y1=yfun(v),y2=yfun(v),stroke='#e3ebf2')),
        lapply(months,function(d)shiny::tags$line(x1=xfun(d),x2=xfun(d),y1=T,y2=H-B,stroke='#d9e4ee','stroke-dasharray'='3 5')),
        lapply(ticks,function(v)shiny::tags$text(x=L-8,y=yfun(v)+4,'text-anchor'='end',style='font-size:12px;fill:#61768b;',sprintf('%.1f억',v/1e8))),
        shiny::tags$polyline(points=path(a$value),stroke='#2879bf','stroke-width'=2.8,fill='none'),
        shiny::tags$polyline(points=path(a$hypothetical),stroke='#d88428','stroke-width'=2.8,fill='none'),
        lapply(months[seq.int(1L,length(months),by=label_step)],function(d)shiny::tags$text(x=xfun(d),y=H-B+19,'text-anchor'='middle',style='font-size:11px;fill:#61768b;',format(d,'%y.%m')))),
      shiny::tags$p(style='font-size:13px;',sprintf('참고: 현금흐름 보정 누적 추정 수익률  내 포트폴리오 %+.2f%% · ETF 가격수익률 %+.2f%% (분배금 제외)',z$portfolio_pct,z$etf_pct)),
      pms_equal_cashflow_risk_table(z),
      shiny::tags$p(class='alert alert-warning',style='font-size:12px;',
        '비교용 추정치: 날짜별 외부 불입액이 기록되지 않아 (총평가액−평가손익)의 증감을 순유입액으로 가정했습니다. ',
        '이 수치는 매매·취득원가 변화·실현손익·계좌이체와 다를 수 있습니다. ETF 가상계좌는 동일한 추정 흐름을 적용한 종가 기준이며 분배금, 세금, 수수료와 환매·거래 체결시점은 반영하지 않습니다. ',
        '따라서 실제 초과수익률이나 실제 불입액을 확정하지 않습니다.'),
      if(z$large_flows>0L)shiny::tags$p(class='text-muted',style='font-size:12px;',sprintf('투자원금 대용치가 직전 자산의 8%%보다 크게 변한 구간 %d회: 원금 추정 또는 기록의 정합성을 확인하세요.',z$large_flows)))
  },error=function(e)shiny::tags$div(class='alert alert-warning',paste('동일조건 비교 계산 오류:',conditionMessage(e))))
}
