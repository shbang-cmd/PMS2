# v0.5.62 - descriptive risk statistics from aggregate valuation archives.
# No recorded deposits/withdrawals: these are NOT TWR or investment returns.
pms_performance_calc <- function(x) {
  x <- x[!is.na(x$date) & is.finite(x$value) & x$value > 0,,drop=FALSE]
  x <- x[order(x$date),,drop=FALSE]
  if(nrow(x)) x <- x[!duplicated(x$date,fromLast=TRUE),,drop=FALSE]
  if(nrow(x)<2L) return(list(data=x,stats=list(n=nrow(x))))
  v <- x$value; n <- length(v)
  r <- v[-1]/v[-n]-1
  peak <- cummax(v); dd <- v/peak-1
  x$drawdown_pct <- 100*dd
  x$index100 <- 100*v/v[1]
  x$change_pct <- c(NA_real_,100*r)
  # Reporting cadence may contain weekends/non-trading days. Report observation-based
  # dispersion and avoid annualized Sharpe/Sortino without actual trading-day returns.
  vol <- if(length(r)>1L) stats::sd(r) else NA_real_
  downside <- sqrt(mean(pmin(r,0)^2))
  best <- max(r); worst <- min(r)
  bottom <- which.min(dd); top <- which.max(v[seq_len(bottom)])
  total_change <- v[n]/v[1]-1
  days <- as.numeric(x$date[n]-x$date[1])
  annualized_value_growth <- if(days>0) (v[n]/v[1])^(365.25/days)-1 else NA_real_
  # Illustrative zero-risk-free ratios computed on observations; NOT Sharpe/Sortino of investments.
  proxy_sharpe <- if(is.finite(vol) && vol>0) mean(r)/vol else NA_real_
  proxy_sortino <- if(is.finite(downside) && downside>0) mean(r)/downside else NA_real_
  stats <- list(n=n,from=x$date[1],to=x$date[n],value_first=v[1],value_last=v[n],
    growth=total_change,annualized_growth=annualized_value_growth,
    mdd=min(dd),mdd_peak=x$date[top],mdd_trough=x$date[bottom],
    current_dd=tail(dd,1),daily_sd=vol,best=best,worst=worst,
    positive=sum(r>0),negative=sum(r<0),unchanged=sum(r==0),
    max_value=max(v),min_value=min(v),
    proxy_sharpe=proxy_sharpe,proxy_sortino=proxy_sortino,
    gap_days=as.numeric(diff(x$date)))
  list(data=x,stats=stats)
}
pms_perf_fmt_pct <- function(v,digits=2L) if(length(v)!=1L || !is.finite(v)) '산출 불가' else sprintf(paste0('%+.',digits,'f%%'),100*v)
pms_perf_fmt_num <- function(v,digits=3L) if(length(v)!=1L || !is.finite(v)) '산출 불가' else sprintf(paste0('%+.',digits,'f'),v)
pms_performance_panel <- function(result) {
  x <- result$data; s <- result$stats
  if(s$n<2L) return(shiny::tags$div(class='alert alert-info','분석할 평가액 기록이 2개 이상 필요합니다.'))
  card <- function(title,value,note='') shiny::tags$div(style='flex:1 1 195px;min-width:195px;padding:14px;border-radius:9px;border:1px solid #dae5ee;background:#f8fafd;',
    shiny::tags$div(style='font-size:12px;color:#64758a;',title),
    shiny::tags$strong(style='font-size:20px;',value),
    shiny::tags$div(style='font-size:11px;color:#687a88;margin-top:5px;',note))
  gap <- s$gap_days
  irregular <- sum(gap>4L,na.rm=TRUE)
  shiny::tags$div(
    shiny::tags$div(class='alert alert-warning',
      shiny::tags$b('해석 주의: 운용수익률 아님. '),
      '현재 자료는 매일의 총평가액·미실현 평가손익만 기록합니다. 입출금, 매매로 인한 원금 변화와 현금·예수금이 포함되지 않아 아래 평가액 증감 기반 MDD·변동성·비율은 실제 투자성과 지표가 아닙니다. ',
      '정확한 TWR·Sharpe·Sortino·Calmar 및 수익률 기준 MDD는 외부 현금흐름과 일별 총자산 기준가가 수집된 이후 산출해야 합니다.'),
    shiny::tags$div(style='display:flex;flex-wrap:wrap;gap:10px;margin:12px 0;',
      card('최신 총평가액',pms_traj_money(s$value_last),sprintf('%s 기준',as.character(s$to))),
      card('기간 평가액 증감률',pms_perf_fmt_pct(s$growth),'입출금 등을 포함한 자산 증감'),
      card('평가액 기준 최대낙폭(MDD)',pms_perf_fmt_pct(s$mdd),sprintf('고점 %s → 저점 %s',s$mdd_peak,s$mdd_trough)),
      card('현재 고점 대비 낙폭',pms_perf_fmt_pct(s$current_dd),'기간 최고 평가액 대비'),
      card('관측간 변화율 표준편차',pms_perf_fmt_pct(s$daily_sd),'연율화하지 않음 · 불규칙 관측 주의'),
      card('최대 상승 / 하락 관측',paste(pms_perf_fmt_pct(s$best),'/',pms_perf_fmt_pct(s$worst)),'연속 기록 간 평가액 변화'),
      card('변화율 기반 평균/변동성',pms_perf_fmt_num(s$proxy_sharpe),'무위험수익률 0 · 비연율화 · 참고만'),
      card('변화율 기반 평균/하방편차',pms_perf_fmt_num(s$proxy_sortino),'비연율화 · 실제 Sortino 아님')),
    pms_trajectory_svg(x,col='#286db0',metric='value',label='총평가액 추이 · 원화'),
    pms_trajectory_svg(x,col='#cc8d3d',metric='profit',label='미실현 평가손익 추이 · 원화'),
    pms_trajectory_svg(x,col='#4a9a80',metric='index100',label='평가액 지수 (첫날=100, 자금유입 혼재)'),
    pms_trajectory_svg(x,col='#cf5757',metric='drawdown_pct',label='최고점 대비 하락률 (%)'),
    shiny::tags$div(style='padding:12px;border:1px solid #e0e7ef;border-radius:9px;margin:12px 0;',
      shiny::tags$h4('추가 관찰 지표'),
      shiny::tags$p(sprintf('분석 날짜: %s ~ %s / 관측 %d회 / 연속 관측 사이 4일 초과 공백 %d회',s$from,s$to,s$n,irregular)),
      shiny::tags$p(sprintf('평가액 최고 %s · 최저 %s',pms_traj_money(s$max_value),pms_traj_money(s$min_value))),
      shiny::tags$p(sprintf('연속 관측 증가 %d회 · 감소 %d회 · 동일 %d회',s$positive,s$negative,s$unchanged)),
      shiny::tags$p('기간 평가액 증가율의 연환산값은 입출금의 영향을 크게 받으므로 실제 CAGR로 표시하지 않습니다.')),
    shiny::tags$p(style='font-size:12px;color:#68798a;',
      '일부 기록은 주말·공휴일을 포함하고 날짜 간격이 일정하지 않습니다. 변동성은 연속 관측치 기준이며 252거래일 연율화하지 않았습니다.'))
}
