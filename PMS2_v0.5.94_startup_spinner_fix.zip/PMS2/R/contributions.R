# Pension/ISA external contributions. Not inferred from holding market values.
pms_contrib_init <- function(con) {
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS account_contributions (id INTEGER PRIMARY KEY AUTOINCREMENT, contribution_date TEXT NOT NULL, account_type TEXT NOT NULL CHECK(account_type IN ('IRP','PENSION','ISA')), broker TEXT NOT NULL DEFAULT '', account_number TEXT NOT NULL DEFAULT '', amount_krw REAL NOT NULL CHECK(amount_krw > 0), memo TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
  DBI::dbExecute(con, 'CREATE INDEX IF NOT EXISTS idx_contrib_year_type ON account_contributions(contribution_date, account_type)')
  DBI::dbExecute(con, 'CREATE TABLE IF NOT EXISTS isa_allowance (year INTEGER PRIMARY KEY, carryover_krw REAL NOT NULL DEFAULT 0 CHECK(carryover_krw >= 0), updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
  invisible(TRUE)
}
pms_contrib_rows <- function(con, year) {
  DBI::dbGetQuery(con, 'SELECT id AS ID, contribution_date AS 날짜, account_type AS 계좌, broker AS 증권사, account_number AS 계좌번호, amount_krw AS 납입액_원, memo AS 비고 FROM account_contributions WHERE substr(contribution_date,1,4)=? ORDER BY contribution_date DESC,id DESC', params=list(as.character(year)))
}
pms_contrib_summary <- function(con, year) {
  rows <- pms_contrib_rows(con,year)
  sums <- sapply(c('IRP','PENSION','ISA'),function(k) sum(rows$납입액_원[rows$계좌==k],na.rm=TRUE))
  carry <- DBI::dbGetQuery(con, 'SELECT carryover_krw FROM isa_allowance WHERE year=?',params=list(as.integer(year)))
  list(irp=unname(sums['IRP']), pension=unname(sums['PENSION']),isa=unname(sums['ISA']),carry=if(nrow(carry)) as.numeric(carry$carryover_krw[1]) else 0)
}
pms_contrib_progress <- function(title,amount,limit,description,color='#478bd2') {
  money <- function(x) paste0(format(round(x),big.mark=',',scientific=FALSE,trim=TRUE),'원')
  pct <- if(limit>0) amount/limit*100 else 0
  shiny::tags$div(style='background:#fff;border:1px solid #dce3eb;padding:13px;border-radius:8px;margin:10px 0;',
    shiny::tags$div(style='display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;',shiny::tags$b(title),shiny::tags$span(paste0(money(amount),' / ',money(limit),' (',sprintf('%.1f',pct),'%)'))),
    shiny::tags$div(style='height:20px;background:#e9edf2;border-radius:6px;margin:8px 0;overflow:hidden;',
      shiny::tags$div(style=paste0('height:100%;width:',sprintf('%.2f',min(100,max(0,pct))),'%;background:',color,';'))),
    shiny::tags$small(paste0('남은 기준 금액: ',money(max(0,limit-amount)),' · ',description)))
}
pms_contrib_panel <- function(x) {
  total <- x$irp+x$pension
  shiny::tagList(
    pms_contrib_progress('IRP 개인 연간 납입 목표',x$irp,9000000,'개인 관리 목표. IRP 단독 세액공제 한도가 아님.','#478bd2'),
    pms_contrib_progress('연금저축 개인 연간 납입 목표',x$pension,9000000,'개인 관리 목표. 연금저축 단독 세액공제 대상은 최대 600만 원.','#7e72ce'),
    pms_contrib_progress('IRP + 연금저축 합산 개인 추가납입',total,18000000,'일반적인 연금계좌 개인 추가납입 합산 한도.','#328ca4'),
    pms_contrib_progress('연금계좌 합산 세액공제 참고 진도',min(total,9000000),9000000,'세액공제 대상 산정 시 연금저축분은 최대 600만 원까지 인정. 각 계좌별 900만 원 공제 아님.','#c18b36'),
    pms_contrib_progress('ISA 연간 납입 진도',x$isa,20000000+x$carry,paste0('기본 연 2,000만 원 + 입력한 미사용한도 이월 ',format(x$carry,big.mark=','),'원. 실제 납입 가능액은 증권사 확인 필요.'),'#39a280'),
    shiny::tags$p(style='font-size:12px;color:#596b7f;', '실제 납입 내역만 집계합니다. 보유 평가액, 매수·매도, 계좌 간 이동을 자동으로 납입액으로 간주하지 않습니다. 세액공제 상한 초과 납입과 공제받지 않은 원금은 구분해야 합니다.')
  )
}
