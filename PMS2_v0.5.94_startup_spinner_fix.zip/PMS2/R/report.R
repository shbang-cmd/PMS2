# PMS2 Quarto report generator. Does not call any external services.
pms_report_money <- function(x, digits=0L) {
  if(length(x)!=1L || !is.finite(x)) return('미산출')
  paste0(format(round(x,digits),big.mark=',',scientific=FALSE,trim=TRUE,nsmall=digits),'원')
}
pms_report_table <- function(df, max_rows=Inf) {
  if(is.null(df) || !nrow(df)) return('_해당 자료가 저장되어 있지 않습니다._')
  df <- head(df,max_rows)
  safe <- function(s) {
    if (is.numeric(s)) s <- format(s, scientific=FALSE, trim=TRUE, big.mark=',')
    s <- as.character(s); s[is.na(s)] <- '미확인'
    gsub('[|\\r\\n]',' / ',s)
  }
  # Align financial figures to the right in both Quarto HTML and PDF.
  # Many money/percentage values are already formatted strings (e.g. '12,345원', '5.20%'),
  # so a numeric-class-only check is insufficient.
  is_numeric_column <- function(column, header) {
    if(is.numeric(column) || is.integer(column)) return(TRUE)
    header <- trimws(as.character(header))
    # Dates/identifiers and category labels remain left aligned.
    if(grepl('날짜|일자|기준일|시작일|종료일|종목|코드|계좌|증권사|구분|분류|상태|출처|설명|비교대상|월$',header)) return(FALSE)
    if(grepl('금액|평가액|평가금|수익|손익|원금|납입|배당|금액|비중|비율|률|수량|잔고|건수|기록수|거래일수|Sharpe|Sortino|Calmar|MDD|VaR|CVaR|_pct|^금액$|^달성률$',header,ignore.case=TRUE)) return(TRUE)
    values <- trimws(as.character(column))
    values <- values[!is.na(values) & nzchar(values) & !(values %in% c('미확인','미산출','기록 없음','해당 없음'))]
    if(!length(values)) return(FALSE)
    # Allow currencies, %, comma separators, signs and negative figures.
    mean(grepl('^[+-]?[0-9][0-9,]*(\\.[0-9]+)?\\s*(원|%|%p|배)?$',values,perl=TRUE)) >= 0.8
  }
  align <- vapply(seq_along(df),function(j)
    if(is_numeric_column(df[[j]],names(df)[j])) '---:' else ':---',character(1))
  lines <- c(paste0('| ',paste(safe(names(df)),collapse=' | '),' |'),
             paste0('| ',paste(align,collapse=' | '),' |'))
  for(i in seq_len(nrow(df))) lines <- c(lines,paste0('| ',paste(vapply(df[i,,drop=FALSE],function(x)safe(x[[1]]),character(1)),collapse=' | '),' |'))
  paste(lines,collapse='\n')
}
# Separate PDF layout: fixed-width LaTeX columns prevent Pandoc's narrow
# automatically allocated cells from breaking Sharpe / Sortino / Calmar.
# HTML keeps the normal responsive Markdown table. No TeX commands leak to HTML.
pms_report_benchmark_metrics <- function(df) {
  if (is.null(df) || !nrow(df)) return('_해당 자료가 저장되어 있지 않습니다._')
  html <- pms_report_table(df, 10)
  tex_escape <- function(x) {
    x <- as.character(x); x[is.na(x)] <- '미확인'
    for (pair in list(c('&','\\&'), c('%','\\%'), c('$','\\$'),
                      c('#','\\#'), c('_','\\_'), c('{','\\{'), c('}','\\}')))
      x <- gsub(pair[1],pair[2],x,fixed=TRUE)
    x
  }
  cols <- c('비교대상','수익률(%)','MDD(%)','Sharpe','Sortino','Calmar')
  df <- df[, intersect(cols,names(df)),drop=FALSE]
  # 177mm usable width on A4: 51 + 25*5 = 176mm, with no auto word-break.
  latex_lines <- c('\\begin{center}',
                   '\\begingroup\\footnotesize',
                   '\\setlength{\\tabcolsep}{3pt}',
                   '\\renewcommand{\\arraystretch}{1.18}',
                   '\\begin{tabular}{@{}p{51mm}rrrrr@{}}',
                   '\\hline',
                   '비교대상 & 수익률(\\%) & MDD(\\%) & Sharpe & Sortino & Calmar \\\\',
                   '\\hline')
  for(i in seq_len(nrow(df))) {
    vals <- vapply(df[i,,drop=FALSE],function(x) tex_escape(x[[1]]),character(1))
    latex_lines <- c(latex_lines,paste0(paste(vals,collapse=' & '),' \\\\'))
  }
  latex_lines <- c(latex_lines,'\\hline','\\end{tabular}',
                   '\\endgroup','\\end{center}')
  paste(c('::: {.content-visible when-format="html"}', html,':::',
          '','::: {.content-visible when-format="pdf"}',
          '```{=latex}',latex_lines,'```',':::'),collapse='\n')
}
pms_report_write <- function(con, destination, include_benchmark=TRUE) {
  # Use a SQLite-consistent snapshot of the data available when the button is pressed.
  d <- pms_valuation(con,include_zero=FALSE)
  if(!nrow(d)) stop('보유종목 자료가 없어 보고서를 작성할 수 없습니다.')
  good <- is.finite(d$market_value_krw) & is.finite(d$quantity) & d$quantity>0
  gp <- good & is.finite(d$profit_krw) & is.finite(d$cost_basis_krw)
  nav <- if(any(good)) sum(d$market_value_krw[good]) else NA_real_
  pnl <- if(any(gp)) sum(d$profit_krw[gp]) else NA_real_
  cost <- if(any(gp)) sum(d$cost_basis_krw[gp]) else NA_real_
  ret <- if(is.finite(cost) && cost>0 && is.finite(pnl)) pnl/cost*100 else NA_real_
  nd <- sum(!good & d$quantity>0)
  active <- sum(d$quantity>0)
  amount <- function(x) pms_report_money(x)
  pct <- function(x) if(is.finite(x)) sprintf('%.2f%%',x) else '미산출'
  fmt_num <- function(x,dig=0) ifelse(is.finite(x),format(round(x,dig),big.mark=',',scientific=FALSE,trim=TRUE,nsmall=dig),'미확인')
  fx <- DBI::dbGetQuery(con,"SELECT rate,quoted_at FROM fx_rates WHERE pair='USD/KRW' LIMIT 1")
  fxtext <- if(nrow(fx) && is.finite(fx$rate[1])) sprintf('1 USD = %s KRW (저장 기준 %s)',fmt_num(fx$rate[1],2),fx$quoted_at[1]) else '유효한 USD/KRW 환율 없음'
  valid <- d[good,,drop=FALSE]
  sums <- function(group) {
    if(!nrow(valid)) return(data.frame())
    t <- aggregate(valid$market_value_krw,list(분류=as.character(group)),sum)
    names(t)[2] <- '평가액'
    t <- t[order(-t$평가액),,drop=FALSE]
    t$비중 <- if(is.finite(nav)&&nav>0) sprintf('%.2f%%',t$평가액/nav*100) else '미산출'
    t$평가액 <- vapply(t$평가액,amount,character(1))
    t
  }
  country <- sums(valid$country)
  country$분류 <- ifelse(country$분류=='KR','한국',ifelse(country$분류=='US','미국',country$분류))
  acc <- sums(valid$account_type)
  broker <- sums(valid$broker)
  top <- if(nrow(valid)) aggregate(valid$market_value_krw,list(종목=valid$name,코드=valid$symbol),sum) else data.frame()
  if(nrow(top)) {
    names(top)[3]<-'평가액'
    top<-top[order(-top$평가액),,drop=FALSE]
    top$비중<-if(is.finite(nav)&&nav>0) sprintf('%.2f%%',top$평가액/nav*100) else '미산출'
    top$평가액<-vapply(top$평가액,amount,character(1))
  }
  miss <- d[!good & d$quantity>0,c('country','symbol','name','quote_status'),drop=FALSE]
  names(miss)<-c('국가','종목코드','종목명','상태')
  date <- suppressWarnings(as.Date(substr(as.character(d$price_date),1,10)))
  stale <- d[d$quantity>0 & (is.na(date) | (as.integer(Sys.Date()-date)>4L)),c('name','symbol','price_date','price_source'),drop=FALSE]
  names(stale)<-c('종목명','종목코드','최근 시세 기준','수집 출처')
  div_account <- tryCatch(pms_dividend_account_totals(con),error=function(e) data.frame())
  div_month <- tryCatch(pms_dividend_monthly_accounts(con),error=function(e) data.frame())
  div_events <- tryCatch(pms_dividend_events(con),error=function(e) data.frame())
  div_total <- if(nrow(div_account) && '계좌유형' %in% names(div_account)) {
    v<-div_account$최근1년_배당금_원화_추정합계[div_account$계좌유형=='전체 합계'];if(length(v)) as.numeric(v[1]) else NA_real_
  } else NA_real_
  div_general <- if(nrow(div_account) && '계좌유형' %in% names(div_account)) {
    v<-div_account$최근1년_배당금_원화_추정합계[div_account$계좌유형=='일반계좌'];if(length(v)) as.numeric(v[1]) else NA_real_
  } else NA_real_
  if(nrow(div_month) && all(c('월','금액') %in% names(div_month))) {
    mo<-aggregate(as.numeric(div_month$금액),list(월=div_month$월),sum,na.rm=TRUE)
    names(mo)[2]<-'배당추정액'
    mo<-mo[order(mo$월),,drop=FALSE]
    mo$배당추정액<-vapply(mo$배당추정액,amount,character(1))
  } else mo<-data.frame()
  ndiv <- if(nrow(div_events)) nrow(div_events) else 0L
  bench <- tryCatch(if(include_benchmark) pms_benchmark_series(con) else NULL,error=function(e) NULL)
  stats <- if(is.list(bench) && is.data.frame(bench$statistics)) bench$statistics else data.frame()
  if(nrow(stats)) {
    for(j in seq_along(stats)) if(is.numeric(stats[[j]])) stats[[j]]<-fmt_num(stats[[j]],2)
  }
  # Wide benchmark tables break English metric headers in A4 PDF.
  # Separate performance figures and dates; retain the source values unchanged.
  benchmark_metrics <- data.frame()
  benchmark_dates <- data.frame()
  if(nrow(stats)) {
    metric_names <- intersect(c('비교대상','최근1년수익률_pct','MDD_pct','Sharpe','Sortino','Calmar'), names(stats))
    benchmark_metrics <- stats[,metric_names,drop=FALSE]
    short_names <- c('비교대상'='비교대상', '최근1년수익률_pct'='수익률(%)',
                     'MDD_pct'='MDD(%)', 'Sharpe'='Sharpe',
                     'Sortino'='Sortino', 'Calmar'='Calmar')
    names(benchmark_metrics) <- unname(short_names[names(benchmark_metrics)])
    date_names <- intersect(c('비교대상','시작일','종료일','거래일수'),names(stats))
    benchmark_dates <- stats[,date_names,drop=FALSE]
  }
  # Contributions are independently logged cash deposits; never infer from holdings.
  report_year <- as.integer(format(Sys.Date(), '%Y'))
  contrib <- tryCatch(pms_contrib_summary(con, report_year), error=function(e) NULL)
  contrib_rows <- tryCatch(pms_contrib_rows(con, report_year), error=function(e) data.frame())
  c_irp <- if(!is.null(contrib)) as.numeric(contrib$irp) else NA_real_
  c_pension <- if(!is.null(contrib)) as.numeric(contrib$pension) else NA_real_
  c_isa <- if(!is.null(contrib)) as.numeric(contrib$isa) else NA_real_
  c_carry <- if(!is.null(contrib)) as.numeric(contrib$carry) else 0
  progress <- function(value, limit) if(is.finite(value) && limit>0) sprintf('%.1f%%',100*value/limit) else '기록 없음'
  contrib_table <- data.frame(
    구분=c('IRP 개인 납입 목표','연금저축 개인 납입 목표','IRP+연금저축 납입 합산','연금계좌 합산 세액공제 참고','ISA 기본+이월 납입'),
    올해등록납입액=c(amount(c_irp),amount(c_pension),amount(c_irp+c_pension),amount(min(c_irp+c_pension,9000000)),amount(c_isa)),
    비교기준=c('9,000,000원','9,000,000원','18,000,000원','9,000,000원',amount(20000000+c_carry)),
    달성률=c(progress(c_irp,9000000),progress(c_pension,9000000),progress(c_irp+c_pension,18000000),progress(min(c_irp+c_pension,9000000),9000000),progress(c_isa,20000000+c_carry)),stringsAsFactors=FALSE)
  # Holding deltas are inferred, NOT broker-confirmed executions.
  trade_all <- tryCatch(pms_trades_changes(con),error=function(e) data.frame())
  cutoff <- Sys.Date()-365L
  if(nrow(trade_all)) {
    day <- suppressWarnings(as.Date(trade_all$date))
    trade_all <- trade_all[!is.na(day)&day>=cutoff&day<=Sys.Date(),,drop=FALSE]
  }
  if(nrow(trade_all)) {
    trade_all$분류 <- ifelse(grepl('온주전환',trade_all$kind),'온주전환 추정',ifelse(trade_all$change>0,'보유수량 증가(매수 추정)','보유수량 감소(매도 추정)'))
    # One conversion contributes a decrease and an increase; count separately as changes, not executions.
    trade_stats <- as.data.frame(table(trade_all$분류),stringsAsFactors=FALSE)
    names(trade_stats) <- c('보유변화구분','변동기록수')
    months <- aggregate(rep(1L,nrow(trade_all)),list(월=substr(trade_all$date,1,7),구분=trade_all$분류),sum)
    names(months)[3] <- '변동기록수'
    months <- months[order(months$월,months$구분),,drop=FALSE]
    recorded_days <- length(unique(trade_all$date))
  } else {trade_stats <- data.frame(); months <- data.frame();recorded_days <- 0L}
  ratio <- if(is.finite(div_general)) div_general/2e7*100 else NA_real_
  flags<-c(if(nd>0) sprintf('평가에 필요한 시세 또는 환율이 없어 %d건이 합계에서 제외됐습니다.',nd) else '현재 보유내역은 모두 가격 및 환율이 존재합니다.',
           if(nrow(stale)) sprintf('시세 기준일이 오래됐거나 확인되지 않는 보유내역 %d건은 거래정지나 상장폐지를 의미하지 않으며 별도 확인이 필요합니다.',nrow(stale)) else '시세 기준일 4일 초과 경고 대상이 없습니다.',
           '외부 입출금 및 매매 시점이 없어 현재 평가손익은 TWR, XIRR 또는 실현 운용수익률이 아닙니다.')
  lines <- c(
    '---','title: "PMS2 개인자산 종합 운용 보고서"',
    sprintf('date: "%s"',format(Sys.Date(),'%Y-%m-%d')),
    'lang: ko','format:','  html:','    toc: true','    toc-depth: 3','    number-sections: true','    theme: cosmo','    embed-resources: true',
    '  pdf:','    pdf-engine: xelatex','    documentclass: article','    papersize: a4','    fontsize: 9pt',
    '    mainfont: "Malgun Gothic"','    sansfont: "Malgun Gothic"','    monofont: "Consolas"',
    '    geometry:','      - top=18mm','      - bottom=18mm','      - left=13mm','      - right=13mm',
    '    toc: true','    toc-depth: 2','    number-sections: true',
    'execute:','  echo: false','---','',
    '> **보고서 성격**: PMS2 SQLite에 보관된 마지막 시세, 보유종목, 배당 이벤트, 과거 종가 캐시를 바탕으로 한 자동 생성 투자 현황 보고서입니다. 매수·매도 권고가 아닙니다. 현금·예수금·외부 입출금이 없어 총 금융자산 또는 실제 투자성과와 다를 수 있습니다.','',
    '# 경영 요약 (Executive Summary)','',
    sprintf('본 보고서는 %s에 생성했습니다. 현재 보유종목 입력 건수는 **%d건**이며, 유효한 시세와 환율로 평가 가능한 건수는 **%d건**입니다. 보유 종목 수와 보유 행의 개수는 다를 수 있습니다.',format(Sys.time(),'%Y-%m-%d %H:%M'),active,sum(good)),'',
    sprintf('저장된 시세로 산정된 **증권 평가액은 %s**, 평가 가능한 취득원가 기준 **미실현 평가손익은 %s**, 취득원가 대비 수익률은 **%s**입니다.',amount(nav),amount(pnl),pct(ret)),'',
    paste(flags,collapse=' '),'',
    '# 평가기준 및 자료 신뢰성','',
    '## 데이터 출처와 시점','',
    'PMS2는 보유종목 테이블과 마지막으로 저장된 가격을 결합해 평가합니다. 이 보고서를 생성하는 동안 quantmod·네이버·Yahoo 등 외부 API에 접근하지 않았습니다. 이미 SQLite에 저장된 각 종목의 기준일이 서로 다를 수 있습니다.','',
    sprintf('원화 환산에 사용한 환율: **%s**.',fxtext),'',
    '미국 주식은 달러 가격에 저장된 원달러 환율을 곱하며, 한국 주식 및 국내 상장 ETF는 원화 평가를 적용합니다. 가격 갱신시각과 가격의 실제 거래 기준일은 별개입니다.','',
    '## 평가가 불완전한 항목','',pms_report_table(miss,50),'',
    '## 오래된 시세 점검','',
    sprintf('현재 보유내역 중 %d건의 가격 기준일이 4일을 초과하거나 날짜 확인이 어렵습니다. 달력 기준 단순 경과일이며, 주말·휴장일을 포함합니다. 상장폐지 판정은 아닙니다.',nrow(stale)),'',
    pms_report_table(stale,40),'',
    '# 자산 규모와 수익성','',
    sprintf('전체 평가액 **%s**는 현금과 예수금이 제외된 증권성 자산의 합계입니다.',amount(nav)),'',
    sprintf('현재 취득원가를 확인할 수 있는 항목의 기준원가는 **%s**이며 평가손익은 **%s**입니다. 일부 매입원가는 브로커 입력값이 아닌 평균매수가 × 평균매입환율로 추정한 값일 수 있습니다.',amount(cost),amount(pnl)),'',
    '평가손익은 아직 매도하지 않은 보유종목의 미실현 손익입니다. 실현손익, 수수료, 양도소득세, 거래세, 환전 비용과 외부 자금 유입은 모두 별도로 관리해야 정확한 운용성과를 산정할 수 있습니다.','',
    '# 자산 배분 점검','',
    '## 국가별 보유 비중','',pms_report_table(country),'',
    '한국과 미국 자산은 서로 다른 통화와 정책 위험에 노출될 수 있습니다. 국가는 상장국 기준 분류이며 국내 상장 미국지수 ETF의 기초자산 노출까지 반영한 경제적 국가 비중과는 다릅니다.','',
    '## 계좌유형별 보유 비중','',pms_report_table(acc),'',
    '일반계좌, ISA, IRP, 연금저축은 과세·인출 제약이 다릅니다. 동일한 증권 평가액이어도 계좌유형에 따라 활용 가능한 현금흐름은 달라질 수 있습니다.','',
    '## 증권사별 분포','',pms_report_table(broker),'',
    '증권사별 보유분산은 운영상 위험과 자금 접근성 판단에 도움이 되지만, 직접적인 투자시장 위험 분산과 동일하지 않습니다.','',
    '## 평가액 상위 종목','',pms_report_table(top,20),'',
    '상위 종목에 평가액이 집중되어 있다면 개별 종목 변동이 전체 평가액을 크게 흔들 수 있습니다. 여기의 비중은 현재 저장된 평가액의 합계에 대한 비율이며 평가 불가능 종목을 제외합니다.','',
    '# 배당과 현금흐름 분석','',
    sprintf('최근 365일의 과거 배당 이벤트를 현재 보유수량에 적용한 **세전 배당 추정액은 %s**입니다. 이는 해당 기간에 실제로 받았던 배당금이 아닙니다.',amount(div_total)),'',
    sprintf('현재 SQLite에서 확인된 배당 이벤트 상세 행 수는 **%d건**입니다. 이벤트 행 수와 종목 수 또는 실제 계좌 입금 건수는 서로 다릅니다.',ndiv),'',
    '## 계좌유형별 배당 추정','',pms_report_table(div_account,30),'',
    '## 최근 12개월 월별 배당 추정','',pms_report_table(mo,15),'',
    '과거 배당락일을 기준으로 월에 귀속시켰기 때문에 실제 지급일 및 계좌 입금 월과 차이가 날 수 있습니다. 환율과 보유수량 역시 과거 실제 지급 당시의 상황을 온전히 재현하지 못할 수 있습니다.','',
    '# 금융소득종합과세 참고 지표','',
    sprintf('일반계좌 최근 365일 **추정 배당금은 %s**이며, 2,000만 원을 단순 참고선으로 두면 **%s**에 해당합니다.',amount(div_general),pct(ratio)),'',
    '이는 **세법상 신고·판정 금액이 아닙니다**. 금융소득종합과세는 해당 과세연도(1~12월)의 이자소득과 배당소득 전체를 검토해야 하고, 원천징수, 계좌별 과세 특례, 분배금 과세 구성 등을 따로 확인해야 합니다.','',
    '# 절세계좌 납입관리 및 세제 안내','',
    sprintf('조회 과세연도는 **%d년**입니다. 납입액은 PMS2에 직접 등록한 자료만 합산하므로 기록이 없을 때 실제 납입이 0원이라는 뜻은 아닙니다.',report_year),'',
    '연금저축·IRP 등의 **개인 추가납입 합산한도 1,800만 원**과 **세액공제 합산한도 900만 원**은 구분해야 합니다. 연금저축 납입분 중 세액공제 대상은 최대 600만 원입니다. IRP 900만 원과 연금저축 900만 원은 사용자 개인의 관리 목표이며 각각 독립된 세액공제 한도가 아닙니다.','',
    'ISA는 연 2,000만 원 기본 납입한도와 미사용 한도 이월을 구분합니다. ISA 납입에는 연금계좌와 같은 납입액 세액공제가 적용되는 것이 아닙니다. 최신 세법과 계좌별 조건은 별도 확인이 필요합니다.','',
    '## 당해 연도 절세계좌 납입 진도','',pms_report_table(contrib_table),'',
    sprintf('현재 등록된 납입 행은 **%d건**입니다. 계좌 간 이동, 시장평가액, 배당금 또는 매매대금을 납입금으로 임의 추정하지 않았습니다.',nrow(contrib_rows)),'',
    '## 등록 납입내역','',pms_report_table(contrib_rows,30),'',
    '# 최근 1년 보유수량 변화 및 매매 추정 통계','',
    sprintf('조회기간은 **%s ~ %s**이며, 보유수량 변화가 확인된 날짜는 **%d일**, 변동 행은 **%d건**입니다.',format(cutoff,'%Y-%m-%d'),format(Sys.Date(),'%Y-%m-%d'),recorded_days,nrow(trade_all)),'',
    '이 내역은 과거 엑셀 및 일별 스냅샷의 보유수량을 비교한 **매매 추정치**이며 실제 증권사 체결내역이나 거래대금이 아닙니다. 누락된 기록일 사이 거래, 이체·주식분할·온주전환, 계좌 식별 변경 등이 영향을 줄 수 있습니다. 온주전환은 매도로 간주하지 않습니다.','',
    '## 변화 유형별 기록 수','',pms_report_table(trade_stats),'',
    '## 월별 보유수량 변동 기록','',pms_report_table(months,48),'',
    '변동 기록 수는 거래 체결 건수와 다르며 동일한 온주전환에서 소수점 감소와 일반주 증가가 각각 한 행으로 나타날 수 있습니다. 실제 매수·매도 손익과 회전율을 확정하려면 체결내역이 추가로 필요합니다.','',
    '# 벤치마크 및 위험 분석','',
    '아래 통계는 현재 보유수량을 과거에도 동일하게 보유했다고 가정하는 가상 백테스트에 기반합니다. 실제 매매이력, 외부 현금흐름, 세금, 수수료와 배당 재투자는 가격수익률 분석에 반영되지 않습니다.','',
    '## 수익률 및 위험지표','',pms_report_benchmark_metrics(benchmark_metrics),'',
    '## 비교기간 및 거래일수','',pms_report_table(benchmark_dates,10),'',
    if(!nrow(stats)) '충분한 과거 주가 데이터가 저장돼 있지 않으면 벤치마크 표가 생성되지 않습니다. 벤치마크 탭에서 과거 종가를 수집한 뒤 보고서를 다시 생성할 수 있습니다.' else 'Sharpe는 변동성 대비 성과, Sortino는 하방 위험 대비 성과, MDD는 최대낙폭을 나타냅니다. 동일 비교기간과 계산가정이 충족되는지 살펴야 합니다.','',
    '# 위험 요인과 후속 점검','',
    '## 시장 및 집중 위험','',
    '상위 보유종목과 국가·계좌별 비중을 기준으로 시장 급락 시 자산가치 변동과 현금 확보 필요성을 점검할 수 있습니다. 다만 현재 자료만으로 미래 가격이나 손실 규모를 확정할 수는 없습니다.','',
    '## 환율 위험','',
    '미국 상장 종목의 원화평가액은 달러 주가뿐 아니라 원달러 환율에도 영향을 받습니다. 평균 매입환율과 취득원가가 정확히 입력되지 않았다면 평가손익 중 환율 기여도를 분해하는 데 오차가 생깁니다.','',
    '## 배당 정보의 정확도','',
    '일부 ETF·종목은 과거 분배금 정보가 누락될 수 있습니다. 배당 수집 실패나 미수집을 배당금 0원과 동일하게 취급하지 말고 해당 종목을 별도로 점검해야 합니다.','',
    '## 데이터 품질 우선순위','',
    '첫째, 오래된 시세와 누락 환율을 확인합니다. 둘째, 브로커의 실제 취득원가 및 매입환율을 검증합니다. 셋째, 배당락일이 아닌 실제 지급일·입금액을 수집합니다. 넷째, 현금 및 외부 자금 흐름을 기록하면 실제 TWR·XIRR 등 운용성과 분석이 가능해집니다.','',
    '# 종합 의견','',
    sprintf('현재 PMS2는 **%d건 보유내역**을 기준으로 평가와 배당 추정을 제공하고 있습니다. 시세 평가 완전성과 취득원가 정확도가 모든 이후 분석의 출발점입니다.',active),'',
    '이번 보고서는 저장된 사실과 계산 가능한 수치를 먼저 제시하고, 해석상 한계를 별도로 구분했습니다. 불충분한 자료에서 투자 권고나 미래 수익률을 단정하지 않습니다.','',
    '---','',
    sprintf('**생성 시각:** %s  |  **원본 자료:** 로컬 PMS2 SQLite  |  **외부 조회:** 없음',format(Sys.time(),'%Y-%m-%d %H:%M:%S')),''
  )
  writeLines(lines,destination,useBytes=TRUE)
  invisible(list(file=destination,nav=nav,pnl=pnl,rows=active,missing=nd))
}
