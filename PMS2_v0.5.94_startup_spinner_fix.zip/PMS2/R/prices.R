# PMS2 v0.2.4 - Windows curl.exe JSON transport, source diagnostics and SSL flag consistency.
# Requires DBI, jsonlite and Windows curl.exe. TLS verification is enabled by default.
# Use PMS_SSL_NO_REVOKE=1 only when permitted by the network security policy.

pms_utc_now <- function() format(Sys.time(), '%Y-%m-%d %H:%M:%S', tz='UTC')
pms_num <- function(x) {
  if (is.null(x) || !length(x)) return(NA_real_)
  suppressWarnings(as.numeric(gsub(',', '', as.character(x[[1]]), fixed=TRUE)))
}

init_market_tables <- function(con) {
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS prices (
    country TEXT NOT NULL, symbol TEXT NOT NULL, price REAL NOT NULL,
    currency TEXT NOT NULL, source TEXT NOT NULL,
    quoted_at TEXT, fetched_at TEXT NOT NULL,
    PRIMARY KEY(country,symbol))")
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS fx_rates (
    pair TEXT PRIMARY KEY, rate REAL NOT NULL, source TEXT NOT NULL,
    quoted_at TEXT, fetched_at TEXT NOT NULL)")
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS collection_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, run_at TEXT NOT NULL,
    country TEXT, symbol TEXT, status TEXT NOT NULL,
    source TEXT, detail TEXT)")
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS symbol_mapping (
    country TEXT NOT NULL, symbol TEXT NOT NULL, naver_code TEXT NOT NULL,
    confirmed_at TEXT, PRIMARY KEY(country,symbol))")
  # Keep a per-trading-date close/quote history for the previous-close ticker.
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS quote_daily_archive (
    country TEXT NOT NULL, symbol TEXT NOT NULL, quote_date TEXT NOT NULL,
    price REAL NOT NULL, source TEXT, captured_at TEXT NOT NULL,
    PRIMARY KEY(country,symbol,quote_date))")
  invisible(TRUE)
}

pms_log <- function(con,country,symbol,status,source='',detail='') {
  DBI::dbExecute(con,"INSERT INTO collection_log
    (run_at,country,symbol,status,source,detail) VALUES(?,?,?,?,?,?)",
    params=list(pms_utc_now(),country,symbol,status,source,substr(detail,1,1200)))
}

# Transport based on working PMS1 JSON endpoints; keep TLS chain/hostname verification enabled.
# HTTP transport: Windows curl.exe default verification, optionally Schannel
# revocation-check fallback ONLY when explicitly enabled in the application.
pms_http_json <- function(url, timeout=10L, ssl_no_revoke=FALSE) {
  if (!grepl('^https://[A-Za-z0-9.-]+(/|$|\\?)',url)) stop('Invalid HTTPS URL')
  exe <- Sys.which('curl.exe')
  if (!nzchar(exe)) stop('curl.exe not found')
  path <- tempfile(fileext='.json'); on.exit(unlink(path),add=TRUE)
  errfile <- tempfile(fileext='.txt'); on.exit(unlink(errfile),add=TRUE)
  args <- c(if (isTRUE(ssl_no_revoke) && .Platform$OS.type=='windows') '--ssl-no-revoke',
            '-L','-sS','--connect-timeout','5','--max-time',as.character(timeout),
            '-H',shQuote('User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
            '-H',shQuote('Accept: application/json'),
            '-w',shQuote('%{http_code}'),'-o',shQuote(path),shQuote(url))
  code <- tryCatch(suppressWarnings(system2(exe,args,stdout=TRUE,stderr=errfile)),error=function(e)e)
  errbytes <- if (file.exists(errfile)) readBin(errfile,'raw',n=file.info(errfile)$size) else raw(0)
  # Avoid substr() on unknown locale-encoded stderr (previous multibyte crash).
  errtext <- if(length(errbytes)) paste(sprintf('%02X',as.integer(head(errbytes,120L))),collapse=' ') else ''
  if(inherits(code,'error')) stop('CURL_EXECUTION_ERROR: ',conditionMessage(code))
  exitcode <- attr(code,'status'); if(is.null(exitcode)) exitcode <- 0L
  httpcode <- suppressWarnings(as.integer(tail(code,1)))
  if(exitcode != 0L) {
    if(exitcode==60L) stop('SSL_CERTIFICATE_ERROR (curl 60). stderr_hex=',errtext)
    if(exitcode==35L) stop('SSL_HANDSHAKE_ERROR (curl 35; possible revocation check). stderr_hex=',errtext)
    stop('CURL_ERROR ',exitcode,' stderr_hex=',errtext)
  }
  if(is.na(httpcode) || httpcode<200L || httpcode>=300L) {
    if(identical(httpcode,429L)) stop('HTTP_429_RATE_LIMIT')
    stop('HTTP_',if(is.na(httpcode)) 'UNKNOWN' else httpcode)
  }
  if(!file.exists(path) || file.info(path)$size==0L) stop('EMPTY_RESPONSE')
  obj <- tryCatch(jsonlite::fromJSON(path,simplifyVector=FALSE),error=function(e)e)
  if(inherits(obj,'error')) stop('INVALID_JSON: ',conditionMessage(obj))
  attr(obj,'http_status') <- httpcode
  attr(obj,'ssl_mode') <- if(isTRUE(ssl_no_revoke)) 'REVOCATION_CHECK_SKIPPED' else 'VERIFIED'
  obj
}

pms_get_json <- function(url,timeout=10L) {
  mode <- identical(Sys.getenv('PMS_SSL_NO_REVOKE',unset='0'),'1')
  pms_http_json(url,timeout,ssl_no_revoke=mode)
}

# Separate probes deliberately do not depend on holdings or foreign symbol mapping.
pms_diagnose_sources <- function(ssl_no_revoke=FALSE,on_step=NULL) {
  cases <- list(
    list(target='국내주식',provider='NAVER KR',url='https://m.stock.naver.com/api/stock/000660/basic',parse=function(x) pms_num(x$closePrice)),
    list(target='미국주식',provider='NAVER US',url='https://api.stock.naver.com/stock/NVDA.O/basic',parse=function(x) pms_num(x$closePrice)),
    list(target='미국주식',provider='YAHOO',url='https://query1.finance.yahoo.com/v8/finance/chart/AAPL',parse=function(x) pms_num(x$chart$result[[1]]$meta$regularMarketPrice)),
    list(target='환율',provider='NAVER FX',url='https://api.stock.naver.com/marketindex/exchange/FX_USDKRW',parse=function(x) pms_num(x$exchangeInfo$closePrice))
  )
  out <- lapply(cases,function(z) {
    if(is.function(on_step)) on_step(z,'start')
    t0 <- proc.time()[['elapsed']]
    r <- tryCatch(pms_http_json(z$url,timeout=8L,ssl_no_revoke=ssl_no_revoke),error=function(e)e)
    elapsed <- round(proc.time()[['elapsed']]-t0,2)
    if(inherits(r,'error')) {
      msg <- conditionMessage(r)
      kind <- if(grepl('SSL_|CERTIFICATE|revocation',msg,ignore.case=TRUE)) 'SSL' else
        if(grepl('429|RATE_LIMIT',msg)) 'HTTP 429' else if(grepl('HTTP_',msg)) 'HTTP' else '연결/파싱'
      row <- data.frame(대상=z$target,공급원=z$provider,결과='실패',SSL오류=if(kind=='SSL') '예' else '아니오',인증서폐기확인=if(isTRUE(ssl_no_revoke)) '생략' else '수행',
         HTTP상태=if(kind=='HTTP 429') '429' else '-',조회값='-',소요초=elapsed,실패원인=msg,
         실패단계=if(kind=='SSL') 2L else if(kind %in% c('HTTP 429','HTTP')) 3L else 4L,check.names=FALSE)
      if(is.function(on_step)) on_step(z,'done',row)
      return(row)
    }
    value <- tryCatch(z$parse(r),error=function(e) NA_real_)
    ok <- is.finite(value) && value>0
    row <- data.frame(대상=z$target,공급원=z$provider,결과=if(ok) '성공' else '실패',SSL오류='아니오',인증서폐기확인=if(isTRUE(ssl_no_revoke)) '생략' else '수행',
       HTTP상태=as.character(attr(r,'http_status')),조회값=if(ok) format(value,big.mark=',',scientific=FALSE,trim=TRUE) else '-',
       소요초=elapsed,실패원인=if(ok) {if(isTRUE(ssl_no_revoke)) '인증서 폐기 확인만 생략' else ''} else '응답 수신 후 가격 파싱 실패',
       실패단계=if(ok) 5L else 5L,check.names=FALSE)
    if(is.function(on_step)) on_step(z,'done',row)
    row
  })
  do.call(rbind,out)
}

pms_naver_kr_quote <- function(symbol) {
  code <- sub('\\.(KS|KQ)$','',toupper(trimws(symbol)))
  if (!grepl('^[0-9A-Z]{6}$',code)) stop('KR Naver code must be 6 alphanumeric characters')
  obj <- pms_get_json(paste0('https://m.stock.naver.com/api/stock/',code,'/basic'))
  if (!is.null(obj$itemCode) && !identical(as.character(obj$itemCode),code)) stop('Naver KR symbol mismatch')
  price <- pms_num(if (!is.null(obj$closePriceRaw)) obj$closePriceRaw else obj$closePrice)
  if (!is.finite(price) || price<=0) stop('Naver KR price missing')
  list(price=price,source='NAVER_KR',quoted_at=if(is.null(obj$localTradedAt)) NA_character_ else as.character(obj$localTradedAt),
       naver_code=code)
}

pms_naver_us_code_quote <- function(symbol, code) {
  url <- paste0('https://api.stock.naver.com/stock/',
                utils::URLencode(code,reserved=TRUE),'/basic')
  obj <- pms_get_json(url)
  # API fields differ across stock categories. Accept only explicit ticker/code verification.
  remote_symbol <- if (!is.null(obj$symbolCode)) toupper(as.character(obj$symbolCode)) else character()
  remote_code <- if (!is.null(obj$reutersCode)) toupper(as.character(obj$reutersCode)) else character()
  expected <- toupper(trimws(as.character(symbol)))
  ticker_matches <- length(remote_symbol)==1L && identical(remote_symbol,expected)
  code_matches <- length(remote_code)==1L && identical(remote_code,toupper(code))
  if (!ticker_matches && !code_matches) stop('Naver US ticker/reutersCode verification failed')
  if (!is.null(obj$nationType) && !identical(as.character(obj$nationType),'USA'))
    stop('Naver US nationType mismatch')
  price <- pms_num(if (!is.null(obj$closePriceRaw)) obj$closePriceRaw else obj$closePrice)
  if(!is.finite(price) || price<=0) stop('Naver US price missing')
  list(price=price,source='NAVER_US',quoted_at=if(is.null(obj$localTradedAt)) NA_character_ else as.character(obj$localTradedAt),
       naver_code=code)
}

pms_naver_us_quote <- function(con, symbol) {
  symbol <- toupper(trimws(symbol))
  m <- DBI::dbGetQuery(con,'SELECT naver_code FROM symbol_mapping WHERE country=? AND symbol=?',
                        params=list('US',symbol))
  # Naver identifiers vary by exchange, ETF and listing; try candidates and
  # *verify* the JSON symbolCode. No assumed mapping is stored on failure.
  candidates <- unique(c(if(nrow(m)) m$naver_code, paste0(symbol,c('.O','.N','.A','.K','.P'))))
  errors <- character()
  for(code in candidates) {
    r <- tryCatch(pms_naver_us_code_quote(symbol,code),error=function(e)e)
    if(!inherits(r,'error')) {
      DBI::dbExecute(con,"INSERT INTO symbol_mapping(country,symbol,naver_code,confirmed_at)
        VALUES('US',?,?,?) ON CONFLICT(country,symbol) DO UPDATE SET
        naver_code=excluded.naver_code, confirmed_at=excluded.confirmed_at",
        params=list(symbol,code,pms_utc_now()))
      return(r)
    }
    errors <- c(errors,paste(code,conditionMessage(r),sep=': '))
    # A TLS/429/network problem is not evidence that the suffix is wrong.
    if(!grepl('HTTP_404|ticker/reutersCode verification failed|Naver US symbol mismatch',
              conditionMessage(r),ignore.case=TRUE)) break
  }
  stop(paste(errors,collapse=' | '))
}

# Yahoo Chart JSON API (PMS1 stock_eval_us verified approach), not getSymbols.
pms_yahoo_quote <- function(country,symbol) {
  code <- toupper(trimws(as.character(symbol)))
  if(country=='KR' && grepl('^[0-9]{6}$',code)) code <- paste0(code,'.KS')
  url <- paste0('https://query1.finance.yahoo.com/v8/finance/chart/',
    utils::URLencode(code,reserved=TRUE),
    '?range=5d&interval=1d&includePrePost=false')
  obj <- pms_get_json(url)
  result <- obj$chart$result
  if(is.null(result)||!length(result)) stop(paste('Yahoo ticker unavailable:',code))
  item <- result[[1]]
  price <- pms_num(item$meta$regularMarketPrice)
  if(!is.finite(price) || price<=0) {
    closes <- suppressWarnings(as.numeric(unlist(item$indicators$quote[[1]]$close)))
    closes <- closes[is.finite(closes) & closes>0]
    if(length(closes)) price <- tail(closes,1)
  }
  if(!is.finite(price) || price<=0) stop('Yahoo valid price missing')
  quoted <- item$meta$regularMarketTime
  quoted_at <- if(!is.null(quoted) && length(quoted) && is.finite(as.numeric(quoted)))
    format(as.POSIXct(as.numeric(quoted),origin='1970-01-01',tz='UTC'),'%Y-%m-%d %H:%M:%S',tz='UTC')
    else NA_character_
  list(price=price,source='YAHOO_CHART',quoted_at=quoted_at)
}

# Optional primary provider: quantmod (Yahoo historical daily adjusted close).
# Does NOT require quantmod when the existing Naver/Yahoo JSON fallback works.
pms_quantmod_symbols <- function(country,symbol) {
  base <- toupper(trimws(as.character(symbol)))
  if(country=='KR' && grepl('^[0-9]{6}$',base)) return(paste0(base,c('.KS','.KQ')))
  base
}

pms_quantmod_quote <- function(country,symbol) {
  if(!requireNamespace('quantmod',quietly=TRUE)) stop('quantmod package is not installed')
  failures <- character()
  for(code in pms_quantmod_symbols(country,symbol)) {
    z <- tryCatch(suppressWarnings(quantmod::getSymbols(
      code,src='yahoo',from=Sys.Date()-15L,to=Sys.Date()+1L,
      auto.assign=FALSE,warnings=FALSE)),error=function(e)e)
    if(inherits(z,'error')) {
      failures <- c(failures,paste0(code,': ',conditionMessage(z))); next
    }
    if(!inherits(z,'xts') || NROW(z)<1L) {failures <- c(failures,paste0(code,': empty xts'));next}
    px <- tryCatch(as.numeric(quantmod::Cl(z)),error=function(e) numeric())
    dates <- as.Date(zoo::index(z))
    good <- which(is.finite(px) & px>0 & !is.na(dates))
    if(!length(good)) {failures<-c(failures,paste0(code,': no valid close'));next}
    last <- tail(good,1L)
    if(as.Date(Sys.Date())-dates[last]>10L) {failures<-c(failures,paste0(code,': quote too old'));next}
    return(list(price=px[last],source='QUANTMOD_YAHOO',quoted_at=paste0(dates[last],' 00:00:00')))
  }
  stop(paste(failures,collapse=' / '))
}

pms_get_quote <- function(country,symbol,con=NULL,allow_yahoo=TRUE) {
  country <- toupper(country)
  # Optional primary source; failures retain the exact legacy Naver/Yahoo fallback.
  qm <- tryCatch(pms_quantmod_quote(country,symbol),error=function(e)e)
  if(!inherits(qm,'error')) return(qm)
  # Use the paths that work in PMS1: Korea NAVER JSON, US Yahoo Chart JSON.
  # A failure triggers a single alternative attempt when enabled.
  if(country=='KR') {
    primary <- tryCatch(pms_naver_kr_quote(symbol),error=function(e)e)
    if(!inherits(primary,'error')) return(primary)
    if(!isTRUE(allow_yahoo)) stop(paste('NAVER:',conditionMessage(primary)))
    alternate <- tryCatch(pms_yahoo_quote(country,symbol),error=function(e)e)
    if(!inherits(alternate,'error')) return(alternate)
    stop(paste('NAVER:',conditionMessage(primary),' / YAHOO:',conditionMessage(alternate)))
  }
  if(country=='US') {
    primary <- if(!is.null(con)) tryCatch(pms_naver_us_quote(con,symbol),error=function(e)e) else simpleError('DB required for Naver symbol mapping')
    if(!inherits(primary,'error')) return(primary)
    if(!isTRUE(allow_yahoo)) stop(paste('NAVER:',conditionMessage(primary)))
    alternate <- tryCatch(pms_yahoo_quote(country,symbol),error=function(e)e)
    if(!inherits(alternate,'error')) return(alternate)
    stop(paste('NAVER:',conditionMessage(primary),' / YAHOO:',conditionMessage(alternate)))
  }
  stop('Unsupported country')
}

pms_store_quote <- function(con,country,symbol,currency,q) {
  # Only archive dated, valid quotes; do not turn stale delisted prices into a new date.
  qt <- as.character(q$quoted_at)
  qdate <- if(length(qt) && !is.na(qt[1])) substr(qt[1],1L,10L) else ''
  if(grepl('^[0-9]{4}-[0-9]{2}-[0-9]{2}$',qdate) &&
     is.finite(as.numeric(q$price)) && as.numeric(q$price)>0) {
    DBI::dbExecute(con,"INSERT INTO quote_daily_archive
      (country,symbol,quote_date,price,source,captured_at) VALUES (?,?,?,?,?,?)
      ON CONFLICT(country,symbol,quote_date) DO UPDATE SET
      price=excluded.price,source=excluded.source,captured_at=excluded.captured_at",
      params=list(country,symbol,qdate,as.numeric(q$price),as.character(q$source),pms_utc_now()))
  }
  DBI::dbExecute(con,"INSERT INTO prices(country,symbol,price,currency,source,quoted_at,fetched_at)
    VALUES(?,?,?,?,?,?,?) ON CONFLICT(country,symbol) DO UPDATE SET
    price=excluded.price,currency=excluded.currency,source=excluded.source,
    quoted_at=excluded.quoted_at,fetched_at=excluded.fetched_at",
    params=list(country,symbol,q$price,currency,q$source,q$quoted_at,pms_utc_now()))
}

# USD/KRW from working PMS1 Naver exchange endpoint.
pms_collect_fx <- function(con) {
  j <- pms_get_json('https://api.stock.naver.com/marketindex/exchange/FX_USDKRW')
  if(is.null(j$exchangeInfo)) stop('Naver USD/KRW exchangeInfo missing')
  fx <- pms_num(j$exchangeInfo$closePrice)
  if(!is.finite(fx)||fx<=0) stop('Invalid USD/KRW rate')
  quoted <- if(!is.null(j$exchangeInfo$localTradedAt))
    as.character(j$exchangeInfo$localTradedAt) else NA_character_
  DBI::dbExecute(con,"INSERT INTO fx_rates(pair,rate,source,quoted_at,fetched_at)
    VALUES('USD/KRW',?,?,?,?) ON CONFLICT(pair) DO UPDATE SET
    rate=excluded.rate,source=excluded.source,quoted_at=excluded.quoted_at,
    fetched_at=excluded.fetched_at",
    params=list(fx,'NAVER_FX',quoted,pms_utc_now()))
  list(rate=fx,source='NAVER_FX',quoted_at=quoted)
}

pms_collect_prices <- function(con,progress=NULL,allow_yahoo=TRUE,on_result=NULL) {
  init_market_tables(con)
  targets <- DBI::dbGetQuery(con,"SELECT country,symbol,MIN(currency) AS currency
    FROM holdings WHERE quantity>0 AND country IN ('KR','US')
    GROUP BY country,symbol ORDER BY country,symbol")
  out <- vector('list',nrow(targets))
  consecutive_failures <- 0L
  successes <- 0L
  for(i in seq_len(nrow(targets))) {
    t <- targets[i,,drop=FALSE]
    q <- tryCatch(pms_get_quote(t$country,t$symbol,con,allow_yahoo),error=function(e)e)
    if(inherits(q,'error')) {
      pms_log(con,t$country,t$symbol,'FAILED','',conditionMessage(q))
      consecutive_failures <- consecutive_failures + 1L
      out[[i]] <- data.frame(country=t$country,symbol=t$symbol,status='FAILED',
                             source='',price=NA_real_,message=conditionMessage(q))
    } else {
      consecutive_failures <- 0L
      successes <- successes + 1L
      pms_store_quote(con,t$country,t$symbol,t$currency,q)
      pms_log(con,t$country,t$symbol,'OK',q$source,'')
      out[[i]] <- data.frame(country=t$country,symbol=t$symbol,status='OK',
                             source=q$source,price=as.numeric(q$price),message='')
    }
    if(is.function(on_result)) on_result(out[[i]],i,nrow(targets))
    if(is.function(progress)) progress(i,nrow(targets),paste(t$country,t$symbol))
    # Circuit breaker: if the first three DISTINCT instruments all fail,
    # stop before wasting minutes on the remaining portfolio. This does not
    # prove an outage; inspect the failure log to distinguish code/TLS issues.
    if (i>=3L && successes==0L && consecutive_failures>=3L) {
      stop('첫 3개 종목 모두 실패하여 수집을 중단했습니다. 종목코드 또는 네이버/Yahoo 연결 문제를 확인하세요. 이미 저장된 시세는 삭제하지 않았습니다.')
    }
  }
  fx <- tryCatch(pms_collect_fx(con),error=function(e)e)
  if(inherits(fx,'error')) pms_log(con,'FX','USD/KRW','FAILED','',conditionMessage(fx))
  else pms_log(con,'FX','USD/KRW','OK',fx$source,
               paste('reference rate:',fx$rate,'at:',fx$quoted_at))
  if(!length(out)) return(data.frame(country=character(),symbol=character(),
                                    status=character(),source=character(),price=numeric(),message=character()))
  do.call(rbind,out)
}
