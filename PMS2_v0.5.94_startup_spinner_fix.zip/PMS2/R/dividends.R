# PMS2 dividend history: Yahoo chart corporate actions, trailing 365 days.
# Historical cash dividend per share; NOT actual dividends received by account.
# Yahoo coverage, especially KR ETFs, may be incomplete. Never convert an API error into zero dividends.

pms_init_dividend_tables <- function(con) {
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS dividend_events (
    country TEXT NOT NULL, symbol TEXT NOT NULL, ex_date TEXT NOT NULL,
    amount REAL NOT NULL, currency TEXT NOT NULL, source TEXT NOT NULL,
    fetched_at TEXT NOT NULL, PRIMARY KEY(country,symbol,ex_date,source))")
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS usdkrw_daily (
    rate_date TEXT PRIMARY KEY, rate REAL NOT NULL, source TEXT NOT NULL,
    fetched_at TEXT NOT NULL)")
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS dividend_fetch_status (
    country TEXT NOT NULL, symbol TEXT NOT NULL, status TEXT NOT NULL,
    events_count INTEGER, source TEXT, detail TEXT, fetched_at TEXT NOT NULL,
    PRIMARY KEY(country,symbol))")
}

# Optional quantmod primary dividend feed; falls back to original Yahoo Chart JSON
# if quantmod is unavailable, raises an error, or returns unusable results.
pms_dividend_quantmod <- function(country,symbol,from=Sys.Date()-365L,to=Sys.Date()) {
  if(!requireNamespace('quantmod',quietly=TRUE)) stop('quantmod package is not installed')
  errors <- character()
  for(code in pms_quantmod_symbols(country,symbol)) {
    z <- tryCatch(suppressWarnings(quantmod::getDividends(
      code,src='yahoo',from=from,to=to+1L,auto.assign=FALSE)),error=function(e)e)
    if(inherits(z,'error')) {errors<-c(errors,paste(code,conditionMessage(z),sep=': '));next}
    if(is.null(z) || !inherits(z,'xts')) {
      errors<-c(errors,paste0(code,': no reliable dividend data'));next
    }
    d <- data.frame(ex_date=as.character(as.Date(zoo::index(z))),
      amount=as.numeric(zoo::coredata(z)),stringsAsFactors=FALSE)
    d <- unique(d[!is.na(d$ex_date) & is.finite(d$amount) & d$amount>0 &
      d$ex_date>=as.character(from) & d$ex_date<=as.character(to),,drop=FALSE])
    return(list(events=d,source=paste0('QUANTMOD_YAHOO:',code)))
  }
  stop(paste(errors,collapse=' / '))
}

pms_dividend_with_fallback <- function(country,symbol,from=Sys.Date()-365L,to=Sys.Date()) {
  primary <- tryCatch(pms_dividend_quantmod(country,symbol,from,to),error=function(e)e)
  if(!inherits(primary,'error')) return(primary)
  backup <- tryCatch(pms_dividend_yahoo(country,symbol,from,to),error=function(e)e)
  if(!inherits(backup,'error')) return(backup)
  stop(paste0('quantmod: ',conditionMessage(primary), ' / Yahoo JSON: ',conditionMessage(backup)))
}

pms_dividend_yahoo <- function(country,symbol,from=Sys.Date()-365L,to=Sys.Date()) {
  base <- toupper(trimws(as.character(symbol)))
  codes <- if(country=='KR' && grepl('^[0-9]{6}$',base)) paste0(base,c('.KS','.KQ')) else base
  since <- as.integer(as.POSIXct(from,tz='UTC'))
  until <- as.integer(as.POSIXct(to+1L,tz='UTC'))
  errors <- character()
  for(code in codes) {
    url <- paste0('https://query1.finance.yahoo.com/v8/finance/chart/',
      utils::URLencode(code,reserved=TRUE),'?period1=',since,'&period2=',until,
      '&interval=1d&events=div&includeAdjustedClose=false')
    x <- tryCatch(pms_get_json(url,timeout=12L),error=function(e)e)
    if(inherits(x,'error')) {
      errors <- c(errors,paste0(code,': ',conditionMessage(x)))
      next
    }
    result <- x$chart$result
    if(is.null(result)||!length(result)) {
      errors <- c(errors,paste0(code,': 차트 결과 없음'))
      next
    }
    chart <- result[[1]]
    returned <- toupper(as.character(chart$meta$symbol %||% ''))
    if(!identical(returned,toupper(code))) {
      errors <- c(errors,paste0(code,': 종목코드 불일치 (',returned,')'))
      next
    }
    ev <- chart$events$dividends
    if(is.null(ev)||!length(ev)) {
      return(list(events=data.frame(ex_date=character(),amount=numeric(),stringsAsFactors=FALSE),
                  source=paste0('YAHOO:',code)))
    }
    rows <- lapply(ev,function(item) {
      ts <- suppressWarnings(as.numeric(item$date %||% NA_real_))
      val <- suppressWarnings(as.numeric(item$amount %||% NA_real_))
      if(!is.finite(ts)||!is.finite(val)||val<=0) return(NULL)
      data.frame(ex_date=format(as.POSIXct(ts,origin='1970-01-01',tz='UTC'),'%Y-%m-%d',tz='UTC'),
                 amount=val,stringsAsFactors=FALSE)
    })
    rows <- Filter(Negate(is.null),rows)
    d <- if(length(rows)) do.call(rbind,rows) else data.frame(ex_date=character(),amount=numeric())
    d <- unique(d[d$ex_date>=as.character(from) & d$ex_date<=as.character(to),,drop=FALSE])
    return(list(events=d,source=paste0('YAHOO:',code)))
  }
  stop(paste(errors,collapse=' / '))
}
`%||%` <- function(a,b) if(is.null(a)||!length(a)) b else a

# Fetch past daily USD/KRW rates (Yahoo symbol KRW=X = KRW per 1 USD).
# Only verified daily closing data are saved; do not manufacture missing rates.
pms_collect_usdkrw_daily <- function(con, from=Sys.Date()-365L, to=Sys.Date()) {
  pms_init_dividend_tables(con)
  start <- from - 12L # prior business day for early ex-dates
  period1 <- as.integer(as.POSIXct(start,tz='UTC'))
  period2 <- as.integer(as.POSIXct(to+1L,tz='UTC'))
  url <- sprintf('https://query1.finance.yahoo.com/v8/finance/chart/KRW=X?period1=%s&period2=%s&interval=1d',period1,period2)
  x <- pms_get_json(url,timeout=20L)
  r <- x$chart$result
  if(is.null(r)||!length(r)) stop('USD/KRW 일별 차트 데이터 없음')
  chart <- r[[1]]
  symbol <- toupper(as.character(chart$meta$symbol %||% ''))
  if(symbol != 'KRW=X') stop(sprintf('환율 종목코드 불일치: %s',symbol))
  ts <- unlist(chart$timestamp,use.names=FALSE)
  raw_close <- chart$indicators$quote[[1]]$close
  close <- if(is.list(raw_close)) vapply(raw_close,function(v) {
    if(is.null(v) || !length(v)) return(NA_real_)
    suppressWarnings(as.numeric(v[[1]]))
  },numeric(1)) else suppressWarnings(as.numeric(raw_close))
  if(!length(ts) || length(ts)!=length(close)) stop('USD/KRW 날짜/종가 데이터 없음 또는 길이 불일치')
  df <- data.frame(rate_date=format(as.POSIXct(as.numeric(ts),origin='1970-01-01',tz='UTC'),'%Y-%m-%d',tz='UTC'),
                   rate=suppressWarnings(as.numeric(close)),stringsAsFactors=FALSE)
  df <- df[is.finite(df$rate) & df$rate>0 & df$rate_date>=as.character(start) & df$rate_date<=as.character(to),,drop=FALSE]
  df <- df[!duplicated(df$rate_date,fromLast=TRUE),,drop=FALSE]
  if(!nrow(df)) stop('USD/KRW 정상 종가가 없습니다')
  now <- pms_utc_now()
  DBI::dbWithTransaction(con, {
    for(i in seq_len(nrow(df))) DBI::dbExecute(con,
      'INSERT INTO usdkrw_daily(rate_date,rate,source,fetched_at) VALUES(?,?,?,?)
       ON CONFLICT(rate_date) DO UPDATE SET rate=excluded.rate,source=excluded.source,fetched_at=excluded.fetched_at',
       params=list(df$rate_date[i],df$rate[i],'YAHOO:KRW=X',now))
  })
  nrow(df)
}

pms_collect_dividends <- function(con,on_result=NULL) {
  pms_init_dividend_tables(con)
  targets <- DBI::dbGetQuery(con,"SELECT country,symbol,MIN(currency) AS currency
    FROM holdings WHERE quantity>0 AND country IN ('KR','US')
    GROUP BY country,symbol ORDER BY country,symbol")
  out <- vector('list',nrow(targets))
  since <- Sys.Date()-365L
  now <- pms_utc_now()
  for(i in seq_len(nrow(targets))) {
    t <- targets[i,,drop=FALSE]
    country <- as.character(t$country); sym <- as.character(t$symbol)
    result <- tryCatch(pms_dividend_with_fallback(country,sym,from=since),error=function(e)e)
    if(inherits(result,'error')) {
      msg <- conditionMessage(result)
      DBI::dbExecute(con,"INSERT INTO dividend_fetch_status(country,symbol,status,events_count,source,detail,fetched_at)
       VALUES(?,?,'FAILED',NULL,'QUANTMOD/YAHOO',?,?) ON CONFLICT(country,symbol) DO UPDATE SET
       status=excluded.status,events_count=excluded.events_count,source=excluded.source,
       detail=excluded.detail,fetched_at=excluded.fetched_at",params=list(country,sym,msg,now))
      out[[i]] <- data.frame(country=country,symbol=sym,status='FAILED',count=NA_integer_,detail=msg)
    } else {
      d <- result$events
      # Replace only after a confirmed successful API response, never on error.
      DBI::dbWithTransaction(con, {
        DBI::dbExecute(con,"DELETE FROM dividend_events WHERE country=? AND symbol=?",params=list(country,sym))
        if(nrow(d)) for(k in seq_len(nrow(d))) {
          DBI::dbExecute(con,"INSERT INTO dividend_events(country,symbol,ex_date,amount,currency,source,fetched_at)
            VALUES(?,?,?,?,?,?,?)",params=list(country,sym,d$ex_date[k],d$amount[k],as.character(t$currency),result$source,now))
        }
        DBI::dbExecute(con,"INSERT INTO dividend_fetch_status(country,symbol,status,events_count,source,detail,fetched_at)
          VALUES(?,?,'OK',?,?,?,?) ON CONFLICT(country,symbol) DO UPDATE SET
          status=excluded.status,events_count=excluded.events_count,source=excluded.source,
          detail=excluded.detail,fetched_at=excluded.fetched_at",
          params=list(country,sym,nrow(d),result$source,if(nrow(d)) '최근 365일 배당 이벤트 조회 성공' else '조회 성공 · 배당 이벤트 0건 (미지급/제공 누락 가능)',now))
      })
      out[[i]] <- data.frame(country=country,symbol=sym,status='OK',count=nrow(d),detail=result$source)
    }
    if(is.function(on_result)) on_result(out[[i]],i,nrow(targets))
  }
  if(!length(out)) return(data.frame(country=character(),symbol=character(),status=character(),count=integer(),detail=character()))
  do.call(rbind,out)
}

# For US dividends use the closing USD/KRW rate on the ex-date; if there is
# no FX quote that day, the most recent preceding trading day (max 7 days).
# This is a historical ex-date estimate, NOT broker payment-day FX or tax amount.
pms_dividend_summary <- function(con) {
  pms_init_dividend_tables(con)
  DBI::dbGetQuery(con,"SELECT h.country AS 국가,h.symbol AS 종목코드,h.name AS 종목명,
    h.currency AS 통화,COALESCE(s.status,'미수집') AS 조회상태,
    s.events_count AS 배당횟수,
    CASE WHEN s.status='OK' THEN ROUND(COALESCE(e.total,0),6) ELSE NULL END AS 연간_주당배당금_합계,
    CASE WHEN h.country='KR' AND s.status='OK' THEN ROUND(COALESCE(e.total,0),2)
         WHEN h.country='US' AND s.status='OK' AND COALESCE(e.fx_missing,0)=0
         THEN ROUND(COALESCE(e.total_krw,0),2) ELSE NULL END AS 연간_주당배당금_원화_합계,
    CASE WHEN h.country!='US' THEN '원화 배당'
         WHEN s.status!='OK' OR s.status IS NULL THEN '배당 조회 전/실패'
         WHEN COALESCE(e.fx_missing,0)>0 THEN '환율 누락'
         WHEN COALESCE(s.events_count,0)=0 THEN '배당 이벤트 0건'
         ELSE '환산 완료' END AS 원화환산상태,
    p.price AS 최근저장시세, p.quoted_at AS 시세기준일,
    CASE WHEN s.status='OK' AND p.price>0 AND COALESCE(e.fx_missing,0)=0
         THEN ROUND(100.0*COALESCE(e.total,0)/p.price,2) ELSE NULL END AS 최근1년_세전_배당수익률_퍼센트,
    s.source AS 출처,s.detail AS 상세,s.fetched_at AS 조회시각_UTC
    FROM (SELECT country,symbol,MIN(name) AS name,MIN(currency) AS currency
       FROM holdings WHERE quantity>0 AND country IN ('KR','US') GROUP BY country,symbol) h
    LEFT JOIN prices p ON p.country=h.country AND p.symbol=h.symbol
    LEFT JOIN dividend_fetch_status s ON h.country=s.country AND h.symbol=s.symbol
    LEFT JOIN (SELECT country,symbol,SUM(amount) AS total,
       SUM(CASE WHEN country='US' THEN amount * fx_rate ELSE NULL END) AS total_krw,
       SUM(CASE WHEN country='US' AND fx_rate IS NULL THEN 1 ELSE 0 END) AS fx_missing
       FROM (SELECT de.*,
         (SELECT rate FROM usdkrw_daily fx WHERE fx.rate_date<=de.ex_date
          AND fx.rate_date>=date(de.ex_date,'-7 days') ORDER BY fx.rate_date DESC LIMIT 1) AS fx_rate
         FROM dividend_events de WHERE de.ex_date >= date('now','-365 days'))
       GROUP BY country,symbol) e
       ON h.country=e.country AND h.symbol=e.symbol
    ORDER BY h.country,h.symbol")
}

pms_dividend_events <- function(con) {
  pms_init_dividend_tables(con)
  DBI::dbGetQuery(con,"SELECT d.country AS 국가,d.symbol AS 종목코드,COALESCE(h.name,d.symbol) AS 종목명,d.ex_date AS 배당락일,
    d.amount AS 주당배당금,d.currency AS 통화,
    CASE WHEN d.country='US' THEN fx.rate_date ELSE NULL END AS 적용환율일,
    CASE WHEN d.country='US' THEN ROUND(fx.rate,4) ELSE NULL END AS 해당배당일환율,
    CASE WHEN d.country='KR' THEN ROUND(d.amount,2)
         WHEN d.country='US' AND fx.rate IS NOT NULL THEN ROUND(d.amount*fx.rate,2)
         ELSE NULL END AS 주당배당금_원화,
    CASE WHEN d.country!='US' THEN '원화 환산 불필요'
         WHEN fx.rate IS NULL THEN '환율 누락'
         WHEN fx.rate_date=d.ex_date THEN '배당락일 종가'
         ELSE '직전 거래일 종가' END AS 환산기준,
    d.source AS 배당출처
    FROM dividend_events d
    LEFT JOIN (SELECT country,symbol,MIN(name) AS name FROM holdings WHERE quantity>0 GROUP BY country,symbol) h
      ON h.country=d.country AND h.symbol=d.symbol
    LEFT JOIN usdkrw_daily fx ON fx.rate_date=(
      SELECT f.rate_date FROM usdkrw_daily f
      WHERE f.rate_date<=d.ex_date AND f.rate_date>=date(d.ex_date,'-7 days')
      ORDER BY f.rate_date DESC LIMIT 1)
    WHERE d.ex_date >= date('now','-365 days')
    ORDER BY d.ex_date DESC,d.country,d.symbol")
}


# Trailing-year cash dividend estimate based on CURRENT holdings quantities.
# NOT actual past cash flow: quantities at ex-dates, payment-date FX, taxes and
# withholding cannot be reconstructed from a current-position table.
# Missing provider/FX data is never interpreted as zero.
pms_dividend_account_totals <- function(con) {
  pms_init_dividend_tables(con)
  x <- DBI::dbGetQuery(con, "SELECT h.id AS holding_id,h.country,h.symbol,
    COALESCE(h.account_type,'') AS account_type,h.quantity,
    COALESCE(s.status,'미수집') AS status,
    COALESCE(e.event_count,0) AS event_count,
    COALESCE(e.unconverted,0) AS unconverted,
    CASE WHEN s.status='OK' THEN COALESCE(e.annual_krw_per_share,0) ELSE NULL END AS annual_krw_per_share
    FROM holdings h
    LEFT JOIN dividend_fetch_status s ON s.country=h.country AND s.symbol=h.symbol
    LEFT JOIN (
      SELECT z.country,z.symbol,COUNT(*) AS event_count,
        SUM(CASE WHEN z.country='US' AND z.fx_rate IS NULL THEN 1 ELSE 0 END) AS unconverted,
        SUM(CASE WHEN z.country='KR' THEN z.amount
                 WHEN z.country='US' AND z.fx_rate IS NOT NULL THEN z.amount*z.fx_rate
                 ELSE NULL END) AS annual_krw_per_share
      FROM (SELECT d.*,
         (SELECT f.rate FROM usdkrw_daily f
          WHERE f.rate_date<=d.ex_date AND f.rate_date>=date(d.ex_date,'-7 days')
          ORDER BY f.rate_date DESC LIMIT 1) AS fx_rate
        FROM dividend_events d WHERE d.ex_date>=date('now','-365 days')) z
      GROUP BY z.country,z.symbol
    ) e ON e.country=h.country AND e.symbol=h.symbol
    WHERE h.quantity>0 AND h.country IN ('KR','US')")
  accounts <- c('GENERAL','IRP','ISA','PENSION')
  labels <- c(GENERAL='일반계좌',IRP='IRP',ISA='ISA',PENSION='연금저축',OTHER='기타/미분류')
  if(nrow(x)) {
    x$account_type <- toupper(trimws(as.character(x$account_type)))
    x$group <- ifelse(x$account_type %in% accounts,x$account_type,'OTHER')
    x$valid <- x$status=='OK' & x$unconverted==0 & is.finite(x$annual_krw_per_share)
    x$valid[is.na(x$valid)] <- FALSE
    x$amount <- ifelse(x$valid, x$quantity*x$annual_krw_per_share, NA_real_)
  }
  out <- lapply(c('ALL',accounts,'OTHER'),function(g) {
    sub <- if(nrow(x) && g!='ALL') x[x$group==g,,drop=FALSE] else x
    if(!nrow(sub)) return(data.frame(계좌유형=if(g=='ALL') '전체 합계' else labels[[g]],
      보유건수=0L,계산완료건수=0L,미완료건수=0L,최근1년_배당금_원화_추정합계=NA_real_,집계상태='보유 없음'))
    ok <- sub$valid
    data.frame(계좌유형=if(g=='ALL') '전체 합계' else labels[[g]],
      보유건수=nrow(sub),계산완료건수=sum(ok),미완료건수=sum(!ok),
      최근1년_배당금_원화_추정합계=if(any(ok)) round(sum(sub$amount[ok]),0) else NA_real_,
      집계상태=if(all(ok)) '완료' else '일부 미조회/환율 누락 (표시 합계는 확인분만)',
      stringsAsFactors=FALSE)
  })
  do.call(rbind,out)
}


# Past 12 calendar months, per-account monthly *estimate* using current quantities.
# Date is EX-date, not cash payment date. The local FX rate table is reused;
# no HTTP calls are made when drawing or re-drawing the chart.
pms_dividend_monthly_accounts <- function(con) {
  pms_init_dividend_tables(con)
  # Build months using first-of-month sequence (stable at month ends).
  current <- as.Date(format(Sys.Date(),'%Y-%m-01'))
  months <- format(seq(current,by='-1 month',length.out=12),'%Y-%m')
  months <- rev(months)
  groups <- c('일반계좌','IRP','ISA','연금저축','기타/미분류')
  sql <- "SELECT substr(d.ex_date,1,7) AS month, h.account_type, h.quantity,
           d.country, d.amount,
           (SELECT f.rate FROM usdkrw_daily f
            WHERE f.rate_date<=d.ex_date AND f.rate_date>=date(d.ex_date,'-7 days')
            ORDER BY f.rate_date DESC LIMIT 1) AS fx_rate
          FROM dividend_events d INNER JOIN holdings h
            ON h.country=d.country AND h.symbol=d.symbol
          WHERE h.quantity>0 AND h.country IN ('KR','US')
            AND d.ex_date>=? AND d.ex_date<=date('now')"
  raw <- DBI::dbGetQuery(con,sql,params=list(paste0(months[1],'-01')))
  out <- expand.grid(월=months,계좌유형=groups,stringsAsFactors=FALSE)
  out$금액 <- 0
  out$환율누락건수 <- 0L
  if(nrow(raw)) {
    acct <- toupper(trimws(ifelse(is.na(raw$account_type),'',raw$account_type)))
    g <- ifelse(acct=='GENERAL','일반계좌',ifelse(acct=='IRP','IRP',
         ifelse(acct=='ISA','ISA',ifelse(acct=='PENSION','연금저축','기타/미분류'))))
    amount_krw <- ifelse(raw$country=='KR',raw$amount,raw$amount*raw$fx_rate)
    missing <- raw$country=='US' & (!is.finite(raw$fx_rate) | is.na(raw$fx_rate))
    for (i in seq_len(nrow(raw))) {
      idx <- which(out$월==raw$month[i] & out$계좌유형==g[i])
      if (!length(idx)) next
      if (isTRUE(missing[i])) {
        out$환율누락건수[idx] <- out$환율누락건수[idx]+1L
      } else if (is.finite(amount_krw[i]) && is.finite(raw$quantity[i])) {
        out$금액[idx] <- out$금액[idx]+as.numeric(amount_krw[i])*as.numeric(raw$quantity[i])
      }
    }
  }
  out$금액 <- round(out$금액,0)
  out[order(match(out$월,months),match(out$계좌유형,groups)),,drop=FALSE]
}


# Estimated dividend calendar: move historic EX-dates ahead one calendar year.
# Not a published upcoming dividend / payment date; historic amounts are NOT forecasts.
# Do not query remote APIs; use previously stored dividends, FX and current holdings.
pms_dividend_forecast_30d <- function(con, today=Sys.Date(), days=30L) {
  pms_init_dividend_tables(con)
  cols <- c('예상_배당락일','국가','종목코드','종목명','작년_배당락일',
            '작년_주당배당금','통화','작년_주당배당금_원화',
            '현재_보유수량_합계','작년_배당금_원화_보유량기준','예상근거')
  empty <- data.frame(matrix(ncol=length(cols),nrow=0),check.names=FALSE)
  names(empty) <- cols
  today <- as.Date(today)
  cutoff <- today+as.integer(days)
  # Separate aggregated holdings before joining events, to avoid duplicate events
  # when one security occurs across multiple accounts.
  sql <- "SELECT d.country,d.symbol, h.name, h.quantity,
            d.ex_date,d.amount,d.currency,
            (SELECT f.rate FROM usdkrw_daily f
              WHERE f.rate_date<=d.ex_date AND f.rate_date>=date(d.ex_date,'-7 days')
              ORDER BY f.rate_date DESC LIMIT 1) AS rate
          FROM dividend_events d JOIN (
            SELECT country,symbol,MIN(name) AS name,SUM(quantity) AS quantity
            FROM holdings WHERE quantity>0 AND country IN ('KR','US')
            GROUP BY country,symbol
          ) h ON d.country=h.country AND d.symbol=h.symbol
          WHERE d.ex_date >= ? AND d.ex_date<=?"
  # Historic ex-dates for the month ahead one calendar year in the future.
  # Extra 8 days protects leap-year boundary; exact window checked after shifting.
  prior_from <- format(today-373L,'%Y-%m-%d')
  prior_to <- format(today-335L,'%Y-%m-%d')
  x <- DBI::dbGetQuery(con,sql,params=list(prior_from,prior_to))
  if(!nrow(x)) return(empty)
  shifted <- vapply(x$ex_date,function(d) {
    yr <- as.integer(substr(d,1,4))+1L
    candidate <- sprintf('%04d-%s',yr,substr(d,6,10))
    date <- suppressWarnings(as.Date(candidate,format='%Y-%m-%d'))
    if(is.na(date)||format(date,'%Y-%m-%d')!=candidate) return(NA_character_)
    format(date,'%Y-%m-%d')
  },character(1))
  ok <- !is.na(shifted) & shifted>as.character(today) & shifted<=as.character(cutoff)
  x <- x[ok,,drop=FALSE]
  shifted <- shifted[ok]
  if(!nrow(x)) return(empty)
  krw <- ifelse(x$country=='KR',x$amount,
                ifelse(is.finite(x$rate),x$amount*x$rate,NA_real_))
  total <- krw*x$quantity
  data <- data.frame(
    예상_배당락일=shifted, 국가=x$country, 종목코드=x$symbol,
    종목명=x$name, 작년_배당락일=x$ex_date,
    작년_주당배당금=round(x$amount,6), 통화=x$currency,
    작년_주당배당금_원화=round(krw,2),
    현재_보유수량_합계=x$quantity,
    작년_배당금_원화_보유량기준=round(total,0),
    예상근거='전년 배당락일 + 1년 (미확정)',
    check.names=FALSE,stringsAsFactors=FALSE)
  data[order(data$예상_배당락일,data$종목코드),,drop=FALSE]
}
