# v0.5.64: SQLite daily snapshots plus exactly one per-date holdings CSV.
pms_snapshot_init <- function(con) {
  DBI::dbExecute(con,"CREATE TABLE IF NOT EXISTS snapshot_daily (
    snapshot_date TEXT PRIMARY KEY, snapshot_at TEXT NOT NULL,
    securities_value_krw REAL, cost_basis_krw REAL, unrealized_pnl_krw REAL,
    unrealized_return_pct REAL, usdkrw_rate REAL,
    holdings_count INTEGER, valued_count INTEGER, missing_quote_count INTEGER,
    snapshot_status TEXT NOT NULL, cash_krw REAL, external_flow_krw REAL)")
  DBI::dbExecute(con,"CREATE TABLE IF NOT EXISTS snapshot_accounts (
    snapshot_date TEXT NOT NULL, broker TEXT NOT NULL, account_type TEXT NOT NULL,
    account_number TEXT NOT NULL, securities_value_krw REAL, cost_basis_krw REAL,
    unrealized_pnl_krw REAL, holdings_count INTEGER,
    PRIMARY KEY(snapshot_date,broker,account_type,account_number))")
  DBI::dbExecute(con,"CREATE TABLE IF NOT EXISTS snapshot_holdings (
    snapshot_date TEXT NOT NULL, holding_id INTEGER NOT NULL,
    country TEXT, symbol TEXT, name TEXT, currency TEXT, asset_class TEXT,
    tax_type TEXT, broker TEXT, account_type TEXT, account_number TEXT,
    fractional_share INTEGER, quantity REAL, avg_price REAL, avg_fx_rate REAL,
    cost_basis_krw REAL, cost_basis_source TEXT, current_price REAL,
    price_date TEXT, price_source TEXT, fx_rate REAL, market_value_krw REAL,
    unrealized_pnl_krw REAL, return_pct REAL, quote_status TEXT,
    PRIMARY KEY(snapshot_date,holding_id))")
  invisible(TRUE)
}
pms_snapshot_history <- function(con) {
  pms_snapshot_init(con)
  DBI::dbGetQuery(con,"SELECT snapshot_date AS 날짜, securities_value_krw AS 증권평가액_원,
    unrealized_pnl_krw AS 평가손익_원, unrealized_return_pct AS 수익률_퍼센트,
    holdings_count AS 보유건수, valued_count AS 정상평가건수,
    missing_quote_count AS 누락건수, snapshot_status AS 상태,
    snapshot_at AS 저장시각 FROM snapshot_daily ORDER BY snapshot_date DESC")
}
pms_snapshot_save <- function(con,date=as.Date(Sys.time(),tz='Asia/Seoul')) {
  pms_snapshot_init(con)
  day <- format(as.Date(date),'%Y-%m-%d')
  d <- pms_valuation(con,include_zero=FALSE)
  if(!nrow(d)) stop('보유종목이 없어 스냅샷을 생성하지 않습니다.')
  good <- is.finite(d$market_value_krw) & d$quantity>0
  cost_good <- good & is.finite(d$cost_basis_krw) & is.finite(d$profit_krw)
  nav <- if(any(good)) sum(d$market_value_krw[good]) else NA_real_
  cost <- if(any(cost_good)) sum(d$cost_basis_krw[cost_good]) else NA_real_
  pnl <- if(any(cost_good)) sum(d$profit_krw[cost_good]) else NA_real_
  n <- sum(d$quantity>0); valued <- sum(good); missing <- n-valued
  status <- if(missing==0L && any(good)) 'COMPLETE' else 'PARTIAL'
  fx <- DBI::dbGetQuery(con,"SELECT rate FROM fx_rates WHERE pair='USD/KRW' LIMIT 1")
  fxval <- if(nrow(fx)) as.numeric(fx$rate[1]) else NA_real_
  recorded <- format(Sys.time(),'%Y-%m-%d %H:%M:%S %z',tz='Asia/Seoul')
  pct <- if(is.finite(cost) && cost>0 && is.finite(pnl)) pnl/cost*100 else NA_real_
  daily <- data.frame(snapshot_date=day,snapshot_at=recorded,
    securities_value_krw=nav,cost_basis_krw=cost,unrealized_pnl_krw=pnl,
    unrealized_return_pct=pct,usdkrw_rate=fxval,holdings_count=n,
    valued_count=valued,missing_quote_count=missing,snapshot_status=status,
    cash_krw=NA_real_,external_flow_krw=NA_real_)
  detail <- data.frame(snapshot_date=day,holding_id=d$id,country=d$country,
    symbol=d$symbol,name=d$name,currency=d$currency,asset_class=d$asset_class,
    tax_type=d$tax_type,broker=d$broker,account_type=d$account_type,
    account_number=d$account_number,fractional_share=d$fractional_share,
    quantity=d$quantity,avg_price=d$avg_price,avg_fx_rate=d$avg_fx_rate,
    cost_basis_krw=d$cost_basis_krw,cost_basis_source=d$cost_basis_source,
    current_price=d$current_price,price_date=d$price_date,price_source=d$price_source,
    fx_rate=d$fx_current,market_value_krw=d$market_value_krw,
    unrealized_pnl_krw=d$profit_krw,return_pct=d$return_pct,
    quote_status=d$quote_status,stringsAsFactors=FALSE)
  account_key <- c('broker','account_type','account_number')
  ids <- unique(detail[account_key]); accounts <- ids
  accounts$snapshot_date <- day
  accounts$securities_value_krw <- NA_real_
  accounts$cost_basis_krw <- NA_real_
  accounts$unrealized_pnl_krw <- NA_real_
  accounts$holdings_count <- integer(nrow(accounts))
  for(i in seq_len(nrow(accounts))) {
    ix <- detail$broker==accounts$broker[i] & detail$account_type==accounts$account_type[i] &
      detail$account_number==accounts$account_number[i]
    accounts$holdings_count[i] <- sum(ix,na.rm=TRUE)
    valid <- ix & is.finite(detail$market_value_krw)
    cp <- valid & is.finite(detail$cost_basis_krw) & is.finite(detail$unrealized_pnl_krw)
    if(any(valid)) accounts$securities_value_krw[i] <- sum(detail$market_value_krw[valid])
    if(any(cp)) {
      accounts$cost_basis_krw[i] <- sum(detail$cost_basis_krw[cp])
      accounts$unrealized_pnl_krw[i] <- sum(detail$unrealized_pnl_krw[cp])
    }
  }
  accounts <- accounts[c('snapshot_date',account_key,'securities_value_krw',
                          'cost_basis_krw','unrealized_pnl_krw','holdings_count')]
  # Atomic per-day replacement. Previously recorded dates are never rewritten.
  DBI::dbWithTransaction(con,{
    DBI::dbExecute(con,'DELETE FROM snapshot_holdings WHERE snapshot_date=?',params=list(day))
    DBI::dbExecute(con,'DELETE FROM snapshot_accounts WHERE snapshot_date=?',params=list(day))
    DBI::dbExecute(con,'DELETE FROM snapshot_daily WHERE snapshot_date=?',params=list(day))
    DBI::dbWriteTable(con,'snapshot_daily',daily,append=TRUE,row.names=FALSE)
    DBI::dbWriteTable(con,'snapshot_accounts',accounts,append=TRUE,row.names=FALSE)
    DBI::dbWriteTable(con,'snapshot_holdings',detail,append=TRUE,row.names=FALSE)
  })
  # One dated CSV per day, updated atomically. No date subdirectories.
  dir.create('snapshots',showWarnings=FALSE,recursive=TRUE)
  final_csv <- file.path('snapshots',paste0(day,'.csv'))
  temp_csv <- tempfile(pattern=paste0('.',day,'_'),tmpdir='snapshots',fileext='.csv')
  utils::write.csv(detail,temp_csv,row.names=FALSE,fileEncoding='UTF-8',na='')
  # Windows file.rename does not reliably overwrite an existing destination.
  if(file.exists(final_csv)) file.remove(final_csv)
  if(!file.rename(temp_csv,final_csv)) {
    if(!file.copy(temp_csv,final_csv,overwrite=TRUE)) stop('일별 종목별 CSV 파일 저장 실패')
    unlink(temp_csv)
  }
  invisible(list(date=day,status=status,holdings=n,valued=valued))
}
