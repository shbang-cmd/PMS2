# PMS2 holdings Excel export / safe bulk import, v0.5.90
pms_excel_fields <- c('id','country','symbol','name','currency','asset_class','tax_type',
                      'broker','account_type','account_number','fractional_share','quantity',
                      'avg_price','avg_fx_rate','cost_krw','memo','updated_at')

pms_holdings_excel_export <- function(con, file) {
  if (!requireNamespace('writexl', quietly=TRUE))
    stop("엑셀 다운로드에는 writexl 패키지가 필요합니다: install.packages('writexl')")
  x <- DBI::dbGetQuery(con, paste0('SELECT ',paste(pms_excel_fields, collapse=', '), ' FROM holdings ORDER BY id'))
  # Editable identifiers must remain TEXT in Excel, including leading zeros.
  for (k in c('country','symbol','name','currency','asset_class','tax_type','broker',
              'account_type','account_number','memo','updated_at')) x[[k]] <- as.character(x[[k]])
  guide <- data.frame(
    항목=c('편집 방법','ID','새 종목','삭제','계좌번호 / 종목코드','소수점 주식','원화 취득원가','주의'),
    설명=c('보유종목 시트에서 값 수정 후 업로드하세요. 열 제목은 바꾸지 마세요.',
           '기존 행의 id는 절대 수정하지 마세요. id가 있는 행은 해당 레코드만 수정합니다.',
           '신규 등록은 id와 updated_at을 비워 새 행을 추가하세요.',
           '엑셀에서 행을 지워도 DB의 기존 보유내역은 삭제되지 않습니다.',
           '기존 문자열 그대로 유지하세요. 앞자리 0이 포함된 종목코드/계좌번호를 숫자로 바꾸지 마세요.',
           'fractional_share는 0(일반주식), 1(소수점 주식)입니다.',
           'cost_krw는 공란 허용, 다른 숫자 필드는 유효한 숫자를 입력하세요.',
           '가져오기 전에 미리보기 검증 및 확인을 거칩니다. 파일에 계좌번호 등 개인정보가 포함됩니다.'),
    stringsAsFactors=FALSE)
  writexl::write_xlsx(list('보유종목'=x,'사용안내'=guide),path=file)
}

pms_excel_number <- function(v, label, row, optional=FALSE) {
  s <- trimws(as.character(v)); if (is.na(v) || identical(s,'')) {
    if (optional) return(NA_real_)
    stop(sprintf('%d행 %s: 숫자가 비어 있습니다.',row,label))
  }
  n <- suppressWarnings(as.numeric(gsub(',','',s,fixed=TRUE)))
  if (!is.finite(n)) stop(sprintf('%d행 %s: 올바른 숫자가 아닙니다 (%s).',row,label,s))
  n
}

pms_holdings_excel_validate <- function(con, path) {
  if (!requireNamespace('readxl',quietly=TRUE)) stop("엑셀 업로드에는 readxl 패키지가 필요합니다: install.packages('readxl')")
  sheets <- readxl::excel_sheets(path)
  if (!('보유종목' %in% sheets)) stop("'보유종목' 시트가 없습니다. PMS2에서 내려받은 원본 서식을 이용하세요.")
  # Read as text: do not lose leading zeros from symbol/account_number.
  raw <- as.data.frame(readxl::read_excel(path,sheet='보유종목',col_types='text',na='', .name_repair='minimal'),stringsAsFactors=FALSE)
  if (anyDuplicated(names(raw)) || !setequal(names(raw),pms_excel_fields))
    stop(paste('엑셀 열 이름이 원본과 다릅니다. 필요한 열:',paste(pms_excel_fields,collapse=', ')))
  raw <- raw[,pms_excel_fields,drop=FALSE]
  if (!nrow(raw)) stop('업로드할 데이터가 없습니다.')
  # Empty rows are ignored. Partial rows are still validated and rejected.
  keep <- apply(raw[,setdiff(pms_excel_fields,c('id','updated_at')),drop=FALSE],1,function(r) any(!is.na(r) & nzchar(trimws(r))))
  raw <- raw[keep,,drop=FALSE]
  if (!nrow(raw)) stop('보유종목 데이터가 없습니다.')
  if (nrow(raw)>10000L) stop('보안을 위해 한 번에 10,000행까지만 업로드할 수 있습니다.')
  old <- DBI::dbGetQuery(con,'SELECT * FROM holdings')
  oldids <- as.character(old$id)
  ids <- trimws(as.character(raw$id)); ids[is.na(ids)] <- ''
  validids <- nzchar(ids)
  if (any(validids & !grepl('^[0-9]+$',ids))) stop('ID는 기존 양의 정수이거나 공란이어야 합니다.')
  if (anyDuplicated(ids[validids])) stop('엑셀에 중복된 ID가 있습니다.')
  if (any(!ids[validids] %in% oldids)) stop('데이터베이스에 없는 ID가 있습니다. 신규 입력 시 ID를 비우세요.')
  records <- vector('list',nrow(raw)); action <- character(nrow(raw)); changed <- logical(nrow(raw))
  natural <- character(nrow(raw))
  norm <- function(v) if(is.na(v)) '' else trimws(as.character(v))
  for (i in seq_len(nrow(raw))) {
    row <- i+1L # column header is row 1
    r <- raw[i,,drop=FALSE]
    v <- function(k) norm(r[[k]][1])
    for (k in c('country','symbol','currency','asset_class','tax_type','broker','account_type','account_number'))
      if (!nzchar(v(k))) stop(sprintf('%d행 %s 항목은 필수입니다.',row,k))
    country <- toupper(v('country')); currency <- toupper(v('currency')); symbol <- toupper(v('symbol'))
    if (!country %in% c('KR','US')) stop(sprintf('%d행 country는 KR 또는 US여야 합니다.',row))
    if (!currency %in% c('KRW','USD')) stop(sprintf('%d행 currency는 KRW 또는 USD여야 합니다.',row))
    f <- pms_excel_number(v('fractional_share'),'fractional_share',row)
    if (!(f %in% c(0,1))) stop(sprintf('%d행 fractional_share는 0 또는 1이어야 합니다.',row))
    qty <- pms_excel_number(v('quantity'),'quantity',row)
    price <- pms_excel_number(v('avg_price'),'avg_price',row)
    fx <- pms_excel_number(v('avg_fx_rate'),'avg_fx_rate',row)
    cost <- pms_excel_number(v('cost_krw'),'cost_krw',row,optional=TRUE)
    if (qty<0 || price<0 || fx<=0 || (!is.na(cost) && cost<0))
      stop(sprintf('%d행 수량·평균가격·취득원가는 0 이상이고 매입환율은 0보다 커야 합니다.',row))
    natural[i] <- paste(v('broker'),v('account_number'),country,symbol,as.integer(f),sep='|')
    record <- list(country=country,symbol=symbol,name=v('name'),currency=currency,
                   asset_class=v('asset_class'),tax_type=v('tax_type'),broker=v('broker'),
                   account_type=v('account_type'),account_number=v('account_number'),
                   fractional_share=as.integer(f),quantity=qty,avg_price=price,
                   avg_fx_rate=fx,cost_krw=cost,memo=v('memo'),updated_at=NA_character_)
    if (!identical(names(record),holdings_columns)) stop('내부 보유종목 열 정의 오류')
    records[[i]] <- record
    action[i] <- if (validids[i]) '수정' else '신규'
    if (validids[i]) {
      prev <- old[match(ids[i],oldids),,drop=FALSE]
      # Guard against an edit done in the app after the Excel was exported.
      original_time <- v('updated_at')
      current_time <- norm(prev$updated_at[1])
      if (!identical(original_time,current_time))
        stop(sprintf('%d행 ID %s: 엑셀 다운로드 이후 다른 수정이 발생했습니다. 최신 파일을 다시 내려받으세요.',row,ids[i]))
      # DB writes decide whether a row changed, but provide a preview count.
      changed[i] <- any(vapply(write_columns,function(k) {
        a <- prev[[k]][1]; b <- record[[k]]
        if (is.na(a) && is.na(b)) return(FALSE)
        if (is.na(a) || is.na(b)) return(TRUE)
        if (is.numeric(a) || is.integer(a)) return(!isTRUE(all.equal(as.numeric(a),as.numeric(b),tolerance=1e-9)))
        !identical(as.character(a),as.character(b))
      },logical(1)))
    } else changed[i] <- TRUE
  }
  if(anyDuplicated(natural)) stop('동일 증권사·계좌번호·국가·종목·소수점구분이 엑셀에 중복돼 있습니다.')
  # Detect collisions with holdings outside the uploaded rows.
  existing_key <- paste(old$broker,old$account_number,old$country,old$symbol,old$fractional_share,sep='|')
  excluded <- !(oldids %in% ids[validids]); collision <- intersect(natural,existing_key[excluded])
  if(length(collision)) stop('엑셀의 신규/변경 행이 기존 다른 ID의 보유종목과 중복됩니다.')
  preview <- data.frame(구분=action,ID=ifelse(nzchar(ids),ids,'(신규)'),종목코드=vapply(records,`[[`,'','symbol'),
                        증권사=vapply(records,`[[`,'','broker'),계좌번호=vapply(records,`[[`,'','account_number'),
                        보유수량=vapply(records,`[[`,0.0,'quantity'),변경됨=ifelse(changed,'예','아니오'),check.names=FALSE)
  list(records=records, ids=ids, action=action, changed=changed, preview=preview,
       summary=sprintf('전체 %d건 · 신규 %d건 · 기존 수정 %d건 · 값 변화 없음 %d건 · 삭제 없음',nrow(raw),sum(action=='신규'),sum(action=='수정' & changed),sum(!changed)))
}

pms_holdings_excel_apply <- function(con, plan) {
  # Atomic import; any failure rolls back *all* changes.
  DBI::dbWithTransaction(con, {
    for (i in seq_along(plan$records)) {
      if (plan$action[i]=='신규') insert_holding(con,plan$records[[i]])
      else {
        # Recheck collision with concurrent edits before writing.
        current <- get_holding(con,as.integer(plan$ids[i]))
        if (is.null(current)) stop(paste('적용 중 ID가 삭제되었습니다:',plan$ids[i]))
        if (plan$changed[i]) update_holding(con,as.integer(plan$ids[i]),plan$records[[i]])
      }
    }
  })
  invisible(TRUE)
}
