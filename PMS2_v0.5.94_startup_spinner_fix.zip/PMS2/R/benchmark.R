# PMS2 v0.5.0: one-year daily adjusted? NO: unadjusted daily close price-only comparison.
# Dividend and transactions excluded. Do not report as actual portfolio performance.
pms_benchmarks <- data.frame(country='KR',symbol=c('379800','379810','069500'),
 name=c('KODEX 미국S&P500','KODEX 미국나스닥100','KODEX 200'),stringsAsFactors=FALSE)

pms_init_benchmark <- function(con) {
 DBI::dbExecute(con,"CREATE TABLE IF NOT EXISTS history_daily (country TEXT NOT NULL,symbol TEXT NOT NULL,trade_date TEXT NOT NULL,close REAL NOT NULL,source TEXT NOT NULL,fetched_at TEXT NOT NULL,PRIMARY KEY(country,symbol,trade_date))")
 DBI::dbExecute(con,"CREATE TABLE IF NOT EXISTS history_fetch_status (country TEXT NOT NULL,symbol TEXT NOT NULL,status TEXT NOT NULL,rows_count INTEGER NOT NULL,detail TEXT,fetched_at TEXT NOT NULL,PRIMARY KEY(country,symbol))")
}
pms_history_yahoo <- function(country,symbol,start=Sys.Date()-370L,end=Sys.Date()) {
 base <- toupper(trimws(as.character(symbol)))
 codes <- if(country=='KR' && grepl('^[0-9]{6}$',base)) paste0(base,c('.KS','.KQ')) else base
 p1 <- as.integer(as.POSIXct(start,tz='UTC'));p2 <- as.integer(as.POSIXct(end+1L,tz='UTC'))
 errs <- character()
 for (code in codes) {
   url <- paste0('https://query1.finance.yahoo.com/v8/finance/chart/',utils::URLencode(code,reserved=TRUE),
      '?period1=',p1,'&period2=',p2,'&interval=1d&events=history&includeAdjustedClose=false')
   x <- tryCatch(pms_get_json(url,timeout=18L),error=function(e)e)
   if(inherits(x,'error')) { errs<-c(errs,paste(code,conditionMessage(x)));next }
   r <- x$chart$result
   if(is.null(r)||!length(r)) {errs<-c(errs,paste(code,'결과 없음'));next}
   r <- r[[1]]
   stamps <- unlist(r$timestamp,use.names=FALSE)
   vals <- unlist(r$indicators$quote[[1]]$close,use.names=FALSE)
   if(!length(stamps)||!length(vals)||length(stamps)!=length(vals)) {errs<-c(errs,paste(code,'날짜/종가 없음'));next}
   tz <- if(country=='KR') 'Asia/Seoul' else 'America/New_York'
   dates <- format(as.POSIXct(as.numeric(stamps),origin='1970-01-01',tz='UTC'),'%Y-%m-%d',tz=tz)
   d <- data.frame(trade_date=dates,close=suppressWarnings(as.numeric(vals)),stringsAsFactors=FALSE)
   d <- d[is.finite(d$close) & d$close>0 & !is.na(d$trade_date),,drop=FALSE]
   d <- d[!duplicated(d$trade_date,fromLast=TRUE),,drop=FALSE]
   if(nrow(d)>2L) return(d[order(d$trade_date),,drop=FALSE])
   errs<-c(errs,paste(code,'유효가격 부족'))
 }
 stop(paste(errs,collapse=' / '))
}
pms_history_targets <- function(con) {
 h <- DBI::dbGetQuery(con,"SELECT country,symbol,MAX(name) AS name FROM holdings WHERE quantity>0 AND country IN ('KR','US') GROUP BY country,symbol")
 t <- unique(rbind(h,pms_benchmarks))
 t[order(t$country,t$symbol),,drop=FALSE]
}
# Price-history cache: reuse complete cached periods and request only uncovered edges.
# Weekends/holidays are tolerated (7 days at either boundary).
pms_history_plan <- function(con, country, symbol, start=Sys.Date()-365L, end=Sys.Date()) {
  d <- DBI::dbGetQuery(con,"SELECT MIN(trade_date) AS first_day, MAX(trade_date) AS last_day, COUNT(*) AS n FROM history_daily WHERE country=? AND symbol=? AND trade_date BETWEEN ? AND ?",
    params=list(country,symbol,as.character(start),as.character(end)))
  if(is.na(d$n[1]) || d$n[1]<30L || is.na(d$first_day[1]) || is.na(d$last_day[1]))
    return(list(mode='전체 수집',ranges=list(c(start-5L,end))))
  first <- as.Date(d$first_day[1]); last <- as.Date(d$last_day[1])
  ranges<-list()
  if(first > start+7L) ranges[[length(ranges)+1L]] <- c(start-5L,first-1L)
  if(last < end-4L) ranges[[length(ranges)+1L]] <- c(last+1L,end)
  if(!length(ranges)) return(list(mode='캐시 재사용',ranges=list()))
  list(mode='누락 기간 보충',ranges=ranges)
}
pms_reset_history <- function(con) {
  pms_init_benchmark(con)
  DBI::dbWithTransaction(con, {
    DBI::dbExecute(con,'DELETE FROM history_daily')
    DBI::dbExecute(con,'DELETE FROM history_fetch_status')
  })
  invisible(TRUE)
}
pms_collect_history <- function(con,on_result=NULL,force=FALSE) {
  pms_init_benchmark(con)
  targets<-pms_history_targets(con);total<-nrow(targets)
  if(!total) return(data.frame())
  rows<-vector('list',total)
  for(i in seq_len(total)) {
    a<-targets[i,,drop=FALSE];cn<-as.character(a$country);sy<-as.character(a$symbol)
    plan<-if(force) list(mode='전체 재수집',ranges=list(c(Sys.Date()-370L,Sys.Date()))) else pms_history_plan(con,cn,sy)
    if(is.function(on_result)) on_result(NULL,i,total,paste0('시작: ',a$name,' (',sy,') · ',plan$mode))
    success<-TRUE; errors<-character(); received<-0L
    for(rng in plan$ranges) {
      out<-tryCatch(pms_history_yahoo(cn,sy,start=as.Date(rng[1],origin='1970-01-01'),end=as.Date(rng[2],origin='1970-01-01')),error=function(e)e)
      if(inherits(out,'error')) { success<-FALSE;errors<-c(errors,conditionMessage(out));next }
      received<-received+nrow(out)
      DBI::dbWithTransaction(con,{
        for(j in seq_len(nrow(out))) DBI::dbExecute(con,"INSERT INTO history_daily(country,symbol,trade_date,close,source,fetched_at) VALUES(?,?,?,?,?,datetime('now')) ON CONFLICT(country,symbol,trade_date) DO UPDATE SET close=excluded.close,source=excluded.source,fetched_at=excluded.fetched_at",
          params=list(cn,sy,out$trade_date[j],out$close[j],'YAHOO_CHART'))
      })
    }
    cnt<-DBI::dbGetQuery(con,'SELECT COUNT(*) AS n FROM history_daily WHERE country=? AND symbol=? AND trade_date BETWEEN ? AND ?',params=list(cn,sy,as.character(Sys.Date()-365L),as.character(Sys.Date())))$n[1]
    status<-if(!success)'FAILED' else if(!length(plan$ranges))'CACHED' else 'OK'
    detail<-if(!success) paste(errors,collapse=' / ') else paste0(plan$mode,' · ',received,'행 신규 응답 / 최근 1년 저장 ',cnt,'행')
    DBI::dbExecute(con,"INSERT INTO history_fetch_status(country,symbol,status,rows_count,detail,fetched_at) VALUES(?,?,?,?,?,datetime('now')) ON CONFLICT(country,symbol) DO UPDATE SET status=excluded.status,rows_count=excluded.rows_count,detail=excluded.detail,fetched_at=excluded.fetched_at",
      params=list(cn,sy,status,as.integer(cnt),substr(detail,1,600)))
    rows[[i]]<-data.frame(국가=cn,종목코드=sy,종목명=as.character(a$name),상태=if(success)if(status=='CACHED')'재사용' else '성공' else '실패',저장거래일=as.integer(cnt),사유=detail,stringsAsFactors=FALSE)
    if(is.function(on_result)) on_result(rows[[i]],i,total,paste0('완료: ',a$name,' · ',rows[[i]]$상태))
  }
  do.call(rbind,rows)
}
pms_history_fetch_table<-function(con){pms_init_benchmark(con);DBI::dbGetQuery(con,"SELECT t.country AS 국가,t.symbol AS 종목코드,t.name AS 종목명,COALESCE(s.status,'미수집') AS 상태,COALESCE(s.rows_count,0) AS 저장거래일,s.detail AS 결과,s.fetched_at AS 조회시각_UTC FROM (SELECT country,symbol,MAX(name) AS name FROM holdings WHERE quantity>0 AND country IN ('KR','US') GROUP BY country,symbol UNION SELECT country,symbol,name FROM (SELECT 'KR' AS country,'379800' AS symbol,'KODEX 미국S&P500' AS name UNION SELECT 'KR','379810','KODEX 미국나스닥100' UNION SELECT 'KR','069500','KODEX 200')) t LEFT JOIN history_fetch_status s ON t.country=s.country AND t.symbol=s.symbol ORDER BY t.country,t.symbol")}

# Eligibility: securities must have close history for essentially the full year.
# Newly listed / incomplete history remains stored but is excluded from the model portfolio.
pms_history_eligibility <- function(price, keys, start, end, min_rows=180L, max_start_gap=20L, max_end_gap=10L) {
  rows<-lapply(keys,function(k) {
    z<-price[price$key==k & is.finite(price$close) & price$close>0,,drop=FALSE]
    days<-sort(unique(as.Date(z$trade_date)))
    n<-length(days)
    first<-if(n)min(days) else as.Date(NA)
    last<-if(n)max(days) else as.Date(NA)
    reason<-if(n==0L) '과거 시세 없음 / 조회 실패' else if(first>start+max_start_gap) '최근 상장 또는 1년 초반 데이터 부족' else if(last<end-max_end_gap) '최근 구간 데이터 부족' else if(n<min_rows) '거래일 데이터 부족' else ''
    data.frame(종목키=k,거래일수=n,최초일=as.character(first),최종일=as.character(last),판정=if(nchar(reason)) '제외' else '포함',사유=reason,stringsAsFactors=FALSE)
  })
  if(!length(rows)) return(data.frame())
  do.call(rbind,rows)
}
pms_benchmark_series <- function(con, start=Sys.Date()-365L, end=Sys.Date()) {
 pms_init_benchmark(con)
 # Resolve a Korean/English holding name for each excluded country:symbol key.
 decorate_excluded <- function(excluded) {
   if(!nrow(excluded) || !('종목키' %in% names(excluded))) return(excluded)
   nm <- DBI::dbGetQuery(con, "SELECT country || ':' || symbol AS key, MAX(name) AS name FROM holdings GROUP BY country,symbol")
   excluded$종목코드 <- sub('^[^:]+:', '', excluded$종목키)
   excluded$종목명 <- as.character(nm$name[match(excluded$종목키,nm$key)])
   excluded$종목명[is.na(excluded$종목명)] <- ''
   excluded[,c('종목키','종목코드','종목명',setdiff(names(excluded),c('종목키','종목코드','종목명'))),drop=FALSE]
 }
 empty <- function(msg, excluded=data.frame()) list(series=data.frame(),statistics=data.frame(),excluded=decorate_excluded(excluded),weights=data.frame(),notice=msg)
 price <- DBI::dbGetQuery(con,"SELECT country,symbol,trade_date,close FROM history_daily WHERE trade_date BETWEEN ? AND ? ORDER BY trade_date",params=list(as.character(start),as.character(end)))
 if(!nrow(price)) return(empty('과거 주가가 없습니다. 먼저 최근 1년 일별 주가를 수집하세요.'))
 h <- DBI::dbGetQuery(con,"SELECT country,symbol,MAX(name) AS name,SUM(quantity) AS qty FROM holdings WHERE quantity>0 AND country IN ('KR','US') GROUP BY country,symbol")
 b<-pms_benchmarks
 bkeys<-paste(b$country,b$symbol,sep=':')
 hkeys<-paste(h$country,h$symbol,sep=':')
 price$key<-paste(price$country,price$symbol,sep=':')
 eligible_table<-pms_history_eligibility(price,unique(c(bkeys,hkeys)),start,end)
 okkeys<-eligible_table$종목키[eligible_table$판정=='포함']
 benchmissing<-setdiff(bkeys,okkeys)
 excluded_holdings<-eligible_table[eligible_table$판정=='제외' & eligible_table$종목키 %in% hkeys,,drop=FALSE]
 if(length(benchmissing)) return(empty(paste0('벤치마크 ETF의 1년치 데이터가 부족합니다: ',paste(benchmissing,collapse=', '),'. 네 개 곡선을 정확하게 비교할 수 없어 그래프를 그리지 않습니다.'),excluded_holdings))
 # Use Korean trading dates for all four comparable curves.
 krdates<-sort(unique(price$trade_date[price$key==bkeys[1]]))
 if(length(krdates)<180L) return(empty('공통 비교 기간의 한국 거래일이 부족합니다.',excluded_holdings))
 portfolio_keys<-intersect(hkeys,okkeys)
 if(!length(portfolio_keys)) return(empty('1년 이력이 충분한 보유종목이 없어 포트폴리오 선을 만들 수 없습니다.',excluded_holdings))
 fx<-DBI::dbGetQuery(con,"SELECT rate_date,rate FROM usdkrw_daily ORDER BY rate_date")
 if(!nrow(fx) && any(sub(':.*$','',portfolio_keys)=='US')) return(empty('미국 보유종목 원화환산에 필요한 일별 USD/KRW 환율 데이터가 없습니다.',excluded_holdings))
 selected<-list()
 for(k in unique(c(bkeys,portfolio_keys))) {
   cn<-sub(':.*$','',k)
   d<-price[price$key==k,c('trade_date','close'),drop=FALSE]
   d<-d[!duplicated(d$trade_date,fromLast=TRUE),,drop=FALSE]
   d<-d[order(d$trade_date),,drop=FALSE]
   pos<-findInterval(as.numeric(as.Date(krdates)),as.numeric(as.Date(d$trade_date)))
   v<-rep(NA_real_,length(krdates));good<-pos>0L
   v[good]<-d$close[pos[good]]
   good[good]<-as.integer(as.Date(krdates[good])-as.Date(d$trade_date[pos[good]]))<=7L
   v[!good]<-NA_real_
   if(cn=='US') {
     fp<-findInterval(as.numeric(as.Date(krdates)),as.numeric(as.Date(fx$rate_date)))
     valid<-fp>0L;rates<-rep(NA_real_,length(krdates));rates[valid]<-as.numeric(fx$rate[fp[valid]])
     valid[valid]<-as.integer(as.Date(krdates[valid])-as.Date(fx$rate_date[fp[valid]]))<=7L
     rates[!valid]<-NA_real_;v<-v*rates
   }
   selected[[k]]<-v
 }
 # Remove a holding if its price/FX cannot be evaluated over the shared comparison window.
 # Never silently drop one of the three benchmarks.
 valid_bench<-Reduce(`&`,lapply(selected[bkeys],function(v)is.finite(v)&v>0))
 if(sum(valid_bench)<180L) return(empty('3개 ETF에 공통으로 유효한 1년치 가격이 부족합니다.',excluded_holdings))
 for(k in portfolio_keys) {
   v<-selected[[k]]
   if(sum(valid_bench & is.finite(v) & v>0)<180L || any(!is.finite(v[valid_bench]) | v[valid_bench]<=0)) {
     excluded_holdings<-rbind(excluded_holdings,data.frame(종목키=k,거래일수=sum(is.finite(v)),최초일=NA_character_,최종일=NA_character_,판정='제외',사유='공통 거래일의 가격 또는 환율 누락',stringsAsFactors=FALSE))
     portfolio_keys<-setdiff(portfolio_keys,k)
   }
 }
 if(!length(portfolio_keys)) return(empty('1년 동안 공통 가격·환율을 확보한 보유종목이 없습니다.',excluded_holdings))
 common<-valid_bench
 for(k in portfolio_keys) common<-common & is.finite(selected[[k]]) & selected[[k]]>0
 if(sum(common)<180L) return(empty('4개 비교곡선에 공통으로 유효한 1년치 거래일이 부족합니다.',excluded_holdings))
 dates<-as.Date(krdates[common])
 res<-data.frame(날짜=dates)
 # Fixed output order: portfolio first, exactly three benchmark ETFs following.
 mat<-vapply(portfolio_keys,function(k)selected[[k]][common],numeric(length(dates)))
 if(is.null(dim(mat))) mat<-matrix(mat,ncol=1L)
 # Buy-and-hold model: use CURRENT quantities, unchanged across historical dates.
 # This is a hypothetical history of the current portfolio, not actual historical holdings.
 idx<-match(portfolio_keys,hkeys)
 qty<-as.numeric(h$qty[idx])
 daily_portfolio_krw<-as.numeric(mat %*% qty)
 if(!all(is.finite(daily_portfolio_krw)) || any(daily_portfolio_krw<=0))
   return(empty('포트폴리오 평가금액 계산에 실패했습니다.',excluded_holdings))
 current_values<-qty*mat[nrow(mat),]
 weights<-data.frame(국가=h$country[idx],종목코드=h$symbol[idx],종목명=h$name[idx],현재보유수량=qty,
                     비교종료일_종가원화=as.numeric(mat[nrow(mat),]),
                     현재비중_퍼센트=round(100*current_values/sum(current_values),3),
                     stringsAsFactors=FALSE)
 weights<-weights[order(-weights$현재비중_퍼센트),,drop=FALSE]
 res[['내 포트폴리오']]<-100*daily_portfolio_krw/daily_portfolio_krw[1]
 for(i in seq_len(nrow(b))) {
   v<-selected[[bkeys[i]]][common]
   res[[b$name[i]]]<-100*v/v[1]
 }
 # Daily simple returns on the same four-series, KRW-denominated common-date panel.
 # Annualization: 252 trading days; risk-free assumption 0% per annum.
 metric<-lapply(names(res)[-1],function(n){
   x<-as.numeric(res[[n]])
   peak<-cummax(x)
   daily_ret<-x[-1L]/x[-length(x)]-1
   vol<-if(length(daily_ret)>1L) stats::sd(daily_ret) else NA_real_
   sharpe<-if(is.finite(vol) && vol>0) sqrt(252)*mean(daily_ret)/vol else NA_real_
   downside<-sqrt(mean(pmin(daily_ret,0)^2))
   sortino<-if(is.finite(downside) && downside>0) sqrt(252)*mean(daily_ret)/downside else NA_real_
   years<-(length(x)-1)/252
   cagr<-if(years>0) (tail(x,1)/x[1])^(1/years)-1 else NA_real_
   drawdown<-abs(min(x/peak-1))
   calmar<-if(is.finite(drawdown) && drawdown>0 && is.finite(cagr)) cagr/drawdown else NA_real_
   data.frame(비교대상=n,
              최근1년수익률_pct=round((tail(x,1)/x[1]-1)*100,2),
              MDD_pct=round(min(x/peak-1)*100,2),
              Sharpe=round(sharpe,3),
              Sortino=round(sortino,3),
              Calmar=round(calmar,3),
              시작일=as.character(res$날짜[1]),
              종료일=as.character(tail(res$날짜,1)),
              거래일수=length(x), stringsAsFactors=FALSE)
 })
 note<-paste0('총 4개 곡선: 내 포트폴리오 + KODEX ETF 3종. 동일 비교기간 ',min(dates),' ~ ',max(dates),'. ',
  '내 포트폴리오는 현재 보유수량을 과거 매일 동일하게 보유했다고 가정한 원화 평가금 합계입니다. 최신 공통거래일 평가액 기준 비중표를 확인하세요. ',
  nrow(excluded_holdings),'개 보유종목 제외. 전체 보유자산 실적을 나타내지 않습니다. ',
  '배당, 거래비용, 세금 및 과거 매매내역 미반영. 미국 주식은 과거 일별 환율로 원화 환산.')
 list(series=res,statistics=do.call(rbind,metric),excluded=decorate_excluded(excluded_holdings),weights=weights,notice=note)
}

# All risk graphs use the four already aligned KRW price-index columns.
# No network requests or changes to stored prices are made.
pms_benchmark_risk_curves <- function(series, window=60L) {
  if(!is.data.frame(series) || nrow(series)<3L || ncol(series)<2L)
    return(list(drawdown=data.frame(),rolling=data.frame()))
  nm<-names(series)[-1L]
  dd<-data.frame(날짜=series$날짜,check.names=FALSE)
  rr<-data.frame(날짜=series$날짜,check.names=FALSE)
  for(n in nm) {
    x<-as.numeric(series[[n]])
    dd[[n]]<-100*(x/cummax(x)-1)
    r<-x[-1L]/x[-length(x)]-1
    v<-rep(NA_real_,length(x))
    if(length(r)>=window) {
      for(i in seq.int(window,length(r))) {
        part<-r[(i-window+1L):i]
        vol<-stats::sd(part)
        if(all(is.finite(part)) && is.finite(vol) && vol>0)
          v[i+1L]<-sqrt(252)*mean(part)/vol
      }
    }
    rr[[n]]<-v
  }
  list(drawdown=dd,rolling=rr)
}


# Total Return: historical cash distributions reinvested at the ex-date closing price.
# Based on CURRENT quantities; not actual account cashflows. Missing histories are flagged.
pms_benchmark_total_return <- function(con, base) {
  pms_init_dividend_tables(con)
  if(!nrow(base$series) || !nrow(base$weights))
    return(list(series=data.frame(),statistics=data.frame(),coverage=data.frame(),notice='가격 백테스트 자료가 부족합니다.'))
  dates<-as.Date(base$series$날짜)
  start<-min(dates); end<-max(dates)
  holdings<-base$weights
  b<-pms_benchmarks
  keys<-unique(c(paste(holdings$국가,holdings$종목코드,sep=':'),paste(b$country,b$symbol,sep=':')))
  # Exact stored historical prices; align to the price benchmark shared Korean trading dates.
  px<-DBI::dbGetQuery(con,'SELECT country,symbol,trade_date,close FROM history_daily WHERE trade_date BETWEEN ? AND ? ORDER BY trade_date',params=list(as.character(start-8L),as.character(end)))
  fx<-DBI::dbGetQuery(con,'SELECT rate_date,rate FROM usdkrw_daily ORDER BY rate_date')
  ev<-DBI::dbGetQuery(con,'SELECT country,symbol,ex_date,amount FROM dividend_events WHERE ex_date BETWEEN ? AND ?',params=list(as.character(start),as.character(end)))
  st<-DBI::dbGetQuery(con,'SELECT country,symbol,status,events_count,detail FROM dividend_fetch_status')
  coverage<-data.frame(국가=character(),종목코드=character(),종목명=character(),배당조회상태=character(),배당이벤트수=integer(),비고=character())
  all_index<-list()
  for(key in keys) {
    cn<-sub(':.*$','',key);sym<-sub('^[^:]+:','',key)
    rowst<-st[st$country==cn & st$symbol==sym,,drop=FALSE]
    ok<-nrow(rowst)>0 && identical(as.character(rowst$status[1]),'OK')
    cnt<-if(nrow(rowst) && !is.na(rowst$events_count[1])) as.integer(rowst$events_count[1]) else NA_integer_
    nm<-if(key %in% paste(b$country,b$symbol,sep=':')) b$name[match(key,paste(b$country,b$symbol,sep=':'))] else holdings$종목명[match(key,paste(holdings$국가,holdings$종목코드,sep=':'))]
    coverage<-rbind(coverage,data.frame(국가=cn,종목코드=sym,종목명=nm,배당조회상태=if(ok)'조회 성공' else if(nrow(rowst))'조회 실패' else '미조회',배당이벤트수=cnt,비고=if(ok && cnt==0)'API에서 이벤트 0건: 실제 미지급 여부 확인 필요' else if(ok) '이력 사용' else 'TR 수익률 계산 대상에서 제외',stringsAsFactors=FALSE))
    if(!ok) next
    d<-px[paste(px$country,px$symbol,sep=':')==key,,drop=FALSE]
    d<-d[!duplicated(d$trade_date,fromLast=TRUE),,drop=FALSE];d<-d[order(d$trade_date),,drop=FALSE]
    if(!nrow(d)) next
    pos<-findInterval(as.numeric(dates),as.numeric(as.Date(d$trade_date)))
    v<-rep(NA_real_,length(dates)); good<-pos>0
    v[good]<-d$close[pos[good]]
    good[good]<-(as.integer(dates[good]-as.Date(d$trade_date[pos[good]]))<=7L)
    v[!good]<-NA_real_
    # Cash dividends and close share the native currency; reinvestment ratio is FX-neutral.
    if(any(!is.finite(v)) || any(v<=0)) next
    events<-ev[paste(ev$country,ev$symbol,sep=':')==key,,drop=FALSE]
    cash<-numeric(length(dates))
    if(nrow(events)) for(j in seq_len(nrow(events))) {
      dt<-as.Date(events$ex_date[j]); k<-which(dates>=dt)[1]
      if(!is.na(k) && is.finite(events$amount[j]) && events$amount[j]>0) cash[k]<-cash[k]+events$amount[j]
    }
    shares<-cumprod(1+cash/v)
    # Use historic FX for US when expressing total-return value in KRW.
    if(cn=='US') {
      if(!nrow(fx)) next
      fpos<-findInterval(as.numeric(dates),as.numeric(as.Date(fx$rate_date)))
      rate<-rep(NA_real_,length(dates));valid<-fpos>0
      rate[valid]<-fx$rate[fpos[valid]]
      valid[valid]<-(as.integer(dates[valid]-as.Date(fx$rate_date[fpos[valid]]))<=7L)
      rate[!valid]<-NA_real_
      if(any(!is.finite(rate)) || any(rate<=0)) next
      v<-v*rate
    }
    all_index[[key]]<-v*shares
  }
  full<-paste(b$country,b$symbol,sep=':')
  full<-c(paste(holdings$국가,holdings$종목코드,sep=':'),full)
  if(!all(full %in% names(all_index))) {
    missing<-setdiff(full,names(all_index))
    return(list(series=data.frame(),statistics=data.frame(),coverage=coverage,notice=paste('배당이력 또는 가격·환율 확인이 부족하여 총수익률 4개 곡선을 표시하지 않습니다. 미완료:',paste(missing,collapse=', '))))
  }
  # Current share counts fixed initially; dividends buy additional fractional shares.
  keys_h<-paste(holdings$국가,holdings$종목코드,sep=':')
  total<-Reduce(`+`,lapply(seq_along(keys_h),function(i) all_index[[keys_h[i]]]*as.numeric(holdings$현재보유수량[i])))
  ans<-data.frame(날짜=dates,check.names=FALSE)
  ans[['내 포트폴리오']]<-100*total/total[1]
  for(i in seq_len(nrow(b))) {k<-paste(b$country[i],b$symbol[i],sep=':'); v<-all_index[[k]];ans[[b$name[i]]]<-100*v/v[1]}
  # Identical metric definitions as price-return table.
  measure<-function(n) {
    x<-as.numeric(ans[[n]]);r<-x[-1]/x[-length(x)]-1;peak<-cummax(x)
    vol<-stats::sd(r);sh<-if(is.finite(vol)&&vol>0) sqrt(252)*mean(r)/vol else NA_real_
    dn<-sqrt(mean(pmin(r,0)^2));so<-if(is.finite(dn)&&dn>0) sqrt(252)*mean(r)/dn else NA_real_
    dd<-min(x/peak-1);years<-(length(x)-1)/252;cagr<-(tail(x,1)/x[1])^(1/years)-1
    ca<-if(abs(dd)>0)cagr/abs(dd) else NA_real_
    data.frame(비교대상=n,최근1년총수익률_pct=round((tail(x,1)/x[1]-1)*100,2),MDD_pct=round(dd*100,2),Sharpe=round(sh,3),Sortino=round(so,3),Calmar=round(ca,3),시작일=as.character(start),종료일=as.character(end),거래일수=length(x))
  }
  list(series=ans,statistics=do.call(rbind,lapply(names(ans)[-1],measure)),coverage=coverage,
       notice='배당락일에 세전 주당 배당·분배금을 해당 종목에 전액 재투자한 가상 총수익률입니다. 현재 보유수량을 기간 시작부터 유지했다고 가정합니다. 지급일·세금·수수료·실제 과거 매매는 미반영합니다. Yahoo 배당이력의 누락 가능성을 조회 상태표에서 확인하세요.')
}

pms_bench_collect_dividend_coverage <- function(con, on_result=NULL) {
  pms_init_dividend_tables(con)
  targets<-unique(rbind(data.frame(country=pms_benchmarks$country,symbol=pms_benchmarks$symbol),
    DBI::dbGetQuery(con,"SELECT DISTINCT country,symbol FROM holdings WHERE quantity>0 AND country IN ('KR','US')")))
  now<-pms_utc_now();out<-vector('list',nrow(targets))
  for(i in seq_len(nrow(targets))) {
    cn<-as.character(targets$country[i]);sy<-as.character(targets$symbol[i]);
    existing<-DBI::dbGetQuery(con,'SELECT status,fetched_at FROM dividend_fetch_status WHERE country=? AND symbol=?',params=list(cn,sy))
    if(nrow(existing) && existing$status[1]=='OK' && as.Date(substr(existing$fetched_at[1],1,10))>=Sys.Date()-1L) {
      out[[i]]<-data.frame(country=cn,symbol=sy,status='CACHED');
    } else {
      result<-tryCatch(pms_dividend_yahoo(cn,sy,from=Sys.Date()-370L),error=function(e)e)
      if(inherits(result,'error')) {
        DBI::dbExecute(con,"INSERT INTO dividend_fetch_status(country,symbol,status,events_count,source,detail,fetched_at) VALUES(?,?,'FAILED',NULL,'YAHOO',?,?) ON CONFLICT(country,symbol) DO UPDATE SET status=excluded.status,detail=excluded.detail,fetched_at=excluded.fetched_at",params=list(cn,sy,conditionMessage(result),now))
        out[[i]]<-data.frame(country=cn,symbol=sy,status='FAILED')
      } else {
        DBI::dbWithTransaction(con,{
          DBI::dbExecute(con,'DELETE FROM dividend_events WHERE country=? AND symbol=?',params=list(cn,sy))
          if(nrow(result$events)) for(j in seq_len(nrow(result$events))) DBI::dbExecute(con,'INSERT INTO dividend_events(country,symbol,ex_date,amount,currency,source,fetched_at) VALUES(?,?,?,?,?,?,?)',params=list(cn,sy,result$events$ex_date[j],result$events$amount[j],if(cn=='KR')'KRW' else 'USD',result$source,now))
          DBI::dbExecute(con,"INSERT INTO dividend_fetch_status(country,symbol,status,events_count,source,detail,fetched_at) VALUES(?,?,'OK',?,?,?,?) ON CONFLICT(country,symbol) DO UPDATE SET status=excluded.status,events_count=excluded.events_count,source=excluded.source,detail=excluded.detail,fetched_at=excluded.fetched_at",params=list(cn,sy,nrow(result$events),result$source,'TR 백테스트용 배당 이력 수집',now))
        })
        out[[i]]<-data.frame(country=cn,symbol=sy,status='OK')
      }
    }
    if(is.function(on_result)) on_result(i,nrow(targets),cn,sy,out[[i]]$status)
  }
  do.call(rbind,out)
}
