# ETF backfill: use direct Yahoo first, then quantmod if installed.
# Do not synthesize/forward fill non-trading dates.
pms_home_etf_fetch <- function(start,end) {
  first <- tryCatch(pms_history_yahoo('KR','379800',start=start,end=end),error=function(e)e)
  if(!inherits(first,'error') && nrow(first)>0L) return(first)
  yahoo_error <- if(inherits(first,'error')) conditionMessage(first) else 'empty response'
  if(!requireNamespace('quantmod',quietly=TRUE)) stop(paste('Yahoo:',yahoo_error,'; quantmod 미설치'))
  errors <- character()
  for(code in c('379800.KS','379800.KQ')) {
    obj <- tryCatch(quantmod::getSymbols(code,src='yahoo',from=start,to=end+1L,auto.assign=FALSE,warnings=FALSE),error=function(e)e)
    if(inherits(obj,'error')) {errors<-c(errors,paste(code,conditionMessage(obj)));next}
    px <- tryCatch(quantmod::Cl(obj),error=function(e)e)
    if(inherits(px,'error')) next
    res <- data.frame(trade_date=as.character(as.Date(zoo::index(px))),close=as.numeric(px[,1]),stringsAsFactors=FALSE)
    res <- res[is.finite(res$close) & res$close>0 & !is.na(res$trade_date),,drop=FALSE]
    if(nrow(res)>2L) return(res[!duplicated(res$trade_date),,drop=FALSE])
  }
  stop(paste('ETF 과거 시세 양쪽 소스 조회 실패. Yahoo:',yahoo_error,'quantmod:',paste(errors,collapse=' / ')))
}

pms_home_overlay_coverage <- function(con) {
  pms_init_benchmark(con)
  pms_init_dividend_tables(con)
  z <- DBI::dbGetQuery(con,"SELECT MIN(trade_date) d1,MAX(trade_date) d2,COUNT(*) n FROM history_daily WHERE country='KR' AND symbol='379800'")
  x <- DBI::dbGetQuery(con,"SELECT MIN(rate_date) d1,MAX(rate_date) d2,COUNT(*) n FROM usdkrw_daily")
  rng <- function(a) if(!nrow(a) || !is.finite(a$n[1]) || a$n[1]==0) '자료 없음' else paste0(a$d1[1],' ~ ',a$d2[1],' (',a$n[1],'일)')
  paste0('ETF 저장기간: ',rng(z),' · 환율 저장기간: ',rng(x))
}

# PMS2 v0.5.76: Extend only home-market overlay data to portfolio start.
# Never overwrite snapshots or holdings; existing benchmark/FX SQLite caches are reused.
pms_home_market_backfill <- function(con, now=Sys.Date(), force=FALSE, only_etf=FALSE) {
  pms_init_benchmark(con)
  pms_init_dividend_tables(con)
  DBI::dbExecute(con, 'CREATE TABLE IF NOT EXISTS home_overlay_fetch_log (series TEXT PRIMARY KEY, checked_at TEXT, status TEXT, detail TEXT)')
  start_row <- DBI::dbGetQuery(con, 'SELECT MIN(snapshot_date) AS d FROM snapshot_daily WHERE securities_value_krw>0')
  if (!nrow(start_row) || is.na(start_row$d[1])) return(invisible('총평가액 이력이 아직 없습니다.'))
  start <- as.Date(start_row$d[1]); end <- as.Date(now)
  if (is.na(start) || start>=end) return(invisible('기록 기간이 부족합니다.'))
  notes <- character()
  # Avoid retry storms when network unavailable; retry failed series after six hours.
  try_series <- function(key, fetch) {
    last <- DBI::dbGetQuery(con,'SELECT checked_at,status FROM home_overlay_fetch_log WHERE series=?',params=list(key))
    if(!force && nrow(last) && identical(last$status[1],'FAILED')) {
      elapsed <- suppressWarnings(as.numeric(difftime(Sys.time(),as.POSIXct(last$checked_at[1],tz='UTC'),units='hours')))
      if(is.finite(elapsed) && elapsed<6) return('이전 수집 실패(재시도 버튼으로 즉시 시도 가능)')
    }
    err <- tryCatch({fetch();NULL},error=function(e)e)
    status <- if(inherits(err,'error')) 'FAILED' else 'OK'
    detail <- if(inherits(err,'error')) conditionMessage(err) else '누락된 과거/최근 구간 보충 완료'
    DBI::dbExecute(con,"INSERT INTO home_overlay_fetch_log(series,checked_at,status,detail) VALUES(?,datetime('now'),?,?) ON CONFLICT(series) DO UPDATE SET checked_at=excluded.checked_at,status=excluded.status,detail=excluded.detail",params=list(key,status,substr(detail,1,500)))
    paste(status,detail)
  }
  etf <- DBI::dbGetQuery(con,"SELECT MIN(trade_date) AS first_day, MAX(trade_date) AS last_day FROM history_daily WHERE country='KR' AND symbol='379800'")
  if(is.na(etf$first_day[1]) || as.Date(etf$first_day[1])>start+7L || as.Date(etf$last_day[1])<end-5L) {
    notes <- c(notes,paste('ETF',try_series('KODEX_379800',function() {
      plan <- pms_history_plan(con,'KR','379800',start=start,end=end)
      for(rng in plan$ranges) {
        z <- pms_home_etf_fetch(as.Date(rng[1],origin='1970-01-01'),as.Date(rng[2],origin='1970-01-01'))
        DBI::dbWithTransaction(con,for(i in seq_len(nrow(z))) DBI::dbExecute(con,
          "INSERT INTO history_daily(country,symbol,trade_date,close,source,fetched_at) VALUES('KR','379800',?,?, 'YAHOO_CHART',datetime('now')) ON CONFLICT(country,symbol,trade_date) DO UPDATE SET close=excluded.close,source=excluded.source,fetched_at=excluded.fetched_at",
          params=list(z$trade_date[i],z$close[i])))
      }
    })))
  }
  fx <- DBI::dbGetQuery(con,'SELECT MIN(rate_date) AS first_day, MAX(rate_date) AS last_day FROM usdkrw_daily')
  fx_first <- if(is.na(fx$first_day[1])) as.Date(NA) else as.Date(fx$first_day[1])
  fx_last <- if(is.na(fx$last_day[1])) as.Date(NA) else as.Date(fx$last_day[1])
  if(!only_etf && (is.na(fx_first) || fx_first>start+7L || is.na(fx_last) || fx_last<end-5L)) {
    notes <- c(notes,paste('USD/KRW',try_series('USD_KRW',function() {
      if(is.na(fx_first) || fx_first>start+7L) pms_collect_usdkrw_daily(con,from=start,to=if(is.na(fx_first)) end else min(end,fx_first-1L))
      if(!is.na(fx_last) && fx_last<end-5L) pms_collect_usdkrw_daily(con,from=max(start,fx_last+1L),to=end)
    })))
  }
  invisible(paste(c(if(length(notes)) notes else '기존 캐시 재사용',pms_home_overlay_coverage(con)),collapse=' | '))
}
