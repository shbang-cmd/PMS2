﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$candidates = @()
$c = Get-Command 'Rscript.exe' -ErrorAction SilentlyContinue
if ($c) { $candidates += $c.Source }
$dirs = @("$env:ProgramFiles\R", "${env:ProgramFiles(x86)}\R", 'C:\R')
foreach ($dir in $dirs) {
  if (Test-Path $dir) {
    $candidates += @(Get-ChildItem -Path $dir -Filter Rscript.exe -File -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
  }
}
$candidates = @($candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique)
if ($candidates.Count -eq 0) {
  Write-Host 'Rscript.exe를 찾지 못했습니다. R 설치 위치를 확인하고 R/bin 폴더를 PATH에 추가하세요.' -ForegroundColor Red
  exit 1
}
$rscript = $candidates[0]
Write-Host "R 실행 파일: $rscript"
Write-Host 'PMS2 서버를 실행하고 Chrome을 열겠습니다. 이 창을 닫으면 서버도 종료됩니다.'
& $rscript 'run_pms2.R'
exit $LASTEXITCODE
