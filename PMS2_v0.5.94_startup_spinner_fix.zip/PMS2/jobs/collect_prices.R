# Run from PMS2 project root using: Rscript jobs/collect_prices.R
source(file.path('R','db.R'))
source(file.path('R','prices.R'))
con <- open_pms_db()
on.exit(DBI::dbDisconnect(con), add=TRUE)
result <- pms_collect_prices(con,progress=function(i,n,s) cat(sprintf('[%d/%d] %s\n',i,n,s)))
print(table(result$status))
print(DBI::dbGetQuery(con,"SELECT * FROM fx_rates"))
