# PMS2 - 개인금융자산 통계연구소
# Version: v0.5.87 (2026-10-18)
# Chrome에서 열고 RStudio Viewer를 사용하지 않는 전용 실행기
# RStudio [Run App] 버튼이 아니라 PMS2_Chrome_실행.bat을 더블클릭하세요.

pms_find_chrome <- function() {
  if (.Platform$OS.type != 'windows') stop('이 실행기는 Windows Chrome 전용입니다.')
  manual <- Sys.getenv('PMS_CHROME_PATH', unset='')
  paths <- c(manual, unname(Sys.which('chrome.exe')),
    file.path(Sys.getenv('PROGRAMFILES'), 'Google/Chrome/Application/chrome.exe'),
    file.path(Sys.getenv('PROGRAMFILES(X86)'), 'Google/Chrome/Application/chrome.exe'),
    file.path(Sys.getenv('LOCALAPPDATA'), 'Google/Chrome/Application/chrome.exe'))
  paths <- unique(paths[nzchar(paths)])
  paths <- paths[file.exists(paths)]
  if (!length(paths)) stop('Chrome.exe를 찾지 못했습니다. PMS_CHROME_PATH 환경변수로 경로를 설정하세요.')
  normalizePath(paths[1], winslash='/', mustWork=TRUE)
}

pms_run_chrome <- function() {
  chrome <- pms_find_chrome()
  message('Chrome 실행파일: ', chrome)
  # 포트가 충돌하면 사용 가능한 포트를 새로 선택합니다.
  port <- httpuv::randomPort()
  url <- paste0('http://127.0.0.1:', port)
  # RStudio Viewer를 절대로 자동으로 열지 않음.
  options(shiny.launch.browser=FALSE)
  later::later(function() {
    message('Chrome 주소: ', url)
    # 새 Chrome 창을 최대화해서 시작(기존 Chrome 창의 크기 설정에 영향받지 않도록 새 창 지정)
    tryCatch({
      system2(chrome, args=c('--new-window', '--start-maximized', shQuote(url)), wait=FALSE, stdout=FALSE, stderr=FALSE)
    }, error=function(e) message('Chrome 실행 오류: ', conditionMessage(e)))
  }, delay=1)
  shiny::runApp('.', host='127.0.0.1', port=port, launch.browser=FALSE)
}

pms_run_chrome()
