# PMS2 risk analysis v0.5.69 -- adapted from user-provided risk_module.R.
# Source: compute_daily_returns_from_dd, estimate_mu_sigma_from_dd,
# run_mc_from_dd, run_future_mdd_from_dd, run_mc_withdraw_from_dd,
# run_var_cvar_from_file and run_garch_vol_alert.
# All risk calculations below are based on an INFERRED contribution proxy:
# invested = total valuation - unrealized profit. It is NOT a verified ledger.
pms_risk_returns <- function(x,clip=0.5) {
  z <- x[is.finite(x$value) & is.finite(x$profit) & x$value>0 & !is.na(x$date),,drop=FALSE]
  z <- z[order(z$date),,drop=FALSE]
  if(nrow(z)) z <- z[!duplicated(z$date,fromLast=TRUE),,drop=FALSE]
  z$invested <- z$value-z$profit
  z$flow_proxy <- c(NA_real_,diff(z$invested))
  z$base <- c(NA_real_,head(z$value,-1))+z$flow_proxy
  z$ret <- ifelse(is.finite(z$base) & z$base>0,z$value/z$base-1,NA_real_)
  z$ret[is.finite(z$ret) & abs(z$ret)>=clip] <- NA_real_
  z
}
pms_risk_compute <- function(x,confidence=0.95) {
  z <- pms_risk_returns(x)
  r <- z$ret[is.finite(z$ret)]
  if(length(r)<20L) return(list(ok=FALSE,n=length(r),message='유효 수익률 기록이 20개 미만입니다.'))
  curve <- cumprod(1+r)
  dd <- curve/cummax(c(1,curve))[-1]-1
  peakdate <- NA_character_
  bottom <- which.min(dd)
  currdd <- tail(dd,1)
  peak <- cummax(c(1,curve))[-1]
  indd <- dd<0
  runs <- rle(indd)
  durations <- runs$lengths[runs$values]
  current_duration <- if(any(!indd)) length(indd)-max(which(!indd)) else length(indd)
  if(!indd[length(indd)]) current_duration <- 0L
  sigma <- if(length(r)>1L) stats::sd(r) else NA_real_
  downside <- sqrt(mean(pmin(r,0)^2))
  ann <- prod(1+r)^(252/length(r))-1
  sharpe <- if(is.finite(sigma)&&sigma>0) mean(r)/sigma*sqrt(252) else NA_real_
  sortino <- if(is.finite(downside)&&downside>0) mean(r)/downside*sqrt(252) else NA_real_
  mdd <- min(dd)
  calmar <- if(mdd<0) ann/abs(mdd) else NA_real_
  q <- as.numeric(stats::quantile(r,1-confidence,names=FALSE,type=7))
  var <- max(0,-q)
  cvar <- max(0,-mean(r[r<=q]))
  # EWMA volatility forecast as an optional lightweight volatility alert.
  ew <- sigma^2
  for(v in tail(r,60L)) ew <- .94*ew+.06*v^2
  ewvol <- sqrt(ew)
  volratio <- if(is.finite(sigma)&&sigma>0) ewvol/sigma else NA_real_
  level <- if(!is.finite(volratio)) '측정 불가' else if(volratio<=1.2) 'NORMAL' else if(volratio<=1.8) 'ALERT' else 'CRITICAL'
  list(ok=TRUE,n=length(r),z=z,r=r,curve=curve,dd=dd,annual=ann,
       sigma=sigma,annvol=sigma*sqrt(252),mdd=mdd,currentdd=currdd,
       sharpe=sharpe,sortino=sortino,calmar=calmar,
       var=var,cvar=cvar,confidence=confidence,nav=tail(z$value,1),
       varwon=var*tail(z$value,1),cvarwon=cvar*tail(z$value,1),
       best=max(r),worst=min(r),maxduration=if(length(durations)) max(durations) else 0L,
       currentduration=current_duration,level=level,volratio=volratio,
       ewvol=ewvol,invalid=sum(!is.finite(z$ret)),
       nsource=sum(z$origin=='IMPORTED',na.rm=TRUE))
}
pms_risk_money <- function(x) if(length(x)!=1L || !is.finite(x)) '산출 불가' else paste0(format(round(x),big.mark=',',trim=TRUE,scientific=FALSE),'원')
pms_risk_pct <- function(x) if(length(x)!=1L || !is.finite(x)) '산출 불가' else sprintf('%+.2f%%',100*x)
pms_risk_num <- function(x) if(length(x)!=1L || !is.finite(x)) '산출 불가' else sprintf('%.2f',x)
pms_risk_cards <- function(s) {
 if(!isTRUE(s$ok)) return(shiny::tags$div(class='alert alert-warning',s$message))
 card <- function(k,v,note='') shiny::tags$div(style='flex:1 1 190px;background:#f5f8fc;border:1px solid #dbe5ef;border-radius:8px;padding:12px;min-width:180px;',
   shiny::tags$div(style='font-size:12px;color:#60738a;',k),
   shiny::tags$strong(style='font-size:22px;',v),
   shiny::tags$div(style='font-size:11px;color:#748294;margin-top:4px;',note))
 shiny::tags$div(
  shiny::tags$div(class='alert alert-warning',shiny::tags$b('투자수익률 추정치입니다. '),
   '원본 PMS의 원금변동 기반 수익률을 재현했습니다. 「평가액−평가손익」의 변화를 입출금 대용으로 사용하므로 매매실현손익·평가기준 변경이 있으면 실제 TWR과 달라집니다. ' ,
   '무위험수익률 0%, 252거래일 연환산 가정입니다. 금융상품별 원래 PMS와 값이 다를 수 있습니다.'),
  shiny::tags$div(style='display:flex;gap:10px;flex-wrap:wrap;margin-bottom:15px;',
    card('추정 연환산 수익률',pms_risk_pct(s$annual),'보정 추정 수익률의 누적 복리'),
    card('추정 MDD',pms_risk_pct(s$mdd),'추정 수익률 누적 곡선 기준'),
    card('현재 낙폭',pms_risk_pct(s$currentdd),'누적 곡선 최근 고점 대비'),
    card('연환산 변동성',pms_risk_pct(s$annvol),'표본 표준편차 × √252'),
    card('Sharpe',pms_risk_num(s$sharpe),'무위험수익률 0%'),
    card('Sortino',pms_risk_num(s$sortino),'하방편차 기반'),
    card('Calmar',pms_risk_num(s$calmar),'연환산 수익률 / |MDD|'),
    card('최장 회복 대기',paste0(s$maxduration,'관측일'),'고점 미회복 구간'),
    card('95% VaR (1관측일)',pms_risk_pct(s$var),pms_risk_money(s$varwon)),
    card('95% CVaR (1관측일)',pms_risk_pct(s$cvar),pms_risk_money(s$cvarwon)),
    card('변동성 위험 신호',s$level,paste0('EWMA/역사 변동성 = ',pms_risk_num(s$volratio),'배'))),
  shiny::tags$p(class='text-muted',sprintf('유효 관측수 %d개 · NA/극단값 제외 %d개 · CSV 이관 %d일 · 수익률 50%% 이상 절댓값 제거 규칙',s$n,s$invalid,s$nsource)),
  shiny::tags$p(style='font-size:12px;color:#60738a;',
   'VaR·CVaR는 과거 보정 추정 수익률의 경험분포를 이용한 1관측일 추정치입니다. 미래 최대 손실 한도가 아니며, 검증되지 않은 입출금 추정의 영향을 받습니다.'))
}
pms_risk_mc <- function(s,years=10,monthly=1000000,n=1500,mode='save',annual_withdraw=48000000) {
 if(!isTRUE(s$ok)) return(NULL)
 years <- max(1L,min(40L,as.integer(years)));n <- max(100L,min(5000L,as.integer(n)))
 mu <- mean(s$r)*252; sigma <- stats::sd(s$r)*sqrt(252)
 set.seed(20261018)
 terminal <- numeric(n);mdd <- numeric(n);ruined <- logical(n)
 steps <- years*12L
 show_idx <- unique(as.integer(round(seq(1,n,length.out=min(n,100L)))))
 stored_paths <- matrix(NA_real_,nrow=steps+1L,ncol=length(show_idx))
 colnames(stored_paths) <- paste0('scenario_',show_idx)
 for(i in seq_len(n)) {
  v <- s$nav; pk <- v; worst <- 0; is_ruined <- FALSE
  path_col <- match(i,show_idx)
  if(!is.na(path_col)) stored_paths[1L,path_col] <- v
  for(j in seq_len(steps)) {
   if(mode=='save') v <- v + monthly
   v <- v*exp((mu-.5*sigma^2)/12 + sigma/sqrt(12)*stats::rnorm(1))
   if(mode=='withdraw') v <- v - annual_withdraw/12
   if(v<=0){
     v<-0;is_ruined<-TRUE;worst <- -1
     if(!is.na(path_col)) stored_paths[(j+1L):(steps+1L),path_col] <- 0
     break
   }
   if(!is.na(path_col)) stored_paths[j+1L,path_col] <- v
   pk<-max(pk,v);worst<-min(worst,v/pk-1)
  }
  terminal[i]<-v;mdd[i]<-worst;ruined[i]<-is_ruined
 }
 list(terminal=terminal,mdd=mdd,ruin=mean(ruined),
      q=as.numeric(stats::quantile(terminal,c(.1,.5,.9))),
      mddq=as.numeric(stats::quantile(mdd,c(.1,.5,.9))),mu=mu,sigma=sigma,
      years=years,mode=mode,n=n,paths=stored_paths)
}


# Metric dictionary: extended descriptions intentionally separated from short cards.
pms_risk_guide <- function() {
  sections <- list(
    c('추정 현금흐름 보정 수익률', '총평가액에서 평가손익을 뺀 투자원금 대용값의 전일 대비 변화를 외부 순유입액으로 가정하여 일별 수익률을 계산합니다.', '실제 외부 입출금이나 실현손익을 구분하지 못합니다. TWR이라고 단정하지 않습니다.'),
    c('연환산 수익률', '유효한 일별 보정 추정 수익률을 복리로 누적하고 거래일 252일을 기준으로 연환산합니다.', '추정 수익률에 오류가 있거나 관측 기간이 짧으면 크게 왜곡됩니다.'),
    c('MDD · 현재 Drawdown', 'MDD는 누적 추정성과가 과거 최고점에서 가장 크게 하락했던 비율이고, 현재 DD는 지금 고점 대비 하락률입니다.', '예: MDD -13%는 분석기간에 고점 대비 최대 13% 하락한 구간이 있었다는 뜻입니다. 절대 손실 한도가 아닙니다.'),
    c('연환산 변동성 (Volatility)', '일별 수익률의 표준편차에 √252를 곱합니다. 수익률이 얼마나 크게 출렁였는지 나타냅니다.', '상승 방향 변동도 포함되며, 값이 낮다고 손실이 없다는 뜻은 아닙니다.'),
    c('Sharpe Ratio', '연평균 초과수익률을 총변동성으로 나눈 지표입니다. PMS2는 무위험수익률 0%를 가정합니다.', '일반적으로 동일한 기간·방법에서 값이 높을수록 위험 대비 성과가 좋다고 해석합니다.'),
    c('Sortino Ratio', 'Sharpe와 달리 목표수익률(현재 0%) 아래의 수익률만 하방 위험으로 간주합니다.', '수익률이 높아도 하락 구간이 크고 잦으면 수치가 낮아질 수 있습니다.'),
    c('Calmar Ratio', '연환산 추정수익률을 |MDD|로 나눕니다.', '손실 위험 대비 성장성을 살펴보지만 MDD가 아주 작으면 값이 불안정합니다.'),
    c('VaR 95% · 99% (1관측일)', '과거 일별 추정수익률에서 손실이 큰 하위 5% 또는 1%에 대응하는 분위수를 구하고 현재 평가액에 곱합니다.', '예: VaR 95% 2%는 역사적 경험분포상 약 5%의 관측일에는 2%보다 큰 손실이 나타났다는 뜻입니다. 확정 손실 상한이 아닙니다.'),
    c('CVaR 95% · 99% (1관측일)', 'VaR보다 손실이 큰 꼬리 구간의 평균 손실률입니다. Expected Shortfall이라고도 부릅니다.', '드문 급락 구간의 평균 피해를 보지만 표본이 적으면 추정 불안정성이 큽니다.'),
    c('DD Duration · 최장 회복 대기', '누적 추정성과가 이전 최고점을 회복하지 못한 연속 관측일 수를 측정합니다.', '달력 일수가 아니라 데이터가 있는 관측일 기준입니다. 장기 하락의 심리적 부담을 가늠할 때 유용합니다.'),
    c('EWMA 변동성 위험 신호', '최근 60개 수익률을 이용해 과거보다 최근 변동성을 더 크게 반영한 EWMA 변동성을 계산하고 역사적 표준편차와 비교합니다.', '비율 1.2 이하 NORMAL, 1.2~1.8 ALERT, 1.8 초과 CRITICAL. 이는 GARCH 예측이 아니며 통계적 참고 경고입니다.'),
    c('Monte Carlo · 미래 자산/인출', '과거 추정수익률 평균·변동성을 바탕으로 월 단위 로그정규 수익률 경로를 반복 생성해 잔액 분포를 모의 계산합니다.', '10%·50%·90% 분위수는 모형 가정하의 시나리오일 뿐 예측구간 보장이 아닙니다. 적립/인출 시점과 세금도 단순화됩니다.')
  )
  shiny::tags$details(style='margin:12px 0 18px;border:1px solid #dbe5ee;border-radius:9px;padding:13px;background:#f8fbff;',
    shiny::tags$summary(style='cursor:pointer;font-size:15px;font-weight:700;',
      '위험지표 상세 해설 펼쳐보기 · 계산식과 읽는 법'),
    shiny::tags$p(style='margin-top:10px;color:#52677e;',
      '아래 지표는 기록된 평가액·평가손익으로 계산한 추정 수익률에 기반합니다. 실제 입출금 장부가 들어오기 전에는 운용성과를 확정하는 데 사용하지 마세요.'),
    lapply(sections,function(z) shiny::tags$div(style='border-top:1px solid #e2ebf2;padding:10px 2px;',
      shiny::tags$strong(z[1]),
      shiny::tags$div(style='margin-top:4px;',shiny::tags$b('의미·계산: '),z[2]),
      shiny::tags$div(style='margin-top:4px;color:#5d7082;',shiny::tags$b('해석·주의: '),z[3]))))
}
