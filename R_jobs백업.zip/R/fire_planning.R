# FIRE long-term planning illustrations. All simulations use user-set assumptions,
# not price history or guaranteed returns. No tax, NHIS, pension taxation, or extra assets.
pms_fire_plan <- function(nav, age=53, end_age=95, monthly_spend=4000000,
                          inflation=.025, pension_age=65, pension_monthly=1900000,
                          fee=.003, shock=-.25) {
  vals <- c(nav,age,end_age,monthly_spend,inflation,pension_age,pension_monthly,fee,shock)
  if(length(vals)!=9L || any(!is.finite(vals)) || nav<=0 || age<18 || end_age<=age || end_age>110 ||
     monthly_spend<0 || inflation<0 || inflation>.30 || pension_monthly<0 ||
     fee<0 || fee>.1 || shock<=-1 || shock>0) return(list(paths=data.frame(),summary=data.frame()))
  years <- seq_len(as.integer(end_age-age))
  run_one <- function(label,base_return,crash=FALSE) {
    bal <- nav
    rows <- vector('list',length(years))
    for (y in years) {
      current_age <- age+y-1
      expense <- monthly_spend*12*(1+inflation)^(y-1)
      pension <- if (current_age>=pension_age) pension_monthly*12 else 0
      withdrawal <- max(0,expense-pension)
      assumed_return <- if(crash && y==1L) shock else base_return
      before <- bal
      end_balance <- max(0, bal*(1+assumed_return-fee)-withdrawal)
      rows[[y]] <- data.frame(시나리오=label,경과연수=y,나이=current_age,
        연간생활비=round(expense),연간연금=round(pension),연간필요인출=round(withdrawal),
        연말잔고=round(end_balance),연초잔고=round(before),
        고갈발생=(before>0 && end_balance<=0 && withdrawal>0),check.names=FALSE)
      bal <- end_balance
    }
    do.call(rbind,rows)
  }
  paths <- do.call(rbind,list(run_one('보수적 · 연 3%',.03),run_one('기준 · 연 5%',.05),
    run_one('낙관적 · 연 7%',.07),run_one('초기 급락 · 첫해 -25% 이후 연 5%',.05,TRUE)))
  summary <- do.call(rbind,lapply(split(paths,paths$시나리오),function(d) {
    empty <- which(d$고갈발생)
    data.frame(시나리오=d$시나리오[1],잔고고갈_나이=if(length(empty))
      paste0(d$나이[empty[1]],'세') else paste0(end_age,'세까지 미고갈'),
      목표연령_잔고=tail(d$연말잔고,1),check.names=FALSE)
  }))
  rownames(summary) <- NULL
  order_labels <- c('보수적 · 연 3%','기준 · 연 5%','낙관적 · 연 7%','초기 급락 · 첫해 -25% 이후 연 5%')
  summary <- summary[match(order_labels,summary$시나리오),,drop=FALSE]
  list(paths=paths,summary=summary)
}

pms_fire_plan_ui <- function(plan,nav,monthly_spend,age,pension_age,pension_monthly) {
  if(!nrow(plan$paths)) return(shiny::tags$div(class='alert alert-warning',
    '계산할 수 없습니다. 입력값과 시세 누락 여부를 확인해 주세요.'))
  base <- plan$paths[plan$paths$시나리오=='기준 · 연 5%',,drop=FALSE]
  first <- base[1,,drop=FALSE]
  rate <- if(nav>0) first$연간필요인출/nav*100 else NA_real_
  cards <- list(
    c('월 생활비 목표',pms_fire_money(monthly_spend)),
    c('은퇴 첫해 필요 인출액',pms_fire_money(first$연간필요인출)),
    c('은퇴 첫해 실질 인출률',sprintf('%.2f%%',rate)),
    c('첫해 인출액 기준 현금 2년분',pms_fire_money(first$연간필요인출*2)))
  shiny::tagList(
    shiny::tags$div(class='row',lapply(cards,function(v)shiny::tags$div(class='col-sm-3',
      shiny::tags$div(style='border:1px solid #ddd;border-radius:8px;padding:12px;margin:6px 0;',
        shiny::tags$div(style='font-size:12px;color:#555;',v[[1]]),
        shiny::tags$strong(style='font-size:18px;',v[[2]]))))),
    shiny::tags$p(class='text-muted',style='font-size:12px;',sprintf(
      '은퇴 시작 %d세, 연금 개시 %d세·월 %s(명목 고정). 계산은 금융자산 평가액만 사용하고 현금·부동산·퇴직금·세금·건강보험료는 별도로 추가하지 않습니다.',
      age,pension_age,pms_fire_money(pension_monthly))))
}
