# PMS2 v0.5.95: deterministic Korean spoken briefing from saved data only.
# No API calls, no LLM-generated financial assertions, no SQLite writes.
pms_voice_brief <- function(con) {
  say_won <- function(x) {
    if (length(x) != 1L || !is.finite(x)) return('집계할 수 없습니다')
    x <- round(x); neg <- if (x < 0) '마이너스 ' else ''
    x <- abs(x)
    eok <- floor(x / 1e8); man <- floor((x %% 1e8) / 1e4); rest <- round(x %% 1e4)
    bits <- character()
    if (eok > 0) bits <- c(bits, paste0(format(eok, big.mark=',', scientific=FALSE, trim=TRUE), '억'))
    if (man > 0) bits <- c(bits, paste0(format(man, big.mark=',', scientific=FALSE, trim=TRUE), '만'))
    if (rest > 0 && eok == 0) bits <- c(bits, as.character(rest))
    if (!length(bits)) bits <- '영'
    paste0(neg, paste(bits, collapse=' '), ' 원')
  }
  say_pct <- function(x) if (length(x) == 1L && is.finite(x))
    paste0(format(round(abs(x),1), nsmall=1, trim=TRUE, scientific=FALSE),' 퍼센트') else '산출 불가'
  dat <- pms_valuation(con, include_zero=FALSE)
  dat <- dat[is.finite(dat$quantity) & dat$quantity > 0,,drop=FALSE]
  good <- is.finite(dat$market_value_krw)
  nav <- if (any(good)) sum(dat$market_value_krw[good]) else NA_real_
  pnl_good <- good & is.finite(dat$profit_krw)
  profit <- if (any(pnl_good)) sum(dat$profit_krw[pnl_good]) else NA_real_
  count <- nrow(dat)
  missing <- sum(!good)
  today <- format(Sys.Date(), '%Y년 %m월 %d일')
  sections <- c(
    paste0('안녕하세요. 개인금융자산 통계연구소, 피엠에스 투 입니다. ',today,' 금융자산 브리핑을 시작합니다.'),
    paste0('먼저 현재 저장된 시세 기준으로 보유 종목은 ',count,'건이고, 총 금융자산 평가액은 ',say_won(nav),'입니다. ',
           if(is.finite(profit)) paste0('보유종목의 미실현 평가손익은 ',say_won(profit),'입니다. ') else '',
           if(missing > 0) paste0('주의할 점은 ',missing,'건의 종목에 유효한 시세가 없어 일부 평가액이 빠졌을 수 있다는 것입니다.') else
             '현재 보유종목 중 평가액 산출에 필요한 시세가 없는 건은 없습니다.'),
    '이 금액은 보유증권 평가액으로, 계좌 외 현금이나 부동산을 포함한 전체 순자산을 뜻하지는 않습니다.'
  )
  if(any(good) && is.finite(nav) && nav>0) {
    grouped <- stats::aggregate(dat$market_value_krw[good],
       by=list(종목=as.character(dat$name[good])), FUN=sum)
    grouped <- grouped[order(-grouped$x),,drop=FALSE]
    top <- head(grouped,3)
    names <- paste(sprintf('%s가 %.1f 퍼센트',top$종목,100*top$x/nav),collapse=', ')
    sections <- c(sections,paste0('종목 집중도를 살펴보겠습니다. 평가액 상위 종목은 ',names,'입니다. ',
       '특정 종목에 집중된 비중은 하락장에서 위험 요인이 될 수 있습니다.'))
  }
  hist <- tryCatch(pms_trajectory_read(con),error=function(e) NULL)
  if(is.data.frame(hist) && nrow(hist) >= 20L) {
    recent <- hist[is.finite(hist$value) & is.finite(hist$profit),,drop=FALSE]
    if(nrow(recent) >= 20L) {
      risk <- tryCatch(pms_risk_compute(recent),error=function(e) NULL)
      if(is.list(risk) && isTRUE(risk$ok)) {
        sections <- c(sections,paste0('다음은 저장된 시계열에서 계산한 위험 분석입니다. ',
          '현금흐름 변화를 추정해서 보정한 연환산 수익률은 ',
          if(risk$annual >= 0) '플러스 ' else '마이너스 ',say_pct(risk$annual),
          ', 최대낙폭은 ',say_pct(risk$mdd),', 샤프 지수는 ',
          format(round(risk$sharpe,2),nsmall=2),'입니다. ',
          '다만 실제 입출금 장부가 없어 원금 변화를 현금흐름으로 추정했으므로, 확정 수익률이 아니라 참고용 분석입니다.'))
      }
    }
  }
  da <- tryCatch(pms_dividend_account_totals(con),error=function(e) NULL)
  if(is.data.frame(da) && nrow(da) && all(c('계좌유형','최근1년_배당금_원화_추정합계') %in% names(da))) {
    v <- suppressWarnings(as.numeric(da$최근1년_배당금_원화_추정합계[as.character(da$계좌유형)=='전체 합계']))
    if(length(v) && is.finite(v[1])) sections <- c(sections,
       paste0('배당 현황입니다. 최근 일 년간 저장된 자료를 기준으로 추정한 배당금 합계는 ',say_won(v[1]),
       '입니다. 배당락일과 실제 지급일은 다를 수 있고, 원천징수 및 계좌별 세금 처리도 별도로 확인해야 합니다.'))
  }
  sections <- c(sections,
    '이번 브리핑에서 투자수익률은 시장 변화와 자금 유입의 영향을 분리하기 위해 추정한 수치입니다. ',
    '주가 급등락이 있는 날에는 기준 시각과 환율을 먼저 확인하고, 목표 자산배분과 최대낙폭을 함께 점검하시기 바랍니다.',
    '이상으로 개인금융자산 통계연구소의 브리핑을 마치겠습니다. 감사합니다.')
  paste(sections,collapse='\n\n')
}
