# v0.5.62 - descriptive risk statistics from aggregate valuation archives.
# No recorded deposits/withdrawals: these are NOT TWR or investment returns.
pms_performance_calc <- function(x) {
  x <- x[!is.na(x$date) & is.finite(x$value) & x$value > 0,,drop=FALSE]
  x <- x[order(x$date),,drop=FALSE]
  if(nrow(x)) x <- x[!duplicated(x$date,fromLast=TRUE),,drop=FALSE]
  if(nrow(x)<2L) return(list(data=x,stats=list(n=nrow(x))))
  v <- x$value; n <- length(v)
  r <- v[-1]/v[-n]-1
  peak <- cummax(v); dd <- v/peak-1
  x$drawdown_pct <- 100*dd
  x$index100 <- 100*v/v[1]
  x$change_pct <- c(NA_real_,100*r)
  # Reporting cadence may contain weekends/non-trading days. Report observation-based
  # dispersion and avoid annualized Sharpe/Sortino without actual trading-day returns.
  vol <- if(length(r)>1L) stats::sd(r) else NA_real_
  downside <- sqrt(mean(pmin(r,0)^2))
  best <- max(r); worst <- min(r)
  bottom <- which.min(dd); top <- which.max(v[seq_len(bottom)])
  total_change <- v[n]/v[1]-1
  days <- as.numeric(x$date[n]-x$date[1])
  annualized_value_growth <- if(days>0) (v[n]/v[1])^(365.25/days)-1 else NA_real_
  # Illustrative zero-risk-free ratios computed on observations; NOT Sharpe/Sortino of investments.
  proxy_sharpe <- if(is.finite(vol) && vol>0) mean(r)/vol else NA_real_
  proxy_sortino <- if(is.finite(downside) && downside>0) mean(r)/downside else NA_real_
  stats <- list(n=n,from=x$date[1],to=x$date[n],value_first=v[1],value_last=v[n],
    growth=total_change,annualized_growth=annualized_value_growth,
    mdd=min(dd),mdd_peak=x$date[top],mdd_trough=x$date[bottom],
    current_dd=tail(dd,1),daily_sd=vol,best=best,worst=worst,
    positive=sum(r>0),negative=sum(r<0),unchanged=sum(r==0),
    max_value=max(v),min_value=min(v),
    proxy_sharpe=proxy_sharpe,proxy_sortino=proxy_sortino,
    gap_days=as.numeric(diff(x$date)))
  list(data=x,stats=stats)
}
pms_perf_fmt_pct <- function(v,digits=2L) if(length(v)!=1L || !is.finite(v)) '산출 불가' else sprintf(paste0('%+.',digits,'f%%'),100*v)
pms_perf_fmt_num <- function(v,digits=3L) if(length(v)!=1L || !is.finite(v)) '산출 불가' else sprintf(paste0('%+.',digits,'f'),v)

# v0.6.34: trend charts use actual elapsed calendar days (not row numbers).
pms_perf_trend_chart <- function(x, metric, label, color, unit='원/일') {
  if(!metric %in% names(x)) {
    return(shiny::tags$div(class='alert alert-warning',paste(label,'데이터 열 없음')))
  }
  dates <- as.Date(x$date)
  values <- suppressWarnings(as.numeric(x[[metric]]))
  good <- !is.na(dates) & is.finite(values)
  dates <- dates[good]; values <- values[good]
  if(length(values)<2L || length(unique(dates))<2L) {
    return(shiny::tags$div(class='alert alert-info',paste(label,'추세선을 계산할 날짜별 자료 부족')))
  }
  t <- as.numeric(dates-min(dates))
  slope <- stats::cov(t,values)/stats::var(t)
  intercept <- mean(values)-slope*mean(t)
  fitted <- intercept+slope*t
  # Keep both series in the same physical units; pad against flat observations.
  limits <- range(c(values,fitted),finite=TRUE)
  span <- diff(limits)
  if(!is.finite(span) || span<=0) span <- max(abs(limits),1)*0.02
  limits <- limits + c(-0.10,0.10)*span
  left <- 85; right <- 980; top <- 26; bottom <- 280
  xcoord <- function(q) left+(q-min(t))/(max(t)-min(t))*(right-left)
  ycoord <- function(q) bottom-(q-limits[1])/diff(limits)*(bottom-top)
  points <- function(xx,yy) paste(sprintf('%.2f,%.2f',xx,yy),collapse=' ')
  axis_values <- seq(limits[1],limits[2],length.out=5)
  fmt_y <- function(z) {
    if(metric %in% c('value','profit')) sprintf('%.2f억',z/1e8)
    else sprintf('%.2f',z)
  }
  colors <- list(line=color,trend='#cc7133')
  polyline <- function(pts,col,width,dash=NULL) {
    args <- list(points=pts,fill='none',stroke=col,`stroke-width`=width,
                 `stroke-linejoin`='round',`stroke-linecap`='round')
    if(!is.null(dash)) args[['stroke-dasharray']] <- dash
    do.call(shiny::tags$polyline,args)
  }
  gridlines <- lapply(axis_values,function(z) shiny::tagList(
    shiny::tags$line(x1=left,x2=right,y1=ycoord(z),y2=ycoord(z),stroke='#dce3ea',`stroke-width`='1'),
    shiny::tags$text(x=left-10,y=ycoord(z)+4,`text-anchor`='end',fill='#566879',`font-size`='12',fmt_y(z))))
  date_ticks <- unique(round(seq(1,length(t),length.out=min(6,length(t)))))
  xlabels <- lapply(date_ticks,function(j) shiny::tags$text(
    x=xcoord(t[j]),y=bottom+24,`text-anchor`='middle',fill='#566879',`font-size`='12',format(dates[j],'%Y-%m-%d')))
  fmt_slope <- if(unit=='원/일') format(round(abs(slope)),big.mark=',',scientific=FALSE,trim=TRUE)
               else sprintf('%.4f',abs(slope))
  slope_text <- paste0(if(slope>0) '+' else if(slope<0) '-' else '',fmt_slope,' ',unit)
  shiny::tags$div(style='margin:14px 0;padding:12px;border:1px solid #d8e1e9;border-radius:8px;',
    shiny::tags$div(style='font-weight:700;margin-bottom:7px;',label),
    shiny::tags$svg(viewBox='0 0 1030 320',style='width:100%;height:auto;max-height:360px;display:block;',
      role='img',`aria-label`=paste(label,'실제 추이와 선형회귀 점선'),
      gridlines,
      polyline(points(xcoord(t),ycoord(values)),colors$line,'2.8'),
      polyline(points(xcoord(t),ycoord(fitted)),colors$trend,'2.4','8 5'),
      xlabels,
      shiny::tags$text(x=right,y=14,`text-anchor`='end',fill=colors$line,`font-size`='13','━━ 실제 기록'),
      shiny::tags$text(x=right-113,y=14,`text-anchor`='end',fill=colors$trend,`font-size`='13','┄ 선형 추세선')),
    shiny::tags$div(style='font-size:13px;margin-top:4px;font-weight:700;',
      paste0('선형회귀 일평균 기울기: ',slope_text)),
    shiny::tags$div(style='color:#68798a;font-size:12px;',
      '경과 달력일 기준 최소제곱 회귀 기울기입니다. 추가 납입·인출 영향을 포함하므로 운용수익률은 아닙니다.'))
}

pms_performance_panel <- function(result) {
  x <- result$data; s <- result$stats
  if(s$n<2L) return(shiny::tags$div(class='alert alert-info','분석할 평가액 기록이 2개 이상 필요합니다.'))
  card <- function(title,value,note='') shiny::tags$div(style='flex:1 1 195px;min-width:195px;padding:14px;border-radius:9px;border:1px solid #dae5ee;background:#f8fafd;',
    shiny::tags$div(style='font-size:12px;color:#64758a;',title),
    shiny::tags$strong(style='font-size:20px;',value),
    shiny::tags$div(style='font-size:11px;color:#687a88;margin-top:5px;',note))
  gap <- s$gap_days
  irregular <- sum(gap>4L,na.rm=TRUE)
  shiny::tags$div(
    shiny::tags$div(class='alert alert-warning',
      shiny::tags$b('해석 주의: 운용수익률 아님. '),
      '현재 자료는 매일의 총평가액·미실현 평가손익만 기록합니다. 입출금, 매매로 인한 원금 변화와 현금·예수금이 포함되지 않아 아래 평가액 증감 기반 MDD·변동성·비율은 실제 투자성과 지표가 아닙니다. ',
      '정확한 TWR·Sharpe·Sortino·Calmar 및 수익률 기준 MDD는 외부 현금흐름과 일별 총자산 기준가가 수집된 이후 산출해야 합니다.'),
    shiny::tags$div(style='display:flex;flex-wrap:wrap;gap:10px;margin:12px 0;',
      card('최신 총평가액',pms_traj_money(s$value_last),sprintf('%s 기준',as.character(s$to))),
      card('기간 평가액 증감률',pms_perf_fmt_pct(s$growth),'입출금 등을 포함한 자산 증감'),
      card('평가액 기준 최대낙폭(MDD)',pms_perf_fmt_pct(s$mdd),sprintf('고점 %s → 저점 %s',s$mdd_peak,s$mdd_trough)),
      card('현재 고점 대비 낙폭',pms_perf_fmt_pct(s$current_dd),'기간 최고 평가액 대비'),
      card('관측간 변화율 표준편차',pms_perf_fmt_pct(s$daily_sd),'연율화하지 않음 · 불규칙 관측 주의'),
      card('최대 상승 / 하락 관측',paste(pms_perf_fmt_pct(s$best),'/',pms_perf_fmt_pct(s$worst)),'연속 기록 간 평가액 변화'),
      card('변화율 기반 평균/변동성',pms_perf_fmt_num(s$proxy_sharpe),'무위험수익률 0 · 비연율화 · 참고만'),
      card('변화율 기반 평균/하방편차',pms_perf_fmt_num(s$proxy_sortino),'비연율화 · 실제 Sortino 아님')),
    pms_perf_trend_chart(x,metric='value',label='총평가액 추이 · 원화',color='#286db0',unit='원/일'),
    pms_perf_trend_chart(x,metric='profit',label='미실현 평가손익 추이 · 원화',color='#cc8d3d',unit='원/일'),
    pms_perf_trend_chart(x,metric='index100',label='평가액 지수 (첫날=100, 자금유입 혼재)',color='#4a9a80',unit='지수포인트/일'),
    pms_trajectory_svg(x,col='#cf5757',metric='drawdown_pct',label='최고점 대비 하락률 (%)'),
    shiny::tags$div(style='padding:12px;border:1px solid #e0e7ef;border-radius:9px;margin:12px 0;',
      shiny::tags$h4('추가 관찰 지표'),
      shiny::tags$p(sprintf('분석 날짜: %s ~ %s / 관측 %d회 / 연속 관측 사이 4일 초과 공백 %d회',s$from,s$to,s$n,irregular)),
      shiny::tags$p(sprintf('평가액 최고 %s · 최저 %s',pms_traj_money(s$max_value),pms_traj_money(s$min_value))),
      shiny::tags$p(sprintf('연속 관측 증가 %d회 · 감소 %d회 · 동일 %d회',s$positive,s$negative,s$unchanged)),
      shiny::tags$p('기간 평가액 증가율의 연환산값은 입출금의 영향을 크게 받으므로 실제 CAGR로 표시하지 않습니다.')),
    shiny::tags$p(style='font-size:12px;color:#68798a;',
      '일부 기록은 주말·공휴일을 포함하고 날짜 간격이 일정하지 않습니다. 변동성은 연속 관측치 기준이며 252거래일 연율화하지 않았습니다.'))
}
