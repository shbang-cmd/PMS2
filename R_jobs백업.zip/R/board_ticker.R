# PMS2 v0.5.96 - fixed lower-edge market and holdings ticker.
# All displayed quotes come from stored data; no fabricated fallback prices.
pms_ticker_init <- function(con) {
  DBI::dbExecute(con,"CREATE TABLE IF NOT EXISTS market_index_ticker (
    ticker TEXT PRIMARY KEY, label TEXT, current_price REAL, previous_close REAL,
    quote_date TEXT, previous_date TEXT, checked_at TEXT, source TEXT)")
}

pms_ticker_collect_indices <- function(con) {
  pms_ticker_init(con)
  if(!requireNamespace('quantmod',quietly=TRUE)) return('quantmod 미설치: 지수 시세는 이전 저장값 사용')
  symbols <- c('^KS11'='코스피','^GSPC'='S&P500','^NDX'='나스닥100')
  notes <- character()
  for(sym in names(symbols)) {
    result <- tryCatch({
      x <- suppressWarnings(quantmod::getSymbols(sym,src='yahoo',auto.assign=FALSE,
        from=Sys.Date()-18L,to=Sys.Date()+1L, warnings=FALSE))
      cls <- as.numeric(quantmod::Cl(x)); dates <- as.Date(zoo::index(x))
      ok <- is.finite(cls) & cls > 0 & !is.na(dates)
      cls<-cls[ok]; dates<-dates[ok]
      if(length(cls)<2) stop('최근 종가 2개 미만')
      DBI::dbExecute(con,"INSERT INTO market_index_ticker
        (ticker,label,current_price,previous_close,quote_date,previous_date,checked_at,source)
        VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(ticker) DO UPDATE SET
        current_price=excluded.current_price,previous_close=excluded.previous_close,
        quote_date=excluded.quote_date,previous_date=excluded.previous_date,
        checked_at=excluded.checked_at,source=excluded.source",
        params=list(sym,unname(symbols[[sym]]),tail(cls,1),tail(cls,2)[1],
          as.character(tail(dates,1)),as.character(tail(dates,2)[1]),
          format(Sys.time(),'%Y-%m-%d %H:%M:%S'),'Yahoo 일별 종가'))
      paste0(symbols[[sym]],' 저장')
    },error=function(e) paste0(symbols[[sym]],' 실패: ',conditionMessage(e)))
    notes <- c(notes,result)
  }
  paste(notes,collapse=' · ')
}

pms_ticker_entries <- function(con,board) {
  pms_ticker_init(con)
  idx <- DBI::dbGetQuery(con,'SELECT * FROM market_index_ticker')
  fx <- tryCatch(DBI::dbGetQuery(con,"SELECT rate,quoted_at FROM fx_rates WHERE pair='USD/KRW' LIMIT 1"),error=function(e)data.frame())
  oldfx <- tryCatch(DBI::dbGetQuery(con,'SELECT rate_date,rate FROM usdkrw_daily WHERE rate>0 ORDER BY rate_date DESC LIMIT 2'),error=function(e)data.frame())
  mk <- function(label,px=NA_real_,prev=NA_real_,date='',digits=2) {
    px <- suppressWarnings(as.numeric(px)); prev <- suppressWarnings(as.numeric(prev))
    if(!length(px)||!is.finite(px[1])||px[1]<=0) return(list(label=label,value='시세 없음',pct=NA_real_,date=''))
    px<-px[1]; prev<-if(length(prev))prev[1] else NA_real_
    pct<-if(is.finite(prev)&&prev>0) 100*(px/prev-1) else NA_real_
    list(label=label,value=formatC(px,format='f',digits=digits,big.mark=','),pct=pct,date=as.character(date))
  }
  fxpx <- if(nrow(fx))fx$rate[1] else if(nrow(oldfx))oldfx$rate[1] else NA_real_
  # For an intraday USD/KRW quote, use the latest earlier daily close, not its own last date.
  fxdate <- if(nrow(fx))substr(as.character(fx$quoted_at[1]),1,10) else if(nrow(oldfx))as.character(oldfx$rate_date[1]) else ''
  prevfx <- NA_real_
  if(nrow(oldfx)) {
    j <- which(as.character(oldfx$rate_date) < fxdate)
    if(length(j)) prevfx <- oldfx$rate[j[1]]
    else if(nrow(oldfx)>1 && is.finite(fxpx) && abs(fxpx-oldfx$rate[1])<1e-8) prevfx <- oldfx$rate[2]
  }
  out <- list(mk('원달러환율',fxpx,prevfx,fxdate,2))
  for(sym in c('^KS11','^GSPC','^NDX')) {
    row <- idx[idx$ticker==sym,,drop=FALSE]
    label <- switch(sym,'^KS11'='코스피','^GSPC'='S&P500','^NDX'='나스닥100')
    out[[length(out)+1L]] <- if(nrow(row))mk(label,row$current_price[1],row$previous_close[1],row$quote_date[1],2) else mk(label)
  }
  if(!is.null(board)&&nrow(board)) {
    for(i in seq_len(nrow(board))) {
      r<-board[i,,drop=FALSE]
      label<-if(!is.na(r$name[1])&&nzchar(as.character(r$name[1])))as.character(r$name[1]) else as.character(r$symbol[1])
      out[[length(out)+1L]]<-mk(label,r$price[1],r$previous_close[1],r$quote_date[1],if(r$country[1]=='KR')0 else 2)
    }
  }
  out
}

# Current holdings and stored snapshots are the only sources; no HTTP during rendering.
pms_summary_ticker_entries <- function(con,board=NULL) {
  safe <- function(expr,default=NA_real_) tryCatch(expr,error=function(e)default)
  fmt <- function(n) if(length(n)!=1 || !is.finite(n)) '미산출' else
    paste0(format(round(n),big.mark=',',trim=TRUE,scientific=FALSE),'원')
  nav <- safe(pms_valuation(con,include_zero=FALSE),NULL)
  active <- !is.null(nav) && nrow(nav)>0
  good <- if(active) is.finite(nav$market_value_krw) & nav$quantity>0 else logical(0)
  complete <- active && all(good) && any(good)
  total <- if(complete) sum(nav$market_value_krw) else NA_real_
  # Count distinct invested tickers, not the sum of share quantities. Across brokers,
  # same country+symbol counts as one; KR and US tickers remain distinct.
  symbols <- if(active) {
    selected <- is.finite(nav$quantity) & nav$quantity>0 & !is.na(nav$country) &
      !is.na(nav$symbol) & nzchar(trimws(as.character(nav$symbol)))
    unique(paste(nav$country[selected],nav$symbol[selected],sep=':'))
  } else character()
  symbols <- symbols[!is.na(symbols) & nzchar(symbols)]
  holdings_count <- if(active) length(symbols) else NA_integer_
  holdings_label <- if(is.finite(holdings_count)) paste0(format(holdings_count,big.mark=','),'종목') else '미산출'
  today <- Sys.Date()
  past <- safe(DBI::dbGetQuery(con,'SELECT snapshot_date,securities_value_krw FROM snapshot_daily WHERE snapshot_date<? AND securities_value_krw>0 ORDER BY snapshot_date DESC LIMIT 1',params=list(as.character(today))),NULL)
  # Comparison against prior recorded portfolio value, not a fully reconstructed previous-day valuation.
  # Do not compare against a stale/old snapshot and label it as yesterday.
  daily_delta <- if(is.finite(total) && !is.null(past) && nrow(past) &&
      as.character(as.Date(past$snapshot_date[1]))==as.character(today-1L))
      total-as.numeric(past$securities_value_krw[1]) else NA_real_
  dmonth <- format(today,'%Y-%m')
  monthly <- safe(pms_dividend_monthly_accounts(con),NULL)
  thisdiv <- if(!is.null(monthly) && nrow(monthly) && any(monthly$월==dmonth))
    sum(monthly$금액[monthly$월==dmonth],na.rm=TRUE) else NA_real_
  # Missing FX must not silently become a complete dividend sum.
  if(!is.null(monthly) && nrow(monthly) && any(monthly$월==dmonth) &&
       any(monthly$환율누락건수[monthly$월==dmonth]>0,na.rm=TRUE)) thisdiv<-NA_real_
  change <- safe(pms_valuation_change_12m(con),NULL)
  monthly_growth <- if(!is.null(change)) change$monthly else NA_real_
  dividends <- safe(pms_dividend_account_totals(con),NULL)
  drow <- if(!is.null(dividends) && nrow(dividends)) dividends[dividends$계좌유형=='전체 합계',,drop=FALSE] else NULL
  ydiv <- if(!is.null(drow) && nrow(drow) && isTRUE(drow$미완료건수[1]==0)) as.numeric(drow$최근1년_배당금_원화_추정합계[1]) else NA_real_
  mk <- function(label,value,change=NA_real_,note='') list(label=label,value=value,change=change,note=note)
  list(mk('전체 평가액',fmt(total),note='현금 제외'),
       mk('전일대비 증감액',fmt(daily_delta),daily_delta,if(!is.finite(daily_delta))'전일 스냅샷 없음' else '전일 스냅샷 대비'),
       mk('보유종목수',holdings_label,note='계좌 중복 제거'),
       mk('당월 예상 배당금',fmt(thisdiv),note='세전 · 배당락일 기준'),
       mk('최근 1년 월평균 증가액',fmt(monthly_growth),monthly_growth,note='입출금 포함 평가액 변화'),
       mk('최근 1년 배당총액',fmt(ydiv),note='현 보유 기준 세전 추정'))
}

pms_ticker_ui <- function(entries,summary=NULL) {
  mkspan <- function(x) {
    cls <- if(!is.finite(x$pct))'pms-ticker-none' else if(x$pct>0)'pms-ticker-up' else if(x$pct<0)'pms-ticker-down' else 'pms-ticker-flat'
    change <- if(!is.finite(x$pct))' 기준가 없음' else sprintf(' %+.2f%%',x$pct)
    shiny::tags$span(class=paste('pms-ticker-item',cls),
      shiny::tags$b(x$label),paste0(' ',x$value),shiny::tags$strong(change),
      if(length(x$date)&&!is.na(x$date)&&nzchar(x$date))shiny::tags$small(paste0(' (',x$date,')')))
  }
  summary_span <- function(x) {
    cls <- if(!is.finite(x$change))'pms-ticker-none' else if(x$change>0)'pms-ticker-up' else if(x$change<0)'pms-ticker-down' else 'pms-ticker-flat'
    shiny::tags$span(class=paste('pms-ticker-item',cls),
      shiny::tags$b(x$label),shiny::tags$strong(x$value),
      if(nzchar(x$note))shiny::tags$small(paste0(' (',x$note,')')))
  }
  summary_ui <- shiny::tags$div(class='pms-ticker-shell pms-summary-shell',role='region',`aria-label`='자산 요약 스크롤 전광판',
    shiny::tags$span(class='pms-ticker-caption','자산 요약'),
    shiny::tags$div(class='pms-ticker-window',
      shiny::tags$div(class='pms-ticker-runner',
        shiny::tags$div(class='pms-ticker-sequence',lapply(summary,summary_span)),
        shiny::tags$div(class='pms-ticker-sequence',`aria-hidden`='true',lapply(summary,summary_span)))))
  market_ui <- shiny::tags$div(class='pms-ticker-shell', role='region',`aria-label`='시장지수 및 보유종목 전일대비 흐름',
    shiny::tags$span(class='pms-ticker-caption','MARKET  ·  보유종목'),
    shiny::tags$div(class='pms-ticker-window',
      shiny::tags$div(class='pms-ticker-runner',
        shiny::tags$div(class='pms-ticker-sequence',lapply(entries,mkspan)),
        shiny::tags$div(class='pms-ticker-sequence',`aria-hidden`='true',lapply(entries,mkspan)))))
  shiny::tagList(summary_ui,market_ui)
}
