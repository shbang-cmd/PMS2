# PMS2 v0.6.10: UNCLASSIFIED exposures counted as CORE (general equities), no DB rewrite.
# PMS2 v0.6.09: class name and percent inside 100% horizontal allocation bars.
# PMS2 v0.6.08 - two horizontal 100% stacked current/target bars.
# PMS2 v0.6.07 - 100% stacked two-bar current/target distribution.
# PMS2 v0.6.06 - effective automatic strategy classification; manual mapping takes precedence.
# PMS2 diversified allocation module. The user's existing holdings are never rewritten.
pms_strategy_choices <- function() c('미분류'='UNCLASSIFIED','일반 주식 (SPY 등)'='CORE','SCHD / 미국배당다우존스 ETF'='SCHD','나스닥100'='NASDAQ100','TQQQ'='TQQQ','금'='GOLD','채권'='BOND','현금성'='CASH')
pms_strategy_target <- c(CORE=.36,SCHD=.20,NASDAQ100=.15,TQQQ=.10,GOLD=.10,BOND=.05,CASH=.04)
pms_strategy_init <- function(con) {
  DBI::dbExecute(con,"CREATE TABLE IF NOT EXISTS holdings_strategy (holding_id INTEGER PRIMARY KEY, strategy_group TEXT NOT NULL)")
}
pms_strategy_data <- function(con) {
  pms_strategy_init(con)
  d <- pms_valuation(con,include_zero=FALSE)
  if(!nrow(d)) return(d)
  m <- DBI::dbGetQuery(con,'SELECT holding_id,strategy_group FROM holdings_strategy')
  d$strategy_group <- as.character(m$strategy_group[match(d$id,m$holding_id)])
  # Propose deterministic classification only for unambiguous categories.
  unset <- is.na(d$strategy_group) | !(d$strategy_group %in% names(pms_strategy_target))
  symbol <- toupper(trimws(as.character(d$symbol)))
  names_ <- toupper(trimws(as.character(d$name)))
  proposed <- rep('UNCLASSIFIED',nrow(d))
  klass <- toupper(as.character(d$asset_class))
  # Specific instrument rules take precedence over broad asset-class labels.
  proposed[klass=='GOLD'] <- 'GOLD'
  proposed[klass=='BOND'] <- 'BOND'
  proposed[klass=='CASH'] <- 'CASH'
  # Gold holdings often arrive from CSV tagged as STOCK.
  proposed[grepl('금현물|KRX금|GOLD', names_) &
             (grepl('금현물|KRX금', names_) | klass=='GOLD')] <- 'GOLD'
  proposed[symbol=='TQQQ'] <- 'TQQQ'
  proposed[symbol=='SCHD' | grepl('미국\\s*배당\\s*다우존스|US\\s*DIVIDEND\\s*EQUITY',names_,perl=TRUE)] <- 'SCHD'
  proposed[symbol %in% c('QQQ','QQQM') |
             grepl('나스닥\\s*100|NASDAQ\\s*100',names_,perl=TRUE)] <- 'NASDAQ100'
  proposed[symbol %in% c('SPY','VOO','IVV','SPLG','SPYM') |
             grepl('S&P\\s*500|SNP\\s*500|에스앤피\\s*500',names_,perl=TRUE)] <- 'CORE'
  # User preference: all otherwise unclassified holdings belong to CORE.
  # This changes the effective allocation, not the underlying holdings or user mapping table.
  proposed[proposed=='UNCLASSIFIED'] <- 'CORE'
  d$suggested_group <- proposed
  d$classification_source <- ifelse(!unset,'사용자 지정',
                                     ifelse(proposed=='CORE','자동/기본 일반주식','자동 분류'))
  # Manual decisions remain authoritative; automatic matching is a read-only
  # effective classification, never an INSERT/UPDATE to holdings_strategy.
  d$strategy_group[unset] <- proposed[unset]
  d$strategy_group[is.na(d$strategy_group) | d$strategy_group=='UNCLASSIFIED'] <- 'CORE'
  d
}
pms_strategy_view <- function(d) {
  target <- pms_strategy_target
  if(!nrow(d)) return(data.frame(그룹=names(target),목표비중=target*100,현재비중=NA_real_,평가액=NA_real_,편차=NA_real_,check.names=FALSE))
  good <- is.finite(d$market_value_krw) & d$quantity>0
  total <- sum(d$market_value_krw[good])
  amount <- vapply(names(target),function(g) sum(d$market_value_krw[good & d$strategy_group==g]),numeric(1))
  current <- if(total>0) amount/total*100 else rep(NA_real_,length(target))
  data.frame(그룹=names(target),목표비중=unname(target)*100,현재비중=unname(current),평가액=unname(amount),편차=unname(current-unname(target)*100),check.names=FALSE)
}
pms_diversification_server <- function(input,output,session,con,refresh) {
  status <- shiny::reactiveVal('미분류 종목은 일반주식으로 자동 집계합니다. 수동 지정한 분류가 우선합니다.')
  output$diversification_status <- shiny::renderText(status())
  d <- shiny::reactive({refresh(); pms_strategy_data(con)})
  agg <- shiny::reactive(pms_strategy_view(d()))
  output$diversification_summary <- shiny::renderUI({
    x <- d();valid <- is.finite(x$market_value_krw) & x$quantity>0
    total <- sum(x$market_value_krw[valid]); missing <- sum(x$quantity>0 & !valid)
    unknown <- sum(x$market_value_krw[valid & x$strategy_group=='UNCLASSIFIED'])
    automatic <- sum(grepl('^자동',x$classification_source[valid]))
    shiny::tags$div(class='alert alert-info',
      sprintf('평가 가능한 금융자산: %s원 / 미분류 평가액: %s원 / 시세·환율 누락: %d건',
        format(round(total),big.mark=','),format(round(unknown),big.mark=','),missing),
      shiny::tags$p(style='margin:3px 0 0;',sprintf('자동 분류 %d종목 · 사용자가 저장한 분류는 우선 적용됩니다.',automatic)),
      if(unknown>0 || missing>0) shiny::tags$p(style='color:#b45a18;', '미분류·시세누락분이 존재하면 목표 비중 판단과 매수 제안이 불완전할 수 있습니다.'))
  })
  output$diversification_chart <- shiny::renderPlot({
    a <- agg()
    current <- pmax(0,as.numeric(a$현재비중))
    target <- pmax(0,as.numeric(a$목표비중))
    current[!is.finite(current)] <- 0
    target[!is.finite(target)] <- 0
    current <- c(current,max(0,100-sum(current)))
    target <- c(target,max(0,100-sum(target)))
    group_names <- c('일반주식','SCHD','나스닥100','TQQQ','금','채권','현금성','미분류')
    palette <- c('#3D7BB6','#27876A','#7751B4','#D16E27',
                 '#D2AE52','#607A98','#868F9B','#BFC4CA')
    values <- cbind(current,target)
    rownames(values) <- group_names
    colnames(values) <- c('현재','목표')
    op <- par(mar=c(3.8,5.2,1.4,1),xpd=FALSE)
    on.exit(par(op))
    centers <- barplot(values,horiz=TRUE,beside=FALSE,col=palette,
      border='white',xlim=c(0,100),xaxt='n',las=1,
      names.arg=c('현재','목표'),cex.names=1.08,width=.7,space=.65)
    axis(1,at=seq(0,100,20),labels=paste0(seq(0,100,20),'%'),cex.axis=.86)
    for(j in seq_len(ncol(values))) {
      offsets <- cumsum(values[,j])-values[,j]
      for(i in seq_len(nrow(values))) {
        width <- values[i,j]
        if(!is.finite(width) || width <= 0) next
        x <- offsets[i]+width/2
        # Two-line names + weights when the segment fits; narrower segments
        # retain a short readable label. The table below has exact values.
        label <- if(width >= 10) sprintf('%s\n%.1f%%',group_names[i],width)
                 else if(width >= 4.5) group_names[i] else ''
        if(!nzchar(label)) next
        foreground <- if(i %in% c(5,8)) '#172b3f' else 'white'
        text(x,centers[j],labels=label,cex=if(width<7) .60 else .72,
             col=foreground,font=2)
      }
    }
    # Narrow allocations are also identified in the legend beneath the bars.
    par(xpd=NA)
    legend('bottom',inset=c(0,-.57),legend=group_names,fill=palette,
      horiz=TRUE,bty='n',cex=.70,x.intersp=.45)
  })
  output$diversification_table <- DT::renderDT({
    a<-agg();a$그룹<-unname(setNames(names(pms_strategy_choices()),pms_strategy_choices())[a$그룹]);
    a[c('목표비중','현재비중','편차')]<-lapply(a[c('목표비중','현재비중','편차')],function(x) round(x,2))
    a$평가액<-round(a$평가액)
    DT::datatable(a,rownames=FALSE,options=list(dom='t',paging=FALSE,scrollX=TRUE))
  })
  output$diversification_buy_advice <- shiny::renderUI({
    x<-d(); a<-agg();cash<-suppressWarnings(as.numeric(input$diversification_new_cash));
    if(!is.finite(cash) || cash<0) return(shiny::tags$p('신규 투자금은 0원 이상의 숫자로 입력하세요.'))
    if(!nrow(x)) return(shiny::tags$p('보유종목을 등록한 후 확인할 수 있습니다.'))
    valid<-is.finite(x$market_value_krw) & x$quantity>0
    if(any(x$quantity>0 & !valid) || any(x$strategy_group[valid]=='UNCLASSIFIED'))
      return(shiny::tags$div(class='alert alert-warning','미분류 또는 평가 누락 종목이 있습니다. 분류·시세를 확인해야 매수금액을 제안할 수 있습니다.'))
    total<-sum(x$market_value_krw[valid]); after<-total+cash
    gaps<-pmax(0,pms_strategy_target*after-a$평가액)
    if(sum(gaps)>0) allocation<-cash*gaps/sum(gaps) else allocation<-rep(0,length(gaps))
    labels<-setNames(names(pms_strategy_choices()),pms_strategy_choices())
    pretty<-paste0(labels[names(pms_strategy_target)],': ',format(round(allocation),big.mark=','),'원')
    shiny::tags$div(class='well',shiny::tags$b('신규 자금 우선 매수안 (기존 보유분 매도 없음)'),
      shiny::tags$p(paste(pretty,collapse=' / ')),
      shiny::tags$small('목표 대비 부족액에 비례해 배분하는 참고용 계산입니다. 거래 수량, 수수료, 세금은 반영하지 않습니다.'))
  })
  output$diversification_holdings <- DT::renderDT({
    x<-d();if(!nrow(x))return(DT::datatable(data.frame(안내='보유종목 없음')))
    labels<-setNames(names(pms_strategy_choices()),pms_strategy_choices())
    DT::datatable(data.frame(ID=x$id,종목명=x$name,종목코드=x$symbol,자산군=x$asset_class,
      적용투자그룹=unname(labels[x$strategy_group]),분류근거=x$classification_source,자동추천=unname(labels[x$suggested_group]),
      평가액=round(x$market_value_krw),check.names=FALSE),rownames=FALSE,
      selection='single',options=list(pageLength=20,scrollX=TRUE))
  })
  shiny::observe({
    x<-d();labs<-paste0(x$name,' (',x$symbol,') / ID ',x$id)
    keep <- shiny::isolate(input$diversification_holding_id)
    ids <- as.character(x$id)
    shiny::updateSelectInput(session,'diversification_holding_id',
      choices=stats::setNames(ids,labs),
      selected=if(length(keep)==1L && keep %in% ids) keep else if(length(ids)) ids[1] else character())
  })
  shiny::observeEvent(input$diversification_holdings_rows_selected,{
    x<-d();i<-input$diversification_holdings_rows_selected
    if(length(i)==1L && i>0 && i<=nrow(x)) shiny::updateSelectInput(session,'diversification_holding_id',selected=as.character(x$id[i]))
  })
  shiny::observeEvent(input$diversification_holding_id,{
    x<-d();idx<-match(as.integer(input$diversification_holding_id),x$id)
    if(is.finite(idx)) shiny::updateSelectInput(session,'diversification_group',selected=x$strategy_group[idx])
  })
  shiny::observeEvent(input$diversification_save_group,{
    id<-suppressWarnings(as.integer(input$diversification_holding_id));group<-input$diversification_group
    tryCatch({
      if(length(id)!=1L || !is.finite(id) || !group %in% names(pms_strategy_target)) stop('유효한 종목과 투자그룹을 지정하세요.')
      if(is.null(get_holding(con,id)))stop('해당 보유종목이 없습니다.')
      pms_strategy_init(con)
      DBI::dbExecute(con,'INSERT INTO holdings_strategy (holding_id,strategy_group) VALUES (?,?) ON CONFLICT(holding_id) DO UPDATE SET strategy_group=excluded.strategy_group',params=list(id,group))
      status(sprintf('ID %s의 목표 투자그룹을 %s로 저장했습니다.',id,group));refresh(shiny::isolate(refresh())+1L)
    },error=function(e)status(paste('저장 오류:',conditionMessage(e))))
  })
}
