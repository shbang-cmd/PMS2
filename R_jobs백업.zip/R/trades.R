# Historical holdings and changes inferred from consecutive daily positions.
pms_trades_init <- function(con) {
  DBI::dbExecute(con, "CREATE TABLE IF NOT EXISTS historical_positions (
   snapshot_date TEXT NOT NULL, country TEXT NOT NULL, symbol TEXT NOT NULL,
   name TEXT, broker TEXT NOT NULL, quantity REAL NOT NULL, avg_price REAL,
   market_price REAL, market_value REAL, profit REAL, source_file TEXT,
   PRIMARY KEY(snapshot_date,country,symbol,broker))")
  DBI::dbExecute(con, 'CREATE INDEX IF NOT EXISTS idx_hist_date ON historical_positions(snapshot_date)')
  invisible(TRUE)
}
pms_trades_seed <- function(con, seed_file=file.path('data','historical_holdings_seed.sqlite')) {
  pms_trades_init(con)
  if(!file.exists(seed_file)) return(0L)
  n <- DBI::dbGetQuery(con,'SELECT COUNT(*) AS n FROM historical_positions')$n[1]
  if(n>0) return(as.integer(n))
  seed <- DBI::dbConnect(RSQLite::SQLite(),seed_file)
  on.exit(DBI::dbDisconnect(seed),add=TRUE)
  DBI::dbWithTransaction(con,{
    rows <- DBI::dbReadTable(seed,'history')
    DBI::dbWriteTable(con,'historical_positions',rows,append=TRUE,row.names=FALSE)
  })
  as.integer(DBI::dbGetQuery(con,'SELECT COUNT(*) AS n FROM historical_positions')$n[1])
}
pms_trades_changes <- function(con) {
  pms_trades_init(con)
  hist <- DBI::dbGetQuery(con, 'SELECT snapshot_date,country,symbol,name,broker,quantity,avg_price,market_price,market_value,profit FROM historical_positions ORDER BY snapshot_date,country,symbol,broker')
  snap <- tryCatch(DBI::dbGetQuery(con, "SELECT h.snapshot_date,h.country,h.symbol,h.name,h.broker,h.quantity,h.avg_price,h.current_price AS market_price,h.market_value_krw AS market_value,h.unrealized_pnl_krw AS profit FROM snapshot_holdings h JOIN snapshot_daily d ON h.snapshot_date=d.snapshot_date WHERE d.snapshot_status='COMPLETE' ORDER BY h.snapshot_date,h.country,h.symbol,h.broker"), error=function(e) NULL)
  # Different source systems use different broker/account identifiers.
  # NEVER bridge the last imported Excel day and the first app snapshot;
  # doing so previously labeled almost all holdings as 'sold'.
  history_deltas <- function(x, origin) {
    empty <- data.frame(date=character(),previous_date=character(),country=character(),symbol=character(),name=character(),broker=character(),previous_quantity=numeric(),quantity=numeric(),change=numeric(),kind=character(),gap_days=integer(),source=character(),stringsAsFactors=FALSE)
    if(is.null(x) || !nrow(x)) return(empty)
    x$quantity <- suppressWarnings(as.numeric(x$quantity))
    x <- x[is.finite(x$quantity) & !is.na(x$symbol) & nzchar(x$symbol),,drop=FALSE]
    if(!nrow(x)) return(empty)
    dates <- sort(unique(as.character(x$snapshot_date)))
    if(length(dates)<2L) return(empty)
    rows <- list()
    for(i in 2:length(dates)) {
      prev <- x[x$snapshot_date==dates[i-1L],,drop=FALSE]
      now <- x[x$snapshot_date==dates[i],,drop=FALSE]
      # Entire country missing is usually a partial import, not liquidation.
      if(!setequal(unique(prev$country),unique(now$country))) next
      # Very low coverage signals an incomplete snapshot/import.
      if(nrow(prev)>10L && nrow(now)<nrow(prev)*0.5) next
      key <- function(z) paste(z$country,z$symbol,z$broker,sep='|')
      # Sum duplicated keys to avoid match() silently dropping accounts.
      aggregate_rows <- function(z) {
        k <- key(z)
        totals <- tapply(z$quantity,k,sum,na.rm=TRUE)
        indices <- match(names(totals),k)
        z <- z[indices,,drop=FALSE]
        z$quantity <- as.numeric(totals)
        rownames(z) <- NULL
        z
      }
      prev <- aggregate_rows(prev); now <- aggregate_rows(now)
      kp <- key(prev); kn <- key(now)
      ks <- union(kp,kn); pi <- match(ks,kp); ni <- match(ks,kn)
      pq <- ifelse(is.na(pi),0,prev$quantity[pmax(pi,1L)])
      nq <- ifelse(is.na(ni),0,now$quantity[pmax(ni,1L)])
      delta <- nq-pq
      changed <- is.finite(delta) & abs(delta)>1e-7
      if(!any(changed)) next
      pi <- pi[changed];ni <- ni[changed];pq <- pq[changed];nq <- nq[changed];delta <- delta[changed]
      co <- ifelse(is.na(ni),prev$country[pmax(pi,1L)],now$country[pmax(ni,1L)])
      sy <- ifelse(is.na(ni),prev$symbol[pmax(pi,1L)],now$symbol[pmax(ni,1L)])
      nm <- ifelse(is.na(ni),prev$name[pmax(pi,1L)],now$name[pmax(ni,1L)])
      br <- ifelse(is.na(ni),prev$broker[pmax(pi,1L)],now$broker[pmax(ni,1L)])
      rows[[length(rows)+1L]] <- data.frame(date=dates[i],previous_date=dates[i-1L],country=co,symbol=sy,name=nm,broker=br,
        previous_quantity=pq,quantity=nq,change=delta,kind=ifelse(delta>0,'증가(매수 추정)','감소(매도 추정)'),
        gap_days=as.integer(as.Date(dates[i])-as.Date(dates[i-1L])),source=origin,stringsAsFactors=FALSE)
    }
    if(!length(rows)) empty else do.call(rbind,rows)
  }
  a <- history_deltas(hist,'과거 엑셀')
  b <- history_deltas(snap,'PMS2 스냅샷')
  # A fractional holding can decrease by a whole number when whole shares
  # are moved into the ordinary-share position. This is NOT a sale.
  # Match opposite position deltas in the same country, symbol and broker family.
  classify_conversions <- function(x) {
    if(!nrow(x)) return(x)
    broker_family <- function(z) {
      z <- toupper(gsub('[[:space:]_\\-]','',as.character(z)))
      z <- gsub('소수점|FRACTIONAL|소수|온주|일반주|일반', '', z)
      z <- gsub('증권|SECURITIES|BROKERAGE','',z)
      z <- sub('^NH.*','NH',z)
      z <- sub('^KB.*','KB',z)
      z <- sub('^삼성.*','삼성',z)
      z <- sub('^한투.*|^한국투자.*','한국투자',z)
      z <- sub('^미래.*','미래에셋',z)
      z
    }
    x$kind <- as.character(x$kind)
    grp <- paste(x$date,x$source,x$country,x$symbol,broker_family(x$broker),sep='|')
    for (g in unique(grp)) {
      ids <- which(grp==g)
      if(length(ids)<2L) next
      fractional <- grepl('소수점|FRACTIONAL|소수',x$broker[ids],ignore.case=TRUE) |
        (abs(x$previous_quantity[ids]-round(x$previous_quantity[ids]))>1e-6) |
        (abs(x$quantity[ids]-round(x$quantity[ids]))>1e-6)
      outgoing <- ids[fractional & x$change[ids]< -1e-7 &
        abs(abs(x$change[ids])-round(abs(x$change[ids])))<1e-5 &
        abs(x$change[ids])>=1-1e-5]
      incoming <- ids[!fractional & x$change[ids]>1e-7]
      if(!length(outgoing)||!length(incoming)) next
      # Only confidently label a full matched transfer, never a lone decrease.
      for (o in outgoing) {
        candidates <- incoming[abs(x$change[incoming]+x$change[o])<1e-5]
        if(!length(candidates)) next
        j <- candidates[1]
        x$kind[o] <- '온주전환 추정(소수점 감소)'
        x$kind[j] <- '온주전환 추정(일반주 증가)'
        incoming <- setdiff(incoming,j)
      }
    }
    x
  }
  a <- classify_conversions(a)
  b <- classify_conversions(b)
  # On overlapping dates prefer imported history to avoid duplicated changes.
  if(nrow(a) && nrow(b)) b <- b[!b$date %in% unique(a$date),,drop=FALSE]
  ans <- rbind(a,b)
  if(nrow(ans)) ans <- ans[order(ans$date,ans$country,ans$symbol),,drop=FALSE]
  ans
}

pms_trades_calendar <- function(changes, month) {
  start <- as.Date(paste0(month,'-01'))
  if(is.na(start)) return(shiny::tags$p('날짜가 잘못되었습니다.'))
  end <- seq(start,by='1 month',length.out=2)[2]-1
  first <- start-(as.POSIXlt(start)$wday+6L)%%7L
  ndays <- as.integer(end-first)+1L
  ndays <- ceiling(ndays/7)*7L
  days <- seq(first,by='day',length.out=ndays)
  header <- lapply(seq_along(c('월','화','수','목','금','토','일')),function(j)shiny::tags$div(c('월','화','수','목','금','토','일')[j],class='pms-trade-dow',style=paste0('text-align:center;font-weight:700;padding:7px;background:#ecf1f6;color:',if(j==6)'#2563eb' else if(j==7)'#dc2626' else '#334155',';')))
  cells <- lapply(days,function(day){
    key <- as.character(day)
    z <- if(nrow(changes)) changes[changes$date==key,,drop=FALSE] else data.frame()
    buy <- if(nrow(z)) sum(z$kind=='증가(매수 추정)') else 0L
    sell <- if(nrow(z)) sum(z$kind=='감소(매도 추정)') else 0L
    transfer <- if(nrow(z)) sum(grepl('온주전환',z$kind)) else 0L
    style <- paste0('min-height:92px;padding:7px;border:1px solid #dce4ec;border-radius:5px;',
      if(format(day,'%Y-%m')==month) 'background:white;' else 'background:#f6f7f9;opacity:.55;',
      if(nrow(z)) 'cursor:pointer;border-left:3px solid #3b7cbd;' else '')
    onclick <- if(nrow(z)) sprintf("Shiny.setInputValue('pms_trade_day','%s',{priority:'event'});",key) else NULL
    shiny::tags$div(class='pms-trade-day',style=style,onclick=onclick,
      shiny::tags$strong(format(day,'%d'),style=paste0('color:',if(as.POSIXlt(day)$wday==6)'#2563eb' else if(as.POSIXlt(day)$wday==0)'#dc2626' else 'inherit',';')),
      if(buy) shiny::tags$div(paste0('▲ 증가 ',buy,'건'),style='font-size:12px;color:#be4350;'),
      if(sell) shiny::tags$div(paste0('▼ 감소 ',sell,'건'),style='font-size:12px;color:#3268ad;'),
      if(transfer) shiny::tags$div(paste0('⇄ 온주전환 ',transfer,'건'),style='font-size:12px;color:#39866f;'),
      if(nrow(z)) shiny::tags$small('클릭하여 상세 보기',style='color:#596a7b;'))
  })
  shiny::tags$div(style='display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:5px;',c(header,cells))
}


# 12-month turnover estimated from net position changes; not brokerage fills.
# Both buys and sells use the SAME historical-price and FX policy.
pms_trade_value_estimate_12m <- function(con, asof=Sys.Date()) {
  empty <- list(buy=NA_real_,sell=NA_real_,net=NA_real_,buy_monthly=NA_real_,
                sell_monthly=NA_real_,net_monthly=NA_real_,buy_n=0L,sell_n=0L,
                excluded=0L,months=0L,note='보유수량 변화 기록이 없습니다.')
  x <- pms_trades_changes(con)
  if(!nrow(x)) return(empty)
  start <- as.Date(asof)-365L
  x <- x[as.Date(x$date)>start & as.Date(x$date)<=as.Date(asof) &
         x$kind %in% c('증가(매수 추정)','감소(매도 추정)') &
         is.finite(x$change) & abs(x$change)>1e-7,,drop=FALSE]
  if(!nrow(x)) {
    empty$buy <- empty$sell <- empty$net <- 0
    empty$buy_monthly <- empty$sell_monthly <- empty$net_monthly <- 0
    empty$note <- '최근 365일간 확인된 매수·매도 추정 기록이 없습니다.'
    return(empty)
  }
  hist <- DBI::dbGetQuery(con,'SELECT snapshot_date,country,symbol,broker,quantity,market_price,market_value FROM historical_positions WHERE snapshot_date>=?',params=list(as.character(start)))
  snap <- tryCatch(DBI::dbGetQuery(con,'SELECT snapshot_date,country,symbol,broker,quantity,current_price AS market_price,market_value_krw AS market_value FROM snapshot_holdings WHERE snapshot_date>=?',params=list(as.character(start))),error=function(e) hist[FALSE,,drop=FALSE])
  fx <- tryCatch(DBI::dbGetQuery(con,'SELECT rate_date,rate FROM usdkrw_daily ORDER BY rate_date'),error=function(e) data.frame(rate_date=character(),rate=numeric()))
  value <- rep(NA_real_,nrow(x))
  for(i in seq_len(nrow(x))) {
    z <- if(x$source[i]=='과거 엑셀') hist else snap
    r <- z[z$snapshot_date==x$date[i] & z$country==x$country[i] &
             z$symbol==x$symbol[i] & z$broker==x$broker[i],,drop=FALSE]
    # A complete sell can have no row on the current date. Use prior recorded
    # position price, but only from the paired previous observation.
    if(!nrow(r) && x$change[i]<0) {
      r <- z[z$snapshot_date==x$previous_date[i] & z$country==x$country[i] &
             z$symbol==x$symbol[i] & z$broker==x$broker[i],,drop=FALSE]
    }
    if(!nrow(r)) next
    qty <- suppressWarnings(as.numeric(r$quantity))
    px0 <- suppressWarnings(as.numeric(r$market_price))
    good <- is.finite(qty)&qty>0&is.finite(px0)&px0>0
    if(!any(good)) next
    px <- sum(qty[good]*px0[good])/sum(qty[good])
    amt <- abs(x$change[i])*px
    if(x$country[i]=='US') {
      if(x$source[i]=='과거 엑셀') {
        ff <- fx[as.Date(fx$rate_date)<=as.Date(x$date[i]) &
                 as.Date(fx$rate_date)>=as.Date(x$date[i])-7L & is.finite(fx$rate),,drop=FALSE]
        if(!nrow(ff)) next
        amt <- amt*tail(ff$rate,1)
      } else {
        # Current snapshots store market value in KRW, price in USD.
        # Derive historical evaluation FX from the same dated row, not today's FX.
        mv <- suppressWarnings(as.numeric(r$market_value))
        fxrow <- mv/(qty*px0)
        validfx <- is.finite(fxrow)&fxrow>0 & good
        if(!any(validfx)) next
        amt <- amt*sum(qty[validfx]*fxrow[validfx])/sum(qty[validfx])
      }
    }
    value[i] <- amt
  }
  buy <- x$change>0
  sell <- x$change<0
  bn <- sum(buy & is.finite(value)); sn <- sum(sell & is.finite(value))
  b <- if(bn) sum(value[buy & is.finite(value)]) else if(any(buy)) NA_real_ else 0
  v <- if(sn) sum(value[sell & is.finite(value)]) else if(any(sell)) NA_real_ else 0
  net <- if(is.finite(b)&&is.finite(v)) b-v else NA_real_
  missing <- sum(!is.finite(value))
  list(buy=b,sell=v,net=net,buy_monthly=b/12,sell_monthly=v/12,
       net_monthly=net/12,buy_n=as.integer(bn),sell_n=as.integer(sn),
       excluded=as.integer(missing),months=length(unique(substr(x$date,1L,7L))),
       note=sprintf('최근 365일의 수량 증가·감소에 기록일 시세를 적용했습니다. 매수 %d건, 매도 %d건 평가 가능; 가격·환율 미확인 %d건 제외. 과거 엑셀의 정확한 체결가격과 매매일이 아닐 수 있습니다.',bn,sn,missing))
}

# Backward-compatible interface for the pre-existing home section.
pms_buy_estimate_12m <- function(con,asof=Sys.Date()) {
  x <- pms_trade_value_estimate_12m(con,asof)
  list(total=x$buy,mean=x$buy_monthly,n=x$buy_n,excluded=x$excluded,
       months=x$months,note=x$note)
}
