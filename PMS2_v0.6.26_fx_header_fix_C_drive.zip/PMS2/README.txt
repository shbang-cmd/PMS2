PMS2 v0.6.26 FX header display fix. Extract to C:\, overwriting PMS2/app.R only. Back up app.R first. Database unchanged.
