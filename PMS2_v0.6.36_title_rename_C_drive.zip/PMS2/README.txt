PMS2 v0.6.36
Changes: App display title / browser tab title / subtitle only.
Install: Back up C:\PMS2\app.R, exit PMS2, extract to C:\.
No database or R module changes.
